const Version = '2026-05-12 13:40:00';
import { connect } from 'cloudflare\u003asockets';
let config_JSON, 反代IP = '', 启用SOCKS5反代 = null, 启用SOCKS5全局反代 = false, 我的SOCKS5账号 = '', parsedSocks5Address = {};
let 缓存反代IP, 缓存反代解析数组, 缓存反代数组索引 = 0, 启用反代兜底 = true, 调试日志打印 = false;
let SOCKS5白名单 = ['*tapecontent.net', '*cloudatacdn.com', '*loadshare.org', '*cdn-centaurus.com', 'scholar.google.com'];
const Pages静态页面 = 'https://edt-pages.github.io';
export default {
    async fetch(request, env, ctx) {
        let 请求URL文本 = request.url.replace(/%5[Cc]/g, '').replace(/\\/g, '');
        const 请求URL锚点索引 = 请求URL文本.indexOf('#');
        const 请求URL主体部分 = 请求URL锚点索引 === -1 ? 请求URL文本 : 请求URL文本.slice(0, 请求URL锚点索引);
        if (!请求URL主体部分.includes('?') && /%3f/i.test(请求URL主体部分)) {
            const 请求URL锚点部分 = 请求URL锚点索引 === -1 ? '' : 请求URL文本.slice(请求URL锚点索引);
            请求URL文本 = 请求URL主体部分.replace(/%3f/i, '?') + 请求URL锚点部分;
        }
        const url = new URL(请求URL文本);
        const UA = request.headers.get('User-Agent') || 'null';
        const upgradeHeader = (request.headers.get('Upgrade') || '').toLowerCase(), contentType = (request.headers.get('content-type') || '').toLowerCase();
        const 管理员密码 = env.ADMIN || env.admin || env.PASSWORD || env.password || env.pswd || env.TOKEN || env.KEY || env.UUID || env.uuid;
        const 加密秘钥 = env.KEY || '勿动此默认密钥，有需求请自行通过添加变量KEY进行修改';
        const userIDMD5 = await MD5MD5(管理员密码 + 加密秘钥);
        const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/;
        const envUUID = env.UUID || env.uuid;
        const userID = (envUUID && uuidRegex.test(envUUID)) ? envUUID.toLowerCase() : [userIDMD5.slice(0, 8), userIDMD5.slice(8, 12), '4' + userIDMD5.slice(13, 16), '8' + userIDMD5.slice(17, 20), userIDMD5.slice(20)].join('-');
        const hosts = env.HOST ? (await 整理成数组(env.HOST)).map(h => h.toLowerCase().replace(/^https?:\/\//, '').split('/')[0].split(':')[0]) : [url.hostname];
        const host = hosts[0];
        const 访问路径 = url.pathname.slice(1).toLowerCase().replace(/\/+$/g, '');
        let 登录路径 = String(env.LOGIN_PATH || 'get')
            .toLowerCase()
            .replace(/^\/+|\/+$/g, '')
            .replace(/\/+/g, '/')
            .replace(/[^a-z0-9_/-]/g, '')
            .split('/')
            .filter(Boolean)
            .join('/') || 'get';
        if (登录路径 === 'get/skyeye') 登录路径 = 'get';
        const 登录路径首段 = 登录路径.split('/')[0];
        if (['login', 'admin', 'administrator', 'dashboard', 'logout', 'sub', 'api'].includes(登录路径首段)) 登录路径 = 'get';
        let 原始页面路径 = String(env.ORIGINAL_PATH || env.SETTINGS_PATH || 'get/skyeye')
            .toLowerCase()
            .replace(/^\/+|\/+$/g, '')
            .replace(/\/+/g, '/')
            .replace(/[^a-z0-9_/-]/g, '')
            .split('/')
            .filter(Boolean)
            .join('/') || 'get/skyeye';
        const 原始页面路径首段 = 原始页面路径.split('/')[0];
        if (原始页面路径 === 登录路径 || ['login', 'admin', 'administrator', 'dashboard', 'logout', 'sub', 'api'].includes(原始页面路径首段)) 原始页面路径 = 'get/skyeye';
        调试日志打印 = ['1', 'true'].includes(env.DEBUG) || 调试日志打印;
        if (env.PROXYIP) {
            const proxyIPs = await 整理成数组(env.PROXYIP);
            反代IP = proxyIPs[Math.floor(Math.random() * proxyIPs.length)];
            启用反代兜底 = false;
        }
        else
            反代IP = (request.cf.colo + '.PrOxYIp.CmLiUsSsS.nEt').toLowerCase();
        const 访问IP = request.headers.get('CF-Connecting-IP') || request.headers.get('True-Client-IP') || request.headers.get('X-Real-IP') || request.headers.get('X-Forwarded-For') || request.headers.get('Fly-Client-IP') || request.headers.get('X-Appengine-Remote-Addr') || request.headers.get('X-Cluster-Client-IP') || '未知IP';
        if (env.GO2SOCKS5)
            SOCKS5白名单 = await 整理成数组(env.GO2SOCKS5);
        if (访问路径 === 'version' && url.searchParams.get('uuid') === userID) {
            return new Response(JSON.stringify({ Version: Number(String(Version).replace(/\D+/g, '')) }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
        }
        else if (管理员密码 && upgradeHeader === 'websocket') {
            await 反代参数获取(url, userID);
            log(`[WebSocket] 命中请求: ${url.pathname}${url.search}`);
            return await 处理WS请求(request, userID, url);
        }
        else if (管理员密码 && !访问路径.startsWith('admin/') && 访问路径 !== 登录路径 && 访问路径 !== 原始页面路径 && request.method === 'POST') {
            await 反代参数获取(url, userID);
            const referer = request.headers.get('Referer') || '';
            const 命中XHTTP特征 = referer.includes('x_padding', 14) || referer.includes('x_padding=');
            if (!命中XHTTP特征 && contentType.startsWith('application/grpc')) {
                log(`[gRPC] 命中请求: ${url.pathname}${url.search}`);
                return await 处理gRPC请求(request, userID);
            }
            log(`[XHTTP] 命中请求: ${url.pathname}${url.search}`);
            return await 处理XHTTP请求(request, userID);
        }
        else {
            if (url.protocol === 'http:')
                return Response.redirect(url.href.replace(`http://${url.hostname}`, `https://${url.hostname}`), 301);
            if (!管理员密码)
                return fetch(Pages静态页面 + '/noADMIN').then(r => { const headers = new Headers(r.headers); headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate'); headers.set('Pragma', 'no-cache'); headers.set('Expires', '0'); return new Response(r.body, { status: 404, statusText: r.statusText, headers }); });
            const 区分大小写访问路径 = url.pathname.slice(1);
            if (访问路径 === '' && request.method === 'GET') {
                return new Response(生成谷歌伪装页面(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
            }
            if ((访问路径 === 'login' || 访问路径.startsWith('login/')) && 访问路径 !== 登录路径) {
                return new Response(生成谷歌伪装页面(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
            }
            if (访问路径 === 'admin' || 访问路径.startsWith('admin/')) {
                const cookies = request.headers.get('Cookie') || '';
                const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                if (!authCookie || authCookie !== await MD5MD5(UA + 加密秘钥 + 管理员密码))
                    return new Response(生成谷歌伪装页面(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
            }
            if (访问路径 === 原始页面路径) {
                const cookies = request.headers.get('Cookie') || '';
                const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                if (request.method === 'POST') {
                    const formData = await request.text();
                    const params = new URLSearchParams(formData);
                    const 输入密码 = params.get('password');
                    if (输入密码 === (typeof 管理员密码 === 'string' ? 管理员密码.replace(/[\r\n]/g, '') : 管理员密码)) {
                        const 响应 = new Response(JSON.stringify({ success: true }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        响应.headers.set('Set-Cookie', `auth=${await MD5MD5(UA + 加密秘钥 + 管理员密码)}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Strict`);
                        return 响应;
                    }
                    return new Response(JSON.stringify({ success: false, error: '密码错误' }), { status: 401, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                }
                if (!authCookie || authCookie !== await MD5MD5(UA + 加密秘钥 + 管理员密码))
                    return new Response(生成本地登录页面(原始页面路径, '/' + 原始页面路径), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                return fetch(Pages静态页面 + '/admin' + url.search).then(r => { const headers = new Headers(r.headers); headers.set('Cache-Control', 'no-store'); return new Response(r.body, { status: r.status, statusText: r.statusText, headers }); });
            }
            if (访问路径 === 登录路径) {
                const cookies = request.headers.get('Cookie') || '';
                const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                if (authCookie == await MD5MD5(UA + 加密秘钥 + 管理员密码)) {
                    if (env.KV && typeof env.KV.get === 'function') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const 当前ADD = await env.KV.get('ADD.txt') || '';
                        const 当前选中地区 = await 读取选中地区(env);
                        return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '', 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                    }
                    return new Response(生成KV未绑定页面(登录路径), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                }
                if (request.method === 'POST') {
                    const formData = await request.text();
                    const params = new URLSearchParams(formData);
                    const 输入密码 = params.get('password');
                    if (输入密码 === (typeof 管理员密码 === 'string' ? 管理员密码.replace(/[\r\n]/g, '') : 管理员密码)) {
                        const 响应 = new Response(JSON.stringify({ success: true }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        响应.headers.set('Set-Cookie', `auth=${await MD5MD5(UA + 加密秘钥 + 管理员密码)}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Strict`);
                        return 响应;
                    }
                    return new Response(JSON.stringify({ success: false, error: '密码错误' }), { status: 401, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                }
                return new Response(生成本地登录页面(登录路径), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
            }
            if (!(env.KV && typeof env.KV.get === 'function')) {
                if (访问路径 === 'admin' || 访问路径.startsWith('admin/')) {
                    const cookies = request.headers.get('Cookie') || '';
                    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                    if (!authCookie || authCookie !== await MD5MD5(UA + 加密秘钥 + 管理员密码))
                        return new Response(生成谷歌伪装页面(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                    return new Response(生成KV未绑定页面(登录路径), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                }
            }
            if (env.KV && typeof env.KV.get === 'function') {
                if (区分大小写访问路径 === 加密秘钥 && 加密秘钥 !== '勿动此默认密钥，有需求请自行通过添加变量KEY进行修改') {
                    const params = new URLSearchParams(url.search);
                    params.set('token', await MD5MD5(host + userID));
                    return new Response('重定向中...', { status: 302, headers: { 'Location': `/sub?${params.toString()}` } });
                }
                else if (访问路径 === 登录路径) {
                    const cookies = request.headers.get('Cookie') || '';
                    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                    if (authCookie == await MD5MD5(UA + 加密秘钥 + 管理员密码))
                        return new Response('重定向中...', { status: 302, headers: { 'Location': '/admin' } });
                    if (request.method === 'POST') {
                        const formData = await request.text();
                        const params = new URLSearchParams(formData);
                        const 输入密码 = params.get('password');
                        if (输入密码 === (typeof 管理员密码 === 'string' ? 管理员密码.replace(/[\r\n]/g, '') : 管理员密码)) {
                            const 响应 = new Response(JSON.stringify({ success: true }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                            响应.headers.set('Set-Cookie', `auth=${await MD5MD5(UA + 加密秘钥 + 管理员密码)}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Strict`);
                            return 响应;
                        }
                        return new Response(JSON.stringify({ success: false, error: '密码错误' }), { status: 401, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                    }
                    return new Response(生成本地登录页面(登录路径), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                }
                else if (访问路径 === 'admin' || 访问路径.startsWith('admin/')) {
                    const cookies = request.headers.get('Cookie') || '';
                    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                    if (!authCookie || authCookie !== await MD5MD5(UA + 加密秘钥 + 管理员密码))
                        return new Response(生成谷歌伪装页面(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                    if (访问路径 === 'admin/test-source') {
                        const 地区代码 = String(url.searchParams.get('region') || 'US').trim().toUpperCase();
                        try {
                            const 拉取结果 = await 获取地区节点文本(地区代码, env);
                            return new Response(JSON.stringify({ success: true, region: 地区代码, count: 拉取结果.count, source: 拉取结果.source, preview: 拉取结果.text.split('\n').slice(0, 10), errors: 拉取结果.errors || [] }, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        } catch (error) {
                            return new Response(JSON.stringify({ success: false, region: 地区代码, error: error.message || String(error) }, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin/speed-apply') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const target = String(url.searchParams.get('target') || 'adaptive').trim().toLowerCase();
                        const limit = Math.max(1, Math.min(1000, parseInt(url.searchParams.get('limit') || '30', 10) || 30));
                        try {
                            const 当前选中地区 = await 读取选中地区(env);
                            if (当前选中地区.length === 0) {
                                return new Response(JSON.stringify({ success: false, error: '请先选择国家/地区' }, null, 2), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                            }
                            config_JSON = await 读取config_JSON(env, host, userID, UA);
                            const 测速结果 = await 测速筛选选中地区节点(当前选中地区, env, limit);
                            await env.KV.put('ADD.txt', 测速结果.text);
                            if (!config_JSON.优选订阅生成)
                                config_JSON.优选订阅生成 = {};
                            if (!config_JSON.优选订阅生成.本地IP库)
                                config_JSON.优选订阅生成.本地IP库 = {};
                            config_JSON.优选订阅生成.local = true;
                            config_JSON.优选订阅生成.本地IP库.随机IP = false;
                            await env.KV.put('config.json', JSON.stringify(config_JSON, null, 2));
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Speed_Apply_Region_IPs', config_JSON));
                            const origin = url.protocol + '//' + url.host;
                            const link = 生成订阅链接(origin, 订阅TOKEN, target);
                            if (url.searchParams.get('html') === '1')
                                return new Response(生成复制结果页面(link, target, 测速结果.count, 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                            return new Response(JSON.stringify({ success: true, target, link, selectedRegions: 当前选中地区, count: 测速结果.count, tested: 测速结果.tested, total: 测速结果.total, fastest: 测速结果.fastest }, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        } catch (error) {
                            return new Response(JSON.stringify({ success: false, error: error.message || String(error) }, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin/apply-regions') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const target = String(url.searchParams.get('target') || 'adaptive').trim().toLowerCase();
                        const limit = Math.max(1, Math.min(5000, parseInt(url.searchParams.get('limit') || '200', 10) || 200));
                        try {
                            const 当前选中地区 = await 读取选中地区(env);
                            if (当前选中地区.length === 0) {
                                return new Response(JSON.stringify({ success: false, error: '请先选择国家/地区' }, null, 2), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                            }
                            config_JSON = await 读取config_JSON(env, host, userID, UA);
                            const 重建结果 = await 重建选中地区节点文本(当前选中地区, env, limit);
                            await env.KV.put('ADD.txt', 重建结果.text);
                            if (!config_JSON.优选订阅生成)
                                config_JSON.优选订阅生成 = {};
                            if (!config_JSON.优选订阅生成.本地IP库)
                                config_JSON.优选订阅生成.本地IP库 = {};
                            config_JSON.优选订阅生成.local = true;
                            config_JSON.优选订阅生成.本地IP库.随机IP = false;
                            await env.KV.put('config.json', JSON.stringify(config_JSON, null, 2));
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Apply_Region_IPs', config_JSON));
                            const origin = url.protocol + '//' + url.host;
                            const link = 生成订阅链接(origin, 订阅TOKEN, target);
                            if (url.searchParams.get('html') === '1')
                                return new Response(生成复制结果页面(link, target, 重建结果.count, 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                            return new Response(JSON.stringify({ success: true, target, link, selectedRegions: 当前选中地区, limit, count: 重建结果.count, details: 重建结果.details, errors: 重建结果.errors || [] }, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        } catch (error) {
                            return new Response(JSON.stringify({ success: false, error: error.message || String(error) }, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin/set-region') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const 地区代码 = String(url.searchParams.get('region') || '').trim().toUpperCase();
                        try {
                            const 当前ADD = await env.KV.get('ADD.txt') || '';
                            const 当前选中地区 = await 读取选中地区(env);
                            if (!/^[A-Z]{2}$/.test(地区代码) || !地区显示顺序.includes(地区代码))
                                return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '地区代码不正确：' + 地区代码, 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                            const 已选中 = 当前选中地区.includes(地区代码);
                            const 新选中地区 = 已选中 ? 当前选中地区.filter(item => item !== 地区代码) : [...当前选中地区, 地区代码];
                            await 保存选中地区(env, 新选中地区);
                            const 动作文本 = 已选中 ? '已取消 ' + 地区代码 : '已选择 ' + 地区代码;
                            const 提示文本 = '';
                            return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, 提示文本, 新选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        }
                        catch (error) {
                            const 当前ADD = await env.KV.get('ADD.txt') || '';
                            const 当前选中地区 = await 读取选中地区(env);
                            return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '选择失败：' + (error.message || String(error)), 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin/set-all-regions') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        try {
                            await 保存选中地区(env, 地区显示顺序);
                            const 当前ADD = await env.KV.get('ADD.txt') || '';
                            return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '', 地区显示顺序), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        } catch (error) {
                            const 当前ADD = await env.KV.get('ADD.txt') || '';
                            const 当前选中地区 = await 读取选中地区(env);
                            return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '全选失败：' + (error.message || String(error)), 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin/clear-regions') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        try {
                            config_JSON = await 读取config_JSON(env, host, userID, UA);
                            await 保存选中地区(env, []);
                            await env.KV.put('ADD.txt', '');
                            if (!config_JSON.优选订阅生成)
                                config_JSON.优选订阅生成 = {};
                            if (!config_JSON.优选订阅生成.本地IP库)
                                config_JSON.优选订阅生成.本地IP库 = {};
                            config_JSON.优选订阅生成.local = true;
                            config_JSON.优选订阅生成.本地IP库.随机IP = false;
                            await env.KV.put('config.json', JSON.stringify(config_JSON, null, 2));
                            return new Response(生成地区选择页面(订阅TOKEN, '', url.protocol + '//' + url.host, '', []), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        } catch (error) {
                            const 当前ADD = await env.KV.get('ADD.txt') || '';
                            const 当前选中地区 = await 读取选中地区(env);
                            return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '清空失败：' + (error.message || String(error)), 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    if (访问路径 === 'admin') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const 当前ADD = await env.KV.get('ADD.txt') || '';
                        const 当前选中地区 = await 读取选中地区(env);
                        return new Response(生成地区选择页面(订阅TOKEN, 当前ADD, url.protocol + '//' + url.host, '', 当前选中地区), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8', 'Cache-Control': 'no-store' } });
                    }
                    if (访问路径 === 'admin/log.json') {
                        const 读取日志内容 = await env.KV.get('log.json') || '[]';
                        return new Response(读取日志内容, { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                    }
                    else if (区分大小写访问路径 === 'admin/getCloudflareUsage') {
                        try {
                            const Usage_JSON = await getCloudflareUsage(url.searchParams.get('Email'), url.searchParams.get('GlobalAPIKey'), url.searchParams.get('AccountID'), url.searchParams.get('APIToken'));
                            return new Response(JSON.stringify(Usage_JSON, null, 2), { status: 200, headers: { 'Content-Type': 'application/json' } });
                        }
                        catch (err) {
                            const errorResponse = { msg: '查询请求量失败，失败原因：' + err.message, error: err.message };
                            return new Response(JSON.stringify(errorResponse, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                        }
                    }
                    else if (区分大小写访问路径 === 'admin/getADDAPI') {
                        if (url.searchParams.get('url')) {
                            const 待验证优选URL = url.searchParams.get('url');
                            try {
                                new URL(待验证优选URL);
                                const 请求优选API内容 = await 请求优选API([待验证优选URL], url.searchParams.get('port') || '443');
                                let 优选API的IP = 请求优选API内容[0].length > 0 ? 请求优选API内容[0] : 请求优选API内容[1];
                                优选API的IP = 优选API的IP.map(item => item.replace(/#(.+)$/, (_, remark) => '#' + decodeURIComponent(remark)));
                                return new Response(JSON.stringify({ success: true, data: 优选API的IP }, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                            catch (err) {
                                const errorResponse = { msg: '验证优选API失败，失败原因：' + err.message, error: err.message };
                                return new Response(JSON.stringify(errorResponse, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                        }
                        return new Response(JSON.stringify({ success: false, data: [] }, null, 2), { status: 403, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                    }
                    else if (访问路径 === 'admin/check') {
                        const 代理协议 = ['socks5', 'http', 'https', 'turn', 'sstp'].find(类型 => url.searchParams.has(类型)) || null;
                        if (!代理协议)
                            return new Response(JSON.stringify({ error: '缺少代理参数' }), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                        const 代理参数 = url.searchParams.get(代理协议);
                        const startTime = Date.now();
                        let 检测代理响应;
                        try {
                            parsedSocks5Address = await 获取SOCKS5账号(代理参数, 获取代理默认端口(代理协议));
                            const { username, password, hostname, port } = parsedSocks5Address;
                            const 完整代理参数 = username && password ? `${username}:${password}@${hostname}:${port}` : `${hostname}:${port}`;
                            try {
                                const 检测主机 = 'cloudflare.com', 检测端口 = 443, encoder = new TextEncoder(), decoder = new TextDecoder();
                                let tcpSocket = null, tlsSocket = null;
                                try {
                                    tcpSocket = 代理协议 === 'socks5'
                                        ? await socks5Connect(检测主机, 检测端口, new Uint8Array(0))
                                        : 代理协议 === 'turn'
                                            ? await turnConnect(parsedSocks5Address, 检测主机, 检测端口)
                                            : 代理协议 === 'sstp'
                                                ? await sstpConnect(parsedSocks5Address, 检测主机, 检测端口)
                                                : (代理协议 === 'https' && isIPHostname(hostname)
                                                    ? await httpsConnect(检测主机, 检测端口, new Uint8Array(0))
                                                    : await httpConnect(检测主机, 检测端口, new Uint8Array(0), 代理协议 === 'https'));
                                    if (!tcpSocket)
                                        throw new Error('无法连接到代理服务器');
                                    tlsSocket = new TlsClient(tcpSocket, { serverName: 检测主机, insecure: true });
                                    await tlsSocket.handshake();
                                    await tlsSocket.write(encoder.encode(`GET /cdn-cgi/trace HTTP/1.1\r\nHost: ${检测主机}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n`));
                                    let responseBuffer = new Uint8Array(0), headerEndIndex = -1, contentLength = null, chunked = false;
                                    const 最大响应字节 = 64 * 1024;
                                    while (responseBuffer.length < 最大响应字节) {
                                        const value = await tlsSocket.read();
                                        if (!value)
                                            break;
                                        if (value.byteLength === 0)
                                            continue;
                                        responseBuffer = 拼接字节数据(responseBuffer, value);
                                        if (headerEndIndex === -1) {
                                            const crlfcrlf = responseBuffer.findIndex((_, i) => i < responseBuffer.length - 3 && responseBuffer[i] === 0x0d && responseBuffer[i + 1] === 0x0a && responseBuffer[i + 2] === 0x0d && responseBuffer[i + 3] === 0x0a);
                                            if (crlfcrlf !== -1) {
                                                headerEndIndex = crlfcrlf + 4;
                                                const headers = decoder.decode(responseBuffer.slice(0, headerEndIndex));
                                                const statusLine = headers.split('\r\n')[0] || '';
                                                const statusMatch = statusLine.match(/HTTP\/\d\.\d\s+(\d+)/);
                                                const statusCode = statusMatch ? parseInt(statusMatch[1], 10) : NaN;
                                                if (!Number.isFinite(statusCode) || statusCode < 200 || statusCode >= 300)
                                                    throw new Error(`代理检测请求失败: ${statusLine || '无效响应'}`);
                                                const lengthMatch = headers.match(/\r\nContent-Length:\s*(\d+)/i);
                                                if (lengthMatch)
                                                    contentLength = parseInt(lengthMatch[1], 10);
                                                chunked = /\r\nTransfer-Encoding:\s*chunked/i.test(headers);
                                            }
                                        }
                                        if (headerEndIndex !== -1 && contentLength !== null && responseBuffer.length >= headerEndIndex + contentLength)
                                            break;
                                        if (headerEndIndex !== -1 && chunked && decoder.decode(responseBuffer).includes('\r\n0\r\n\r\n'))
                                            break;
                                    }
                                    if (headerEndIndex === -1)
                                        throw new Error('代理检测响应头过长或无效');
                                    const response = decoder.decode(responseBuffer);
                                    const ip = response.match(/(?:^|\n)ip=(.*)/)?.[1];
                                    const loc = response.match(/(?:^|\n)loc=(.*)/)?.[1];
                                    if (!ip || !loc)
                                        throw new Error('代理检测响应无效');
                                    检测代理响应 = { success: true, proxy: 代理协议 + "://" + 完整代理参数, ip, loc, responseTime: Date.now() - startTime };
                                }
                                finally {
                                    try {
                                        tlsSocket ? tlsSocket.close() : await tcpSocket?.close?.();
                                    }
                                    catch (e) { }
                                }
                            }
                            catch (error) {
                                检测代理响应 = { success: false, error: error.message, proxy: 代理协议 + "://" + 完整代理参数, responseTime: Date.now() - startTime };
                            }
                        }
                        catch (err) {
                            检测代理响应 = { success: false, error: err.message, proxy: 代理协议 + "://" + 代理参数, responseTime: Date.now() - startTime };
                        }
                        return new Response(JSON.stringify(检测代理响应, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                    }
                    config_JSON = await 读取config_JSON(env, host, userID, UA);
                    if (访问路径 === 'admin/region' && request.method === 'POST') {
                        try {
                            let 请求体 = {};
                            const 原始请求体 = await request.text();
                            try {
                                请求体 = JSON.parse(原始请求体 || '{}');
                            }
                            catch (e) {
                                请求体 = Object.fromEntries(new URLSearchParams(原始请求体));
                            }
                            const 地区代码 = String(请求体.region || 请求体.code || url.searchParams.get('region') || '').trim().toUpperCase();
                            const 拉取结果 = await 获取地区节点文本(地区代码, env);
                            if (!拉取结果.text)
                                return new Response(JSON.stringify({ success: false, error: '没有拉取到该地区节点' }), { status: 404, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                            await env.KV.put('ADD.txt', 拉取结果.text);
                            if (!config_JSON.优选订阅生成)
                                config_JSON.优选订阅生成 = {};
                            if (!config_JSON.优选订阅生成.本地IP库)
                                config_JSON.优选订阅生成.本地IP库 = {};
                            config_JSON.优选订阅生成.local = true;
                            config_JSON.优选订阅生成.本地IP库.随机IP = false;
                            await env.KV.put('config.json', JSON.stringify(config_JSON, null, 2));
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Save_Region_IPs', config_JSON));
                            return new Response(JSON.stringify({ success: true, region: 地区代码, count: 拉取结果.count, message: `已写入 ${拉取结果.count} 个节点到 ADD.txt`, preview: 拉取结果.text.split('\n').slice(0, 10) }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        }
                        catch (error) {
                            return new Response(JSON.stringify({ success: false, error: error.message || String(error) }), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                        }
                    }
                    else if (访问路径 === 'admin/sub-links') {
                        const 订阅TOKEN = await MD5MD5(host + userID);
                        const 源 = url.protocol + '//' + url.host;
                        return new Response(JSON.stringify({ success: true, adaptive: `${源}/sub?token=${订阅TOKEN}`, v2ray: `${源}/sub?target=mixed&token=${订阅TOKEN}`, clash: `${源}/sub?target=clash&token=${订阅TOKEN}`, singbox: `${源}/sub?target=singbox&token=${订阅TOKEN}` }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8', 'Cache-Control': 'no-store' } });
                    }
                    else if (访问路径 === 'admin/init') {
                        try {
                            config_JSON = await 读取config_JSON(env, host, userID, UA, true);
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Init_Config', config_JSON));
                            config_JSON.init = '配置已重置为默认值';
                            return new Response(JSON.stringify(config_JSON, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                        }
                        catch (err) {
                            const errorResponse = { msg: '配置重置失败，失败原因：' + err.message, error: err.message };
                            return new Response(JSON.stringify(errorResponse, null, 2), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                        }
                    }
                    else if (request.method === 'POST') {
                        if (访问路径 === 'admin/config.json') {
                            try {
                                const newConfig = await request.json();
                                if (!newConfig.UUID || !newConfig.HOST)
                                    return new Response(JSON.stringify({ error: '配置不完整' }), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                                await env.KV.put('config.json', JSON.stringify(newConfig, null, 2));
                                ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Save_Config', config_JSON));
                                return new Response(JSON.stringify({ success: true, message: '配置已保存' }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                            catch (error) {
                                console.error('保存配置失败:', error);
                                return new Response(JSON.stringify({ error: '保存配置失败: ' + error.message }), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                        }
                        else if (访问路径 === 'admin/cf.json') {
                            try {
                                const newConfig = await request.json();
                                const CF_JSON = { Email: null, GlobalAPIKey: null, AccountID: null, APIToken: null, UsageAPI: null };
                                if (!newConfig.init || newConfig.init !== true) {
                                    if (newConfig.Email && newConfig.GlobalAPIKey) {
                                        CF_JSON.Email = newConfig.Email;
                                        CF_JSON.GlobalAPIKey = newConfig.GlobalAPIKey;
                                    }
                                    else if (newConfig.AccountID && newConfig.APIToken) {
                                        CF_JSON.AccountID = newConfig.AccountID;
                                        CF_JSON.APIToken = newConfig.APIToken;
                                    }
                                    else if (newConfig.UsageAPI) {
                                        CF_JSON.UsageAPI = newConfig.UsageAPI;
                                    }
                                    else {
                                        return new Response(JSON.stringify({ error: '配置不完整' }), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                                    }
                                }
                                await env.KV.put('cf.json', JSON.stringify(CF_JSON, null, 2));
                                ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Save_Config', config_JSON));
                                return new Response(JSON.stringify({ success: true, message: '配置已保存' }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                            catch (error) {
                                console.error('保存配置失败:', error);
                                return new Response(JSON.stringify({ error: '保存配置失败: ' + error.message }), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                        }
                        else if (访问路径 === 'admin/tg.json') {
                            try {
                                const newConfig = await request.json();
                                if (newConfig.init && newConfig.init === true) {
                                    const TG_JSON = { BotToken: null, ChatID: null };
                                    await env.KV.put('tg.json', JSON.stringify(TG_JSON, null, 2));
                                }
                                else {
                                    if (!newConfig.BotToken || !newConfig.ChatID)
                                        return new Response(JSON.stringify({ error: '配置不完整' }), { status: 400, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                                    await env.KV.put('tg.json', JSON.stringify(newConfig, null, 2));
                                }
                                ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Save_Config', config_JSON));
                                return new Response(JSON.stringify({ success: true, message: '配置已保存' }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                            catch (error) {
                                console.error('保存配置失败:', error);
                                return new Response(JSON.stringify({ error: '保存配置失败: ' + error.message }), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                        }
                        else if (区分大小写访问路径 === 'admin/ADD.txt') {
                            try {
                                const customIPs = await request.text();
                                await env.KV.put('ADD.txt', customIPs);
                                ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Save_Custom_IPs', config_JSON));
                                return new Response(JSON.stringify({ success: true, message: '自定义IP已保存' }), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                            catch (error) {
                                console.error('保存自定义IP失败:', error);
                                return new Response(JSON.stringify({ error: '保存自定义IP失败: ' + error.message }), { status: 500, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                            }
                        }
                        else
                            return new Response(JSON.stringify({ error: '不支持的POST请求路径' }), { status: 404, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                    }
                    else if (访问路径 === 'admin/config.json') {
                        return new Response(JSON.stringify(config_JSON, null, 2), { status: 200, headers: { 'Content-Type': 'application/json' } });
                    }
                    else if (区分大小写访问路径 === 'admin/ADD.txt') {
                        let 本地优选IP = await env.KV.get('ADD.txt') || 'null';
                        if (本地优选IP == 'null')
                            本地优选IP = (await 生成随机IP(request, config_JSON.优选订阅生成.本地IP库.随机数量, config_JSON.优选订阅生成.本地IP库.指定端口, (config_JSON.协议类型 === 'ss' ? config_JSON.SS.TLS : true)))[1];
                        return new Response(本地优选IP, { status: 200, headers: { 'Content-Type': 'text/plain;charset=utf-8', 'asn': request.cf.asn } });
                    }
                    else if (访问路径 === 'admin/cf.json') {
                        return new Response(JSON.stringify(request.cf, null, 2), { status: 200, headers: { 'Content-Type': 'application/json;charset=utf-8' } });
                    }
                    ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Admin_Login', config_JSON));
                    return fetch(Pages静态页面 + '/admin' + url.search);
                }
                else if (访问路径 === 'logout' || uuidRegex.test(访问路径)) {
                    const 响应 = new Response('重定向中...', { status: 302, headers: { 'Location': '/' + 登录路径 } });
                    响应.headers.set('Set-Cookie', 'auth=; Path=/; Max-Age=0; HttpOnly');
                    return 响应;
                }
                else if (访问路径 === 'sub') {
                    const 订阅TOKEN = await MD5MD5(host + userID), 作为优选订阅生成器 = ['1', 'true'].includes(env.BEST_SUB) && url.searchParams.get('host') === 'example.com' && url.searchParams.get('uuid') === '00000000-0000-4000-8000-000000000000' && UA.toLowerCase().includes('tunnel (https://github.com/cmliu/edge');
                    const 请求TOKEN = url.searchParams.get('token');
                    const 用户客户端请求订阅 = 请求TOKEN === 订阅TOKEN;
                    const 当前日序号 = Math.floor(Date.now() / 86400000);
                    const 订阅转换后端TOKEN种子 = base64SecretEncode(订阅TOKEN, userID);
                    const [今日订阅转换后端专属TOKEN, 昨日订阅转换后端专属TOKEN] = await Promise.all([
                        MD5MD5(订阅转换后端TOKEN种子 + 当前日序号),
                        MD5MD5(订阅转换后端TOKEN种子 + (当前日序号 - 1)),
                    ]);
                    const 订阅转换后端请求订阅 = 请求TOKEN === 今日订阅转换后端专属TOKEN || 请求TOKEN === 昨日订阅转换后端专属TOKEN;
                    if (用户客户端请求订阅 || 订阅转换后端请求订阅 || 作为优选订阅生成器) {
                        config_JSON = await 读取config_JSON(env, host, userID, UA);
                        if (作为优选订阅生成器)
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Get_Best_SUB', config_JSON, false));
                        else
                            ctx.waitUntil(请求日志记录(env, request, 访问IP, 'Get_SUB', config_JSON));
                        const ua = UA.toLowerCase();
                        const responseHeaders = {
                            "content-type": "text/plain; charset=utf-8",
                            "Profile-Update-Interval": config_JSON.优选订阅生成.SUBUpdateTime,
                            "Profile-web-page-url": url.protocol + '//' + url.host + '/admin',
                            "Cache-Control": "no-store",
                        };
                        if (config_JSON.CF.Usage.success) {
                            const pagesSum = config_JSON.CF.Usage.pages;
                            const workersSum = config_JSON.CF.Usage.workers;
                            const total = Number.isFinite(config_JSON.CF.Usage.max) ? (config_JSON.CF.Usage.max / 1000) * 1024 : 1024 * 100;
                            responseHeaders["Subscription-Userinfo"] = `upload=${pagesSum}; download=${workersSum}; total=${total}; expire=4102329600`;
                        }
                        const isSubConverterRequest = url.searchParams.has('b64') || url.searchParams.has('base64') || request.headers.get('subconverter-request') || request.headers.get('subconverter-version') || ua.includes('subconverter') || ua.includes(('CF-Workers-SUB').toLowerCase()) || 作为优选订阅生成器;
                        const 订阅类型 = isSubConverterRequest
                            ? 'mixed'
                            : url.searchParams.has('target')
                                ? url.searchParams.get('target')
                                : url.searchParams.has('clash') || ua.includes('clash') || ua.includes('meta') || ua.includes('mihomo')
                                    ? 'clash'
                                    : url.searchParams.has('sb') || url.searchParams.has('singbox') || ua.includes('singbox') || ua.includes('sing-box')
                                        ? 'singbox'
                                        : url.searchParams.has('surge') || ua.includes('surge')
                                            ? 'surge&ver=4'
                                            : url.searchParams.has('quanx') || ua.includes('quantumult')
                                                ? 'quanx'
                                                : url.searchParams.has('loon') || ua.includes('loon')
                                                    ? 'loon'
                                                    : 'mixed';
                        if (!ua.includes('mozilla'))
                            responseHeaders["Content-Disposition"] = `attachment; filename*=utf-8''${encodeURIComponent(config_JSON.优选订阅生成.SUBNAME)}`;
                        const 协议类型 = ((url.searchParams.has('surge') || ua.includes('surge')) && config_JSON.协议类型 !== 'ss') ? 'tro' + 'jan' : config_JSON.协议类型;
                        let 订阅内容 = '';
                        if (订阅类型 === 'mixed') {
                            const TLS分片参数 = config_JSON.TLS分片 == 'Shadowrocket' ? `&fragment=${encodeURIComponent('1,40-60,30-50,tlshello')}` : config_JSON.TLS分片 == 'Happ' ? `&fragment=${encodeURIComponent('3,1,tlshello')}` : '';
                            let 完整优选IP = [], 其他节点LINK = '', 反代IP池 = [];
                            if (!url.searchParams.has('sub') && config_JSON.优选订阅生成.local) {
                                const 完整优选列表 = config_JSON.优选订阅生成.本地IP库.随机IP ? (await 生成随机IP(request, config_JSON.优选订阅生成.本地IP库.随机数量, config_JSON.优选订阅生成.本地IP库.指定端口, (协议类型 === 'ss' ? config_JSON.SS.TLS : true)))[0] : await env.KV.get('ADD.txt') ? await 整理成数组(await env.KV.get('ADD.txt')) : (await 生成随机IP(request, config_JSON.优选订阅生成.本地IP库.随机数量, config_JSON.优选订阅生成.本地IP库.指定端口, (协议类型 === 'ss' ? config_JSON.SS.TLS : true)))[0];
                                const 优选API = [], 优选IP = [], 其他节点 = [];
                                for (const 元素 of 完整优选列表) {
                                    if (元素.toLowerCase().startsWith('sub://')) {
                                        优选API.push(元素);
                                    }
                                    else {
                                        const 备注位置 = 元素.indexOf('#');
                                        const 地址部分 = 备注位置 > -1 ? 元素.slice(0, 备注位置) : 元素;
                                        const 备注部分 = 备注位置 > -1 ? 元素.slice(备注位置) : '';
                                        const subMatch = 元素.match(/sub\s*=\s*([^\s&#]+)/i);
                                        if (subMatch && subMatch[1].trim().includes('.')) {
                                            const 优选IP作为反代IP = 元素.toLowerCase().includes('proxyip=true');
                                            if (优选IP作为反代IP)
                                                优选API.push('sub://' + subMatch[1].trim() + "?proxyip=true" + (元素.includes('#') ? ('#' + 元素.split('#')[1]) : ''));
                                            else
                                                优选API.push('sub://' + subMatch[1].trim() + (元素.includes('#') ? ('#' + 元素.split('#')[1]) : ''));
                                        }
                                        else if (地址部分.toLowerCase().startsWith('https://')) {
                                            优选API.push(元素);
                                        }
                                        else if (地址部分.toLowerCase().includes('://')) {
                                            if (元素.includes('#')) {
                                                const 地址备注分离 = 元素.split('#');
                                                其他节点.push(地址备注分离[0] + '#' + encodeURIComponent(decodeURIComponent(地址备注分离[1])));
                                            }
                                            else
                                                其他节点.push(元素);
                                        }
                                        else {
                                            if (地址部分.includes('*')) {
                                                优选IP.push(替换星号为随机字符(地址部分) + 备注部分);
                                            }
                                            else
                                                优选IP.push(元素);
                                        }
                                    }
                                }
                                const 请求优选API内容 = await 请求优选API(优选API, (协议类型 === 'ss' && !config_JSON.SS.TLS) ? '80' : '443');
                                const 合并其他节点数组 = [...new Set(其他节点.concat(请求优选API内容[1]))];
                                其他节点LINK = 合并其他节点数组.length > 0 ? 合并其他节点数组.join('\n') + '\n' : '';
                                const 优选API的IP = 请求优选API内容[0];
                                反代IP池 = 请求优选API内容[3] || [];
                                完整优选IP = [...new Set(优选IP.concat(优选API的IP))];
                            }
                            else {
                                let 优选订阅生成器HOST = url.searchParams.get('sub') || config_JSON.优选订阅生成.SUB;
                                const [优选生成器IP数组, 优选生成器其他节点] = await 获取优选订阅生成器数据(优选订阅生成器HOST);
                                完整优选IP = 完整优选IP.concat(优选生成器IP数组);
                                其他节点LINK += 优选生成器其他节点;
                            }
                            const ECHLINK参数 = config_JSON.ECH ? `&ech=${encodeURIComponent((config_JSON.ECHConfig.SNI ? config_JSON.ECHConfig.SNI + '+' : '') + config_JSON.ECHConfig.DNS)}` : '';
                            const isLoonOrSurge = ua.includes('loon') || ua.includes('surge');
                            const { type: 传输协议, 路径字段名, 域名字段名 } = 获取传输协议配置(config_JSON);
                            订阅内容 = 其他节点LINK + 完整优选IP.map(原始地址 => {
                                const regex = /^(\[[\da-fA-F:]+\]|[\d.]+|[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*)(?::(\d+))?(?:#(.+))?$/;
                                const match = 原始地址.match(regex);
                                let 节点地址, 节点端口 = "443", 节点备注;
                                if (match) {
                                    节点地址 = match[1];
                                    节点端口 = match[2] ? match[2] : (协议类型 === 'ss' && !config_JSON.SS.TLS) ? '80' : '443';
                                    节点备注 = match[3] || 节点地址;
                                }
                                else {
                                    console.warn(`[订阅内容] 不规范的IP格式已忽略: ${原始地址}`);
                                    return null;
                                }
                                let 完整节点路径 = config_JSON.完整节点路径;
                                const 链式代理匹配 = 节点备注.match(/\$(socks5|http|https|turn|sstp):\/\/([^#\s]+)/i);
                                if (链式代理匹配) {
                                    try {
                                        const 代理协议 = 链式代理匹配[1].toLowerCase(), 代理参数 = 链式代理匹配[2];
                                        const 链式代理数据 = { type: 代理协议, ...获取SOCKS5账号(代理参数, 获取代理默认端口(代理协议)) };
                                        完整节点路径 = `/video/${base64SecretEncode(JSON.stringify(链式代理数据), userID) + (config_JSON.启用0RTT ? '?ed=2560' : '')}`;
                                        节点备注 = 节点备注.replace(链式代理匹配[0], '').trim() || 节点地址;
                                    }
                                    catch (error) {
                                        console.warn(`[订阅内容] 链式代理解析失败，已忽略该指令: ${链式代理匹配[0]} (${error && error.message ? error.message : error})`);
                                    }
                                }
                                else if (反代IP池.length > 0) {
                                    const 匹配到的反代IP = 反代IP池.find(p => p.includes(节点地址));
                                    if (匹配到的反代IP)
                                        完整节点路径 = (`${config_JSON.PATH}/proxyip=${匹配到的反代IP}`).replace(/\/\//g, '/') + (config_JSON.启用0RTT ? '?ed=2560' : '');
                                }
                                if (isLoonOrSurge)
                                    完整节点路径 = 完整节点路径.replace(/,/g, '%2C');
                                if (协议类型 === 'ss' && !作为优选订阅生成器) {
                                    完整节点路径 = (完整节点路径.includes('?') ? 完整节点路径.replace('?', '?enc=' + config_JSON.SS.加密方式 + '&') : (完整节点路径 + '?enc=' + config_JSON.SS.加密方式)).replace(/([=,])/g, '\\$1');
                                    if (!isSubConverterRequest)
                                        完整节点路径 = 完整节点路径 + ';mux=0';
                                    return `${协议类型}://${btoa(config_JSON.SS.加密方式 + ':00000000-0000-4000-8000-000000000000')}@${节点地址}:${节点端口}?plugin=v2${encodeURIComponent('ray-plugin;mode=websocket;host=example.com;path=' + (config_JSON.随机路径 ? 随机路径(完整节点路径) : 完整节点路径) + (config_JSON.SS.TLS ? ';tls' : '')) + ECHLINK参数 + TLS分片参数}#${encodeURIComponent(节点备注)}`;
                                }
                                else {
                                    const 传输路径参数值 = 获取传输路径参数值(config_JSON, 完整节点路径, 作为优选订阅生成器);
                                    return `${协议类型}://00000000-0000-4000-8000-000000000000@${节点地址}:${节点端口}?security=tls&type=${传输协议 + ECHLINK参数}&${域名字段名}=example.com&fp=${config_JSON.Fingerprint}&sni=example.com&${路径字段名}=${encodeURIComponent(传输路径参数值) + TLS分片参数}&encryption=none${config_JSON.跳过证书验证 ? '&insecure=1&allowInsecure=1' : ''}#${encodeURIComponent(节点备注)}`;
                                }
                            }).filter(item => item !== null).join('\n');
                        }
                        else {
                            const 订阅转换URL = `${config_JSON.订阅转换配置.SUBAPI}/sub?target=${订阅类型}&url=${encodeURIComponent(url.protocol + '//' + url.host + '/sub?target=mixed&token=' + 今日订阅转换后端专属TOKEN + '&asOrg=' + 识别运营商(request) + (url.searchParams.has('sub') && url.searchParams.get('sub') != '' ? `&sub=${url.searchParams.get('sub')}` : ''))}&config=${encodeURIComponent(config_JSON.订阅转换配置.SUBCONFIG)}&emoji=${config_JSON.订阅转换配置.SUBEMOJI}&scv=${config_JSON.跳过证书验证}`;
                            try {
                                const response = await fetch(订阅转换URL, { headers: { 'User-Agent': 'Subconverter for ' + 订阅类型 + ' edge' + 'tunnel (https://github.com/cmliu/edge' + 'tunnel)' } });
                                if (response.ok) {
                                    订阅内容 = await response.text();
                                    if (url.searchParams.has('surge') || ua.includes('surge'))
                                        订阅内容 = Surge订阅配置文件热补丁(订阅内容, url.protocol + '//' + url.host + '/sub?token=' + 订阅TOKEN + '&surge', config_JSON);
                                }
                                else
                                    return new Response('订阅转换后端异常：' + response.statusText, { status: response.status });
                            }
                            catch (error) {
                                return new Response('订阅转换后端异常：' + error.message, { status: 403 });
                            }
                        }
                        if (!ua.includes('subconverter') && 用户客户端请求订阅) {
                            const 打乱后HOSTS = [...config_JSON.HOSTS].sort(() => Math.random() - 0.5);
                            let 替换域名计数 = 0, 当前随机HOST = null;
                            订阅内容 = 订阅内容
                                .replace(/00000000-0000-4000-8000-000000000000/g, config_JSON.UUID)
                                .replace(/MDAwMDAwMDAtMDAwMC00MDAwLTgwMDAtMDAwMDAwMDAwMDAw/g, btoa(config_JSON.UUID))
                                .replace(/example\.com/g, () => {
                                if (替换域名计数 % 2 === 0) {
                                    const 原始host = 打乱后HOSTS[Math.floor(替换域名计数 / 2) % 打乱后HOSTS.length];
                                    当前随机HOST = 替换星号为随机字符(原始host);
                                }
                                替换域名计数++;
                                return 当前随机HOST;
                            });
                        }
                        if (订阅类型 === 'mixed' && (!ua.includes('mozilla') || url.searchParams.has('b64') || url.searchParams.has('base64')))
                            订阅内容 = btoa(订阅内容);
                        if (订阅类型 === 'singbox') {
                            订阅内容 = await Singbox订阅配置文件热补丁(订阅内容, config_JSON);
                            responseHeaders["content-type"] = 'application/json; charset=utf-8';
                        }
                        else if (订阅类型 === 'clash') {
                            订阅内容 = Clash订阅配置文件热补丁(订阅内容, config_JSON);
                            responseHeaders["content-type"] = 'application/x-yaml; charset=utf-8';
                        }
                        return new Response(订阅内容, { status: 200, headers: responseHeaders });
                    }
                }
                else if (访问路径 === 'locations') {
                    const cookies = request.headers.get('Cookie') || '';
                    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1];
                    if (authCookie && authCookie == await MD5MD5(UA + 加密秘钥 + 管理员密码))
                        return fetch(new Request('https://speed.cloudflare.com/locations', { headers: { 'Referer': 'https://speed.cloudflare.com/' } }));
                }
                else if (访问路径 === 'robots.txt')
                    return new Response('User-agent: *\nDisallow: /', { status: 200, headers: { 'Content-Type': 'text/plain; charset=UTF-8' } });
            }
            else if (!envUUID)
                return fetch(Pages静态页面 + '/noKV').then(r => { const headers = new Headers(r.headers); headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate'); headers.set('Pragma', 'no-cache'); headers.set('Expires', '0'); return new Response(r.body, { status: 404, statusText: r.statusText, headers }); });
        }
        let 伪装页URL = env.URL || 'nginx';
        if (伪装页URL && 伪装页URL !== 'nginx' && 伪装页URL !== '1101') {
            伪装页URL = 伪装页URL.trim().replace(/\/$/, '');
            if (!伪装页URL.match(/^https?:\/\//i))
                伪装页URL = 'https://' + 伪装页URL;
            if (伪装页URL.toLowerCase().startsWith('http://'))
                伪装页URL = 'https://' + 伪装页URL.substring(7);
            try {
                const u = new URL(伪装页URL);
                伪装页URL = u.protocol + '//' + u.host;
            }
            catch (e) {
                伪装页URL = 'nginx';
            }
        }
        if (伪装页URL === '1101')
            return new Response(await html1101(url.host, 访问IP), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8' } });
        try {
            const 反代URL = new URL(伪装页URL), 新请求头 = new Headers(request.headers);
            新请求头.set('Host', 反代URL.host);
            新请求头.set('Referer', 反代URL.origin);
            新请求头.set('Origin', 反代URL.origin);
            if (!新请求头.has('User-Agent') && UA && UA !== 'null')
                新请求头.set('User-Agent', UA);
            const 反代响应 = await fetch(反代URL.origin + url.pathname + url.search, { method: request.method, headers: 新请求头, body: request.body, cf: request.cf });
            const 内容类型 = 反代响应.headers.get('content-type') || '';
            if (/text|javascript|json|xml/.test(内容类型)) {
                const 响应内容 = (await 反代响应.text()).replaceAll(反代URL.host, url.host);
                return new Response(响应内容, { status: 反代响应.status, headers: { ...Object.fromEntries(反代响应.headers), 'Cache-Control': 'no-store' } });
            }
            return 反代响应;
        }
        catch (error) { }
        return new Response(await nginx(), { status: 200, headers: { 'Content-Type': 'text/html; charset=UTF-8' } });
    }
};
async function 处理XHTTP请求(request, yourUUID) {
    if (!request.body)
        return new Response('Bad Request', { status: 400 });
    const reader = request.body.getReader();
    const 首包 = await 读取XHTTP首包(reader, yourUUID);
    if (!首包) {
        try {
            reader.releaseLock();
        }
        catch (e) { }
        return new Response('Invalid request', { status: 400 });
    }
    if (isSpeedTestSite(首包.hostname)) {
        try {
            reader.releaseLock();
        }
        catch (e) { }
        return new Response('Forbidden', { status: 403 });
    }
    if (首包.isUDP && 首包.协议 !== 'trojan' && 首包.port !== 53) {
        try {
            reader.releaseLock();
        }
        catch (e) { }
        return new Response('UDP is not supported', { status: 400 });
    }
    const remoteConnWrapper = { socket: null, connectingPromise: null, retryConnect: null };
    let 当前写入Socket = null;
    let 远端写入器 = null;
    const responseHeaders = new Headers({
        'Content-Type': 'application/octet-stream',
        'X-Accel-Buffering': 'no',
        'Cache-Control': 'no-store'
    });
    const 释放远端写入器 = () => {
        if (远端写入器) {
            try {
                远端写入器.releaseLock();
            }
            catch (e) { }
            远端写入器 = null;
        }
        当前写入Socket = null;
    };
    const 获取远端写入器 = () => {
        const socket = remoteConnWrapper.socket;
        if (!socket)
            return null;
        if (socket !== 当前写入Socket) {
            释放远端写入器();
            当前写入Socket = socket;
            远端写入器 = socket.writable.getWriter();
        }
        return 远端写入器;
    };
    return new Response(new ReadableStream({
        async start(controller) {
            let 已关闭 = false;
            let udpRespHeader = 首包.respHeader;
            const 木马UDP上下文 = { 缓存: new Uint8Array(0) };
            const xhttpBridge = {
                readyState: WebSocket.OPEN,
                send(data) {
                    if (已关闭)
                        return;
                    try {
                        const chunk = data instanceof Uint8Array
                            ? data
                            : data instanceof ArrayBuffer
                                ? new Uint8Array(data)
                                : ArrayBuffer.isView(data)
                                    ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
                                    : new Uint8Array(data);
                        controller.enqueue(chunk);
                    }
                    catch (e) {
                        已关闭 = true;
                        this.readyState = WebSocket.CLOSED;
                    }
                },
                close() {
                    if (已关闭)
                        return;
                    已关闭 = true;
                    this.readyState = WebSocket.CLOSED;
                    try {
                        controller.close();
                    }
                    catch (e) { }
                }
            };
            const 写入远端 = async (payload, allowRetry = true) => {
                const writer = 获取远端写入器();
                if (!writer)
                    return false;
                try {
                    await writer.write(payload);
                    return true;
                }
                catch (err) {
                    释放远端写入器();
                    if (allowRetry && typeof remoteConnWrapper.retryConnect === 'function') {
                        await remoteConnWrapper.retryConnect();
                        return await 写入远端(payload, false);
                    }
                    throw err;
                }
            };
            try {
                if (首包.isUDP) {
                    if (首包.rawData?.byteLength) {
                        if (首包.协议 === 'trojan')
                            await 转发木马UDP数据(首包.rawData, xhttpBridge, 木马UDP上下文);
                        else
                            await forwardataudp(首包.rawData, xhttpBridge, udpRespHeader);
                        udpRespHeader = null;
                    }
                }
                else {
                    await forwardataTCP(首包.hostname, 首包.port, 首包.rawData, xhttpBridge, 首包.respHeader, remoteConnWrapper, yourUUID);
                }
                while (true) {
                    const { done, value } = await reader.read();
                    if (done)
                        break;
                    if (!value || value.byteLength === 0)
                        continue;
                    if (首包.isUDP) {
                        if (首包.协议 === 'trojan')
                            await 转发木马UDP数据(value, xhttpBridge, 木马UDP上下文);
                        else
                            await forwardataudp(value, xhttpBridge, udpRespHeader);
                        udpRespHeader = null;
                    }
                    else {
                        if (!(await 写入远端(value)))
                            throw new Error('Remote socket is not ready');
                    }
                }
                if (!首包.isUDP) {
                    const writer = 获取远端写入器();
                    if (writer) {
                        try {
                            await writer.close();
                        }
                        catch (e) { }
                    }
                }
            }
            catch (err) {
                log(`[XHTTP转发] 处理失败: ${err?.message || err}`);
                closeSocketQuietly(xhttpBridge);
            }
            finally {
                释放远端写入器();
                try {
                    reader.releaseLock();
                }
                catch (e) { }
            }
        },
        cancel() {
            释放远端写入器();
            try {
                remoteConnWrapper.socket?.close();
            }
            catch (e) { }
            try {
                reader.releaseLock();
            }
            catch (e) { }
        }
    }), { status: 200, headers: responseHeaders });
}
function 有效数据长度(data) {
    if (!data)
        return 0;
    if (typeof data.byteLength === 'number')
        return data.byteLength;
    if (typeof data.length === 'number')
        return data.length;
    return 0;
}
async function 读取XHTTP首包(reader, token) {
    const decoder = new TextDecoder();
    const 尝试解析魏烈思首包 = (data) => {
        const length = data.byteLength;
        if (length < 18)
            return { 状态: 'need_more' };
        if (formatIdentifier(data.subarray(1, 17)) !== token)
            return { 状态: 'invalid' };
        const optLen = data[17];
        const cmdIndex = 18 + optLen;
        if (length < cmdIndex + 1)
            return { 状态: 'need_more' };
        const cmd = data[cmdIndex];
        if (cmd !== 1 && cmd !== 2)
            return { 状态: 'invalid' };
        const portIndex = cmdIndex + 1;
        if (length < portIndex + 3)
            return { 状态: 'need_more' };
        const port = (data[portIndex] << 8) | data[portIndex + 1];
        const addressType = data[portIndex + 2];
        const addressIndex = portIndex + 3;
        let headerLen = -1;
        let hostname = '';
        if (addressType === 1) {
            if (length < addressIndex + 4)
                return { 状态: 'need_more' };
            hostname = `${data[addressIndex]}.${data[addressIndex + 1]}.${data[addressIndex + 2]}.${data[addressIndex + 3]}`;
            headerLen = addressIndex + 4;
        }
        else if (addressType === 2) {
            if (length < addressIndex + 1)
                return { 状态: 'need_more' };
            const domainLen = data[addressIndex];
            if (length < addressIndex + 1 + domainLen)
                return { 状态: 'need_more' };
            hostname = decoder.decode(data.subarray(addressIndex + 1, addressIndex + 1 + domainLen));
            headerLen = addressIndex + 1 + domainLen;
        }
        else if (addressType === 3) {
            if (length < addressIndex + 16)
                return { 状态: 'need_more' };
            const ipv6 = [];
            for (let i = 0; i < 8; i++) {
                const base = addressIndex + i * 2;
                ipv6.push(((data[base] << 8) | data[base + 1]).toString(16));
            }
            hostname = ipv6.join(':');
            headerLen = addressIndex + 16;
        }
        else
            return { 状态: 'invalid' };
        if (!hostname)
            return { 状态: 'invalid' };
        return {
            状态: 'ok',
            结果: {
                协议: 'vl' + 'ess',
                hostname,
                port,
                isUDP: cmd === 2,
                rawData: data.subarray(headerLen),
                respHeader: new Uint8Array([data[0], 0]),
            }
        };
    };
    const 尝试解析木马首包 = (data) => {
        const 密码哈希 = sha224(token);
        const 密码哈希字节 = new TextEncoder().encode(密码哈希);
        const length = data.byteLength;
        if (length < 58)
            return { 状态: 'need_more' };
        if (data[56] !== 0x0d || data[57] !== 0x0a)
            return { 状态: 'invalid' };
        for (let i = 0; i < 56; i++) {
            if (data[i] !== 密码哈希字节[i])
                return { 状态: 'invalid' };
        }
        const socksStart = 58;
        if (length < socksStart + 2)
            return { 状态: 'need_more' };
        const cmd = data[socksStart];
        if (cmd !== 1 && cmd !== 3)
            return { 状态: 'invalid' };
        const isUDP = cmd === 3;
        const atype = data[socksStart + 1];
        let cursor = socksStart + 2;
        let hostname = '';
        if (atype === 1) {
            if (length < cursor + 4)
                return { 状态: 'need_more' };
            hostname = `${data[cursor]}.${data[cursor + 1]}.${data[cursor + 2]}.${data[cursor + 3]}`;
            cursor += 4;
        }
        else if (atype === 3) {
            if (length < cursor + 1)
                return { 状态: 'need_more' };
            const domainLen = data[cursor];
            if (length < cursor + 1 + domainLen)
                return { 状态: 'need_more' };
            hostname = decoder.decode(data.subarray(cursor + 1, cursor + 1 + domainLen));
            cursor += 1 + domainLen;
        }
        else if (atype === 4) {
            if (length < cursor + 16)
                return { 状态: 'need_more' };
            const ipv6 = [];
            for (let i = 0; i < 8; i++) {
                const base = cursor + i * 2;
                ipv6.push(((data[base] << 8) | data[base + 1]).toString(16));
            }
            hostname = ipv6.join(':');
            cursor += 16;
        }
        else
            return { 状态: 'invalid' };
        if (!hostname)
            return { 状态: 'invalid' };
        if (length < cursor + 4)
            return { 状态: 'need_more' };
        const port = (data[cursor] << 8) | data[cursor + 1];
        if (data[cursor + 2] !== 0x0d || data[cursor + 3] !== 0x0a)
            return { 状态: 'invalid' };
        const dataOffset = cursor + 4;
        return {
            状态: 'ok',
            结果: {
                协议: 'trojan',
                hostname,
                port,
                isUDP,
                rawData: data.subarray(dataOffset),
                respHeader: null,
            }
        };
    };
    let buffer = new Uint8Array(1024);
    let offset = 0;
    while (true) {
        const { value, done } = await reader.read();
        if (done) {
            if (offset === 0)
                return null;
            break;
        }
        const chunk = value instanceof Uint8Array ? value : new Uint8Array(value);
        if (offset + chunk.byteLength > buffer.byteLength) {
            const newBuffer = new Uint8Array(Math.max(buffer.byteLength * 2, offset + chunk.byteLength));
            newBuffer.set(buffer.subarray(0, offset));
            buffer = newBuffer;
        }
        buffer.set(chunk, offset);
        offset += chunk.byteLength;
        const 当前数据 = buffer.subarray(0, offset);
        const 木马结果 = 尝试解析木马首包(当前数据);
        if (木马结果.状态 === 'ok')
            return { ...木马结果.结果, reader };
        const 魏烈思结果 = 尝试解析魏烈思首包(当前数据);
        if (魏烈思结果.状态 === 'ok')
            return { ...魏烈思结果.结果, reader };
        if (木马结果.状态 === 'invalid' && 魏烈思结果.状态 === 'invalid')
            return null;
    }
    const 最终数据 = buffer.subarray(0, offset);
    const 最终木马结果 = 尝试解析木马首包(最终数据);
    if (最终木马结果.状态 === 'ok')
        return { ...最终木马结果.结果, reader };
    const 最终魏烈思结果 = 尝试解析魏烈思首包(最终数据);
    if (最终魏烈思结果.状态 === 'ok')
        return { ...最终魏烈思结果.结果, reader };
    return null;
}
async function 处理gRPC请求(request, yourUUID) {
    if (!request.body)
        return new Response('Bad Request', { status: 400 });
    const reader = request.body.getReader();
    const remoteConnWrapper = { socket: null, connectingPromise: null, retryConnect: null };
    let isDnsQuery = false;
    const 木马UDP上下文 = { 缓存: new Uint8Array(0) };
    let 判断是否是木马 = null;
    let 当前写入Socket = null;
    let 远端写入器 = null;
    const grpcHeaders = new Headers({
        'Content-Type': 'application/grpc',
        'grpc-status': '0',
        'X-Accel-Buffering': 'no',
        'Cache-Control': 'no-store'
    });
    const 下行缓存上限 = 64 * 1024;
    const 下行刷新间隔 = 20;
    return new Response(new ReadableStream({
        async start(controller) {
            let 已关闭 = false;
            let 发送队列 = [];
            let 队列字节数 = 0;
            let 刷新定时器 = null;
            const grpcBridge = {
                readyState: WebSocket.OPEN,
                send(data) {
                    if (已关闭)
                        return;
                    const chunk = data instanceof Uint8Array ? data : new Uint8Array(data);
                    const lenBytes数组 = [];
                    let remaining = chunk.byteLength >>> 0;
                    while (remaining > 127) {
                        lenBytes数组.push((remaining & 0x7f) | 0x80);
                        remaining >>>= 7;
                    }
                    lenBytes数组.push(remaining);
                    const lenBytes = new Uint8Array(lenBytes数组);
                    const protobufLen = 1 + lenBytes.length + chunk.byteLength;
                    const frame = new Uint8Array(5 + protobufLen);
                    frame[0] = 0;
                    frame[1] = (protobufLen >>> 24) & 0xff;
                    frame[2] = (protobufLen >>> 16) & 0xff;
                    frame[3] = (protobufLen >>> 8) & 0xff;
                    frame[4] = protobufLen & 0xff;
                    frame[5] = 0x0a;
                    frame.set(lenBytes, 6);
                    frame.set(chunk, 6 + lenBytes.length);
                    发送队列.push(frame);
                    队列字节数 += frame.byteLength;
                    if (队列字节数 >= 下行缓存上限)
                        刷新发送队列();
                    else if (!刷新定时器)
                        刷新定时器 = setTimeout(刷新发送队列, 下行刷新间隔);
                },
                close() {
                    if (this.readyState === WebSocket.CLOSED)
                        return;
                    刷新发送队列(true);
                    已关闭 = true;
                    this.readyState = WebSocket.CLOSED;
                    try {
                        controller.close();
                    }
                    catch (e) { }
                }
            };
            const 刷新发送队列 = (force = false) => {
                if (刷新定时器) {
                    clearTimeout(刷新定时器);
                    刷新定时器 = null;
                }
                if ((!force && 已关闭) || 队列字节数 === 0)
                    return;
                const out = new Uint8Array(队列字节数);
                let offset = 0;
                for (const item of 发送队列) {
                    out.set(item, offset);
                    offset += item.byteLength;
                }
                发送队列 = [];
                队列字节数 = 0;
                try {
                    controller.enqueue(out);
                }
                catch (e) {
                    已关闭 = true;
                    grpcBridge.readyState = WebSocket.CLOSED;
                }
            };
            const 关闭连接 = () => {
                if (已关闭)
                    return;
                刷新发送队列(true);
                已关闭 = true;
                grpcBridge.readyState = WebSocket.CLOSED;
                if (刷新定时器)
                    clearTimeout(刷新定时器);
                if (远端写入器) {
                    try {
                        远端写入器.releaseLock();
                    }
                    catch (e) { }
                    远端写入器 = null;
                }
                当前写入Socket = null;
                try {
                    reader.releaseLock();
                }
                catch (e) { }
                try {
                    remoteConnWrapper.socket?.close();
                }
                catch (e) { }
                try {
                    controller.close();
                }
                catch (e) { }
            };
            const 释放远端写入器 = () => {
                if (远端写入器) {
                    try {
                        远端写入器.releaseLock();
                    }
                    catch (e) { }
                    远端写入器 = null;
                }
                当前写入Socket = null;
            };
            const 写入远端 = async (payload, allowRetry = true) => {
                const socket = remoteConnWrapper.socket;
                if (!socket)
                    return false;
                if (socket !== 当前写入Socket) {
                    释放远端写入器();
                    当前写入Socket = socket;
                    远端写入器 = socket.writable.getWriter();
                }
                try {
                    await 远端写入器.write(payload);
                    return true;
                }
                catch (err) {
                    释放远端写入器();
                    if (allowRetry && typeof remoteConnWrapper.retryConnect === 'function') {
                        await remoteConnWrapper.retryConnect();
                        return await 写入远端(payload, false);
                    }
                    throw err;
                }
            };
            try {
                let pending = new Uint8Array(0);
                while (true) {
                    const { done, value } = await reader.read();
                    if (done)
                        break;
                    if (!value || value.byteLength === 0)
                        continue;
                    const 当前块 = value instanceof Uint8Array ? value : new Uint8Array(value);
                    const merged = new Uint8Array(pending.length + 当前块.length);
                    merged.set(pending, 0);
                    merged.set(当前块, pending.length);
                    pending = merged;
                    while (pending.byteLength >= 5) {
                        const grpcLen = ((pending[1] << 24) >>> 0) | (pending[2] << 16) | (pending[3] << 8) | pending[4];
                        const frameSize = 5 + grpcLen;
                        if (pending.byteLength < frameSize)
                            break;
                        const grpcPayload = pending.slice(5, frameSize);
                        pending = pending.slice(frameSize);
                        if (!grpcPayload.byteLength)
                            continue;
                        let payload = grpcPayload;
                        if (payload.byteLength >= 2 && payload[0] === 0x0a) {
                            let shift = 0;
                            let offset = 1;
                            let varint有效 = false;
                            while (offset < payload.length) {
                                const current = payload[offset++];
                                if ((current & 0x80) === 0) {
                                    varint有效 = true;
                                    break;
                                }
                                shift += 7;
                                if (shift > 35)
                                    break;
                            }
                            if (varint有效)
                                payload = payload.slice(offset);
                        }
                        if (!payload.byteLength)
                            continue;
                        if (isDnsQuery) {
                            if (判断是否是木马)
                                await 转发木马UDP数据(payload, grpcBridge, 木马UDP上下文);
                            else
                                await forwardataudp(payload, grpcBridge, null);
                            continue;
                        }
                        if (remoteConnWrapper.socket) {
                            if (!(await 写入远端(payload)))
                                throw new Error('Remote socket is not ready');
                        }
                        else {
                            let 首包buffer;
                            if (payload instanceof ArrayBuffer)
                                首包buffer = payload;
                            else if (ArrayBuffer.isView(payload))
                                首包buffer = payload.buffer.slice(payload.byteOffset, payload.byteOffset + payload.byteLength);
                            else
                                首包buffer = new Uint8Array(payload).buffer;
                            const 首包bytes = new Uint8Array(首包buffer);
                            if (判断是否是木马 === null)
                                判断是否是木马 = 首包bytes.byteLength >= 58 && 首包bytes[56] === 0x0d && 首包bytes[57] === 0x0a;
                            if (判断是否是木马) {
                                const 解析结果 = 解析木马请求(首包buffer, yourUUID);
                                if (解析结果?.hasError)
                                    throw new Error(解析结果.message || 'Invalid trojan request');
                                const { port, hostname, rawClientData, isUDP } = 解析结果;
                                log(`[gRPC] 木马首包: ${hostname}:${port} | UDP: ${isUDP ? '是' : '否'}`);
                                if (isSpeedTestSite(hostname))
                                    throw new Error('Speedtest site is blocked');
                                if (isUDP) {
                                    isDnsQuery = true;
                                    if (有效数据长度(rawClientData) > 0)
                                        await 转发木马UDP数据(rawClientData, grpcBridge, 木马UDP上下文);
                                }
                                else {
                                    await forwardataTCP(hostname, port, rawClientData, grpcBridge, null, remoteConnWrapper, yourUUID);
                                }
                            }
                            else {
                                判断是否是木马 = false;
                                const 解析结果 = 解析魏烈思请求(首包buffer, yourUUID);
                                if (解析结果?.hasError)
                                    throw new Error(解析结果.message || 'Invalid 魏烈思 request');
                                const { port, hostname, rawIndex, version, isUDP } = 解析结果;
                                log(`[gRPC] 魏烈思首包: ${hostname}:${port} | UDP: ${isUDP ? '是' : '否'}`);
                                if (isSpeedTestSite(hostname))
                                    throw new Error('Speedtest site is blocked');
                                if (isUDP) {
                                    if (port !== 53)
                                        throw new Error('UDP is not supported');
                                    isDnsQuery = true;
                                }
                                const respHeader = new Uint8Array([version[0], 0]);
                                grpcBridge.send(respHeader);
                                const rawData = 首包buffer.slice(rawIndex);
                                if (isDnsQuery) {
                                    if (判断是否是木马)
                                        await 转发木马UDP数据(rawData, grpcBridge, 木马UDP上下文);
                                    else
                                        await forwardataudp(rawData, grpcBridge, null);
                                }
                                else
                                    await forwardataTCP(hostname, port, rawData, grpcBridge, null, remoteConnWrapper, yourUUID);
                            }
                        }
                    }
                    刷新发送队列();
                }
            }
            catch (err) {
                log(`[gRPC转发] 处理失败: ${err?.message || err}`);
            }
            finally {
                释放远端写入器();
                关闭连接();
            }
        },
        cancel() {
            try {
                remoteConnWrapper.socket?.close();
            }
            catch (e) { }
            try {
                reader.releaseLock();
            }
            catch (e) { }
        }
    }), { status: 200, headers: grpcHeaders });
}
async function 处理WS请求(request, yourUUID, url) {
    const WS套接字对 = new WebSocketPair();
    const [clientSock, serverSock] = Object.values(WS套接字对);
    serverSock.accept();
    serverSock.binaryType = 'arraybuffer';
    let remoteConnWrapper = { socket: null, connectingPromise: null, retryConnect: null };
    let isDnsQuery = false;
    let 判断是否是木马 = null;
    const 木马UDP上下文 = { 缓存: new Uint8Array(0) };
    const earlyDataHeader = request.headers.get('sec-websocket-protocol') || '';
    const SS模式禁用EarlyData = !!url.searchParams.get('enc');
    let 已取消读取 = false;
    let 可读流已结束 = false;
    const readable = new ReadableStream({
        start(controller) {
            const 是流已关闭错误 = (err) => {
                const msg = err?.message || `${err || ''}`;
                return msg.includes('ReadableStream is closed') || msg.includes('The stream is closed') || msg.includes('already closed');
            };
            const 安全入队 = (data) => {
                if (已取消读取 || 可读流已结束)
                    return;
                try {
                    controller.enqueue(data);
                }
                catch (err) {
                    可读流已结束 = true;
                    if (!是流已关闭错误(err)) {
                        try {
                            controller.error(err);
                        }
                        catch (_) { }
                    }
                }
            };
            const 安全关闭流 = () => {
                if (已取消读取 || 可读流已结束)
                    return;
                可读流已结束 = true;
                try {
                    controller.close();
                }
                catch (err) {
                    if (!是流已关闭错误(err)) {
                        try {
                            controller.error(err);
                        }
                        catch (_) { }
                    }
                }
            };
            const 安全报错流 = (err) => {
                if (已取消读取 || 可读流已结束)
                    return;
                可读流已结束 = true;
                try {
                    controller.error(err);
                }
                catch (_) { }
            };
            serverSock.addEventListener('message', (event) => {
                安全入队(event.data);
            });
            serverSock.addEventListener('close', () => {
                closeSocketQuietly(serverSock);
                安全关闭流();
            });
            serverSock.addEventListener('error', (err) => {
                安全报错流(err);
                closeSocketQuietly(serverSock);
            });
            if (SS模式禁用EarlyData || !earlyDataHeader)
                return;
            try {
                const binaryString = atob(earlyDataHeader.replace(/-/g, '+').replace(/_/g, '/'));
                const bytes = new Uint8Array(binaryString.length);
                for (let i = 0; i < binaryString.length; i++)
                    bytes[i] = binaryString.charCodeAt(i);
                安全入队(bytes.buffer);
            }
            catch (error) {
                安全报错流(error);
            }
        },
        cancel() {
            已取消读取 = true;
            可读流已结束 = true;
            closeSocketQuietly(serverSock);
        }
    });
    let 判断协议类型 = null, 当前写入Socket = null, 远端写入器 = null;
    let ss上下文 = null, ss初始化任务 = null;
    const 释放远端写入器 = () => {
        if (远端写入器) {
            try {
                远端写入器.releaseLock();
            }
            catch (e) { }
            远端写入器 = null;
        }
        当前写入Socket = null;
    };
    const 写入远端 = async (chunk, allowRetry = true) => {
        const socket = remoteConnWrapper.socket;
        if (!socket)
            return false;
        if (socket !== 当前写入Socket) {
            释放远端写入器();
            当前写入Socket = socket;
            远端写入器 = socket.writable.getWriter();
        }
        try {
            await 远端写入器.write(chunk);
            return true;
        }
        catch (err) {
            释放远端写入器();
            if (allowRetry && typeof remoteConnWrapper.retryConnect === 'function') {
                await remoteConnWrapper.retryConnect();
                return await 写入远端(chunk, false);
            }
            throw err;
        }
    };
    const 获取SS上下文 = async () => {
        if (ss上下文)
            return ss上下文;
        if (!ss初始化任务) {
            ss初始化任务 = (async () => {
                const 请求加密方式 = (url.searchParams.get('enc') || '').toLowerCase();
                const 首选加密配置 = SS支持加密配置[请求加密方式] || SS支持加密配置['aes-128-gcm'];
                const 入站候选加密配置 = [首选加密配置, ...Object.values(SS支持加密配置).filter(c => c.method !== 首选加密配置.method)];
                const 入站主密钥任务缓存 = new Map();
                const 取入站主密钥任务 = (config) => {
                    if (!入站主密钥任务缓存.has(config.method))
                        入站主密钥任务缓存.set(config.method, SS派生主密钥(yourUUID, config.keyLen));
                    return 入站主密钥任务缓存.get(config.method);
                };
                const 入站状态 = {
                    buffer: new Uint8Array(0),
                    hasSalt: false,
                    waitPayloadLength: null,
                    decryptKey: null,
                    nonceCounter: new Uint8Array(SSNonce长度),
                    加密配置: null,
                };
                const 初始化入站解密状态 = async () => {
                    const lengthCipherTotalLength = 2 + SSAEAD标签长度;
                    const 最大盐长度 = Math.max(...入站候选加密配置.map(c => c.saltLen));
                    const 最大对齐扫描字节 = 16;
                    const 可扫描最大偏移 = Math.min(最大对齐扫描字节, Math.max(0, 入站状态.buffer.byteLength - (lengthCipherTotalLength + Math.min(...入站候选加密配置.map(c => c.saltLen)))));
                    for (let offset = 0; offset <= 可扫描最大偏移; offset++) {
                        for (const 加密配置 of 入站候选加密配置) {
                            const 初始化最小长度 = offset + 加密配置.saltLen + lengthCipherTotalLength;
                            if (入站状态.buffer.byteLength < 初始化最小长度)
                                continue;
                            const salt = 入站状态.buffer.subarray(offset, offset + 加密配置.saltLen);
                            const lengthCipher = 入站状态.buffer.subarray(offset + 加密配置.saltLen, 初始化最小长度);
                            const masterKey = await 取入站主密钥任务(加密配置);
                            const decryptKey = await SS派生会话密钥(加密配置, masterKey, salt, ['decrypt']);
                            const nonceCounter = new Uint8Array(SSNonce长度);
                            try {
                                const lengthPlain = await SSAEAD解密(decryptKey, nonceCounter, lengthCipher);
                                if (lengthPlain.byteLength !== 2)
                                    continue;
                                const payloadLength = (lengthPlain[0] << 8) | lengthPlain[1];
                                if (payloadLength < 0 || payloadLength > 加密配置.maxChunk)
                                    continue;
                                if (offset > 0)
                                    log(`[SS入站] 检测到前导噪声 ${offset}B，已自动对齐`);
                                if (加密配置.method !== 首选加密配置.method)
                                    log(`[SS入站] URL enc=${请求加密方式 || 首选加密配置.method} 与实际 ${加密配置.method} 不一致，已自动切换`);
                                入站状态.buffer = 入站状态.buffer.subarray(初始化最小长度);
                                入站状态.decryptKey = decryptKey;
                                入站状态.nonceCounter = nonceCounter;
                                入站状态.waitPayloadLength = payloadLength;
                                入站状态.加密配置 = 加密配置;
                                入站状态.hasSalt = true;
                                return true;
                            }
                            catch (_) { }
                        }
                    }
                    const 初始化失败判定长度 = 最大盐长度 + lengthCipherTotalLength + 最大对齐扫描字节;
                    if (入站状态.buffer.byteLength >= 初始化失败判定长度) {
                        throw new Error(`SS handshake decrypt failed (enc=${请求加密方式 || 'auto'}, candidates=${入站候选加密配置.map(c => c.method).join('/')})`);
                    }
                    return false;
                };
                const 入站解密器 = {
                    async 输入(dataChunk) {
                        const chunk = 数据转Uint8Array(dataChunk);
                        if (chunk.byteLength > 0)
                            入站状态.buffer = 拼接字节数据(入站状态.buffer, chunk);
                        if (!入站状态.hasSalt) {
                            const 初始化成功 = await 初始化入站解密状态();
                            if (!初始化成功)
                                return [];
                        }
                        const plaintextChunks = [];
                        while (true) {
                            if (入站状态.waitPayloadLength === null) {
                                const lengthCipherTotalLength = 2 + SSAEAD标签长度;
                                if (入站状态.buffer.byteLength < lengthCipherTotalLength)
                                    break;
                                const lengthCipher = 入站状态.buffer.subarray(0, lengthCipherTotalLength);
                                入站状态.buffer = 入站状态.buffer.subarray(lengthCipherTotalLength);
                                const lengthPlain = await SSAEAD解密(入站状态.decryptKey, 入站状态.nonceCounter, lengthCipher);
                                if (lengthPlain.byteLength !== 2)
                                    throw new Error('SS length decrypt failed');
                                const payloadLength = (lengthPlain[0] << 8) | lengthPlain[1];
                                if (payloadLength < 0 || payloadLength > 入站状态.加密配置.maxChunk)
                                    throw new Error(`SS payload length invalid: ${payloadLength}`);
                                入站状态.waitPayloadLength = payloadLength;
                            }
                            const payloadCipherTotalLength = 入站状态.waitPayloadLength + SSAEAD标签长度;
                            if (入站状态.buffer.byteLength < payloadCipherTotalLength)
                                break;
                            const payloadCipher = 入站状态.buffer.subarray(0, payloadCipherTotalLength);
                            入站状态.buffer = 入站状态.buffer.subarray(payloadCipherTotalLength);
                            const payloadPlain = await SSAEAD解密(入站状态.decryptKey, 入站状态.nonceCounter, payloadCipher);
                            plaintextChunks.push(payloadPlain);
                            入站状态.waitPayloadLength = null;
                        }
                        return plaintextChunks;
                    },
                };
                let 出站加密器 = null;
                const SS单批最大字节 = 32 * 1024;
                const 获取出站加密器 = async () => {
                    if (出站加密器)
                        return 出站加密器;
                    if (!入站状态.加密配置)
                        throw new Error('SS cipher is not negotiated');
                    const 出站加密配置 = 入站状态.加密配置;
                    const 出站主密钥 = await SS派生主密钥(yourUUID, 出站加密配置.keyLen);
                    const 出站随机字节 = crypto.getRandomValues(new Uint8Array(出站加密配置.saltLen));
                    const 出站加密密钥 = await SS派生会话密钥(出站加密配置, 出站主密钥, 出站随机字节, ['encrypt']);
                    const 出站Nonce计数器 = new Uint8Array(SSNonce长度);
                    let 随机字节已发送 = false;
                    出站加密器 = {
                        async 加密并发送(dataChunk, sendChunk) {
                            const plaintextData = 数据转Uint8Array(dataChunk);
                            if (!随机字节已发送) {
                                await sendChunk(出站随机字节);
                                随机字节已发送 = true;
                            }
                            if (plaintextData.byteLength === 0)
                                return;
                            let offset = 0;
                            while (offset < plaintextData.byteLength) {
                                const end = Math.min(offset + 出站加密配置.maxChunk, plaintextData.byteLength);
                                const payloadPlain = plaintextData.subarray(offset, end);
                                const lengthPlain = new Uint8Array(2);
                                lengthPlain[0] = (payloadPlain.byteLength >>> 8) & 0xff;
                                lengthPlain[1] = payloadPlain.byteLength & 0xff;
                                const lengthCipher = await SSAEAD加密(出站加密密钥, 出站Nonce计数器, lengthPlain);
                                const payloadCipher = await SSAEAD加密(出站加密密钥, 出站Nonce计数器, payloadPlain);
                                const frame = new Uint8Array(lengthCipher.byteLength + payloadCipher.byteLength);
                                frame.set(lengthCipher, 0);
                                frame.set(payloadCipher, lengthCipher.byteLength);
                                await sendChunk(frame);
                                offset = end;
                            }
                        },
                    };
                    return 出站加密器;
                };
                let SS发送队列 = Promise.resolve();
                const SS入队发送 = (chunk) => {
                    SS发送队列 = SS发送队列.then(async () => {
                        if (serverSock.readyState !== WebSocket.OPEN)
                            return;
                        const 已初始化出站加密器 = await 获取出站加密器();
                        await 已初始化出站加密器.加密并发送(chunk, async (encryptedChunk) => {
                            if (encryptedChunk.byteLength > 0 && serverSock.readyState === WebSocket.OPEN) {
                                await WebSocket发送并等待(serverSock, encryptedChunk.buffer);
                            }
                        });
                    }).catch((error) => {
                        log(`[SS发送] 加密失败: ${error?.message || error}`);
                        closeSocketQuietly(serverSock);
                    });
                    return SS发送队列;
                };
                const 回包Socket = {
                    get readyState() {
                        return serverSock.readyState;
                    },
                    send(data) {
                        const chunk = 数据转Uint8Array(data);
                        if (chunk.byteLength <= SS单批最大字节) {
                            return SS入队发送(chunk);
                        }
                        for (let i = 0; i < chunk.byteLength; i += SS单批最大字节) {
                            SS入队发送(chunk.subarray(i, Math.min(i + SS单批最大字节, chunk.byteLength)));
                        }
                        return SS发送队列;
                    },
                    close() {
                        closeSocketQuietly(serverSock);
                    }
                };
                ss上下文 = {
                    入站解密器,
                    回包Socket,
                    首包已建立: false,
                    目标主机: '',
                    目标端口: 0,
                };
                return ss上下文;
            })().finally(() => { ss初始化任务 = null; });
        }
        return ss初始化任务;
    };
    const 处理SS数据 = async (chunk) => {
        const 上下文 = await 获取SS上下文();
        let 明文块数组 = null;
        try {
            明文块数组 = await 上下文.入站解密器.输入(chunk);
        }
        catch (err) {
            const msg = err?.message || `${err}`;
            if (msg.includes('Decryption failed') || msg.includes('SS handshake decrypt failed') || msg.includes('SS length decrypt failed')) {
                log(`[SS入站] 解密失败，连接关闭: ${msg}`);
                closeSocketQuietly(serverSock);
                return;
            }
            throw err;
        }
        for (const 明文块 of 明文块数组) {
            let 已写入 = false;
            try {
                已写入 = await 写入远端(明文块, false);
            }
            catch (_) {
                已写入 = false;
            }
            if (已写入)
                continue;
            if (上下文.首包已建立 && 上下文.目标主机 && 上下文.目标端口 > 0) {
                await forwardataTCP(上下文.目标主机, 上下文.目标端口, 明文块, 上下文.回包Socket, null, remoteConnWrapper, yourUUID);
                continue;
            }
            const 明文数据 = 数据转Uint8Array(明文块);
            if (明文数据.byteLength < 3)
                throw new Error('invalid ss data');
            const addressType = 明文数据[0];
            let cursor = 1;
            let hostname = '';
            if (addressType === 1) {
                if (明文数据.byteLength < cursor + 4 + 2)
                    throw new Error('invalid ss ipv4 length');
                hostname = `${明文数据[cursor]}.${明文数据[cursor + 1]}.${明文数据[cursor + 2]}.${明文数据[cursor + 3]}`;
                cursor += 4;
            }
            else if (addressType === 3) {
                if (明文数据.byteLength < cursor + 1)
                    throw new Error('invalid ss domain length');
                const domainLength = 明文数据[cursor];
                cursor += 1;
                if (明文数据.byteLength < cursor + domainLength + 2)
                    throw new Error('invalid ss domain data');
                hostname = SS文本解码器.decode(明文数据.subarray(cursor, cursor + domainLength));
                cursor += domainLength;
            }
            else if (addressType === 4) {
                if (明文数据.byteLength < cursor + 16 + 2)
                    throw new Error('invalid ss ipv6 length');
                const ipv6 = [];
                const ipv6View = new DataView(明文数据.buffer, 明文数据.byteOffset + cursor, 16);
                for (let i = 0; i < 8; i++)
                    ipv6.push(ipv6View.getUint16(i * 2).toString(16));
                hostname = ipv6.join(':');
                cursor += 16;
            }
            else {
                throw new Error(`invalid ss addressType: ${addressType}`);
            }
            if (!hostname)
                throw new Error(`invalid ss address: ${addressType}`);
            const port = (明文数据[cursor] << 8) | 明文数据[cursor + 1];
            cursor += 2;
            const rawClientData = 明文数据.subarray(cursor);
            if (isSpeedTestSite(hostname))
                throw new Error('Speedtest site is blocked');
            上下文.首包已建立 = true;
            上下文.目标主机 = hostname;
            上下文.目标端口 = port;
            await forwardataTCP(hostname, port, rawClientData, 上下文.回包Socket, null, remoteConnWrapper, yourUUID);
        }
    };
    readable.pipeTo(new WritableStream({
        async write(chunk) {
            if (isDnsQuery) {
                if (判断是否是木马)
                    return await 转发木马UDP数据(chunk, serverSock, 木马UDP上下文);
                return await forwardataudp(chunk, serverSock, null);
            }
            if (判断协议类型 === 'ss') {
                await 处理SS数据(chunk);
                return;
            }
            if (await 写入远端(chunk))
                return;
            if (判断协议类型 === null) {
                if (url.searchParams.get('enc'))
                    判断协议类型 = 'ss';
                else {
                    const bytes = new Uint8Array(chunk);
                    判断协议类型 = bytes.byteLength >= 58 && bytes[56] === 0x0d && bytes[57] === 0x0a ? '木马' : '魏烈思';
                }
                判断是否是木马 = 判断协议类型 === '木马';
                log(`[WS转发] 协议类型: ${判断协议类型} | 来自: ${url.host} | UA: ${request.headers.get('user-agent') || '未知'}`);
            }
            if (判断协议类型 === 'ss') {
                await 处理SS数据(chunk);
                return;
            }
            if (await 写入远端(chunk))
                return;
            if (判断协议类型 === '木马') {
                const 解析结果 = 解析木马请求(chunk, yourUUID);
                if (解析结果?.hasError)
                    throw new Error(解析结果.message || 'Invalid trojan request');
                const { port, hostname, rawClientData, isUDP } = 解析结果;
                if (isSpeedTestSite(hostname))
                    throw new Error('Speedtest site is blocked');
                if (isUDP) {
                    isDnsQuery = true;
                    if (有效数据长度(rawClientData) > 0)
                        return 转发木马UDP数据(rawClientData, serverSock, 木马UDP上下文);
                    return;
                }
                await forwardataTCP(hostname, port, rawClientData, serverSock, null, remoteConnWrapper, yourUUID);
            }
            else {
                判断是否是木马 = false;
                const 解析结果 = 解析魏烈思请求(chunk, yourUUID);
                if (解析结果?.hasError)
                    throw new Error(解析结果.message || 'Invalid 魏烈思 request');
                const { port, hostname, rawIndex, version, isUDP } = 解析结果;
                if (isSpeedTestSite(hostname))
                    throw new Error('Speedtest site is blocked');
                if (isUDP) {
                    if (port === 53)
                        isDnsQuery = true;
                    else
                        throw new Error('UDP is not supported');
                }
                const respHeader = new Uint8Array([version[0], 0]);
                const rawData = chunk.slice(rawIndex);
                if (isDnsQuery) {
                    if (判断是否是木马)
                        return 转发木马UDP数据(rawData, serverSock, 木马UDP上下文);
                    return forwardataudp(rawData, serverSock, respHeader);
                }
                await forwardataTCP(hostname, port, rawData, serverSock, respHeader, remoteConnWrapper, yourUUID);
            }
        },
        close() {
            释放远端写入器();
        },
        abort() {
            释放远端写入器();
        }
    })).catch((err) => {
        const msg = err?.message || `${err}`;
        if (msg.includes('Network connection lost') || msg.includes('ReadableStream is closed')) {
            log(`[WS转发] 连接结束: ${msg}`);
        }
        else {
            log(`[WS转发] 处理失败: ${msg}`);
        }
        释放远端写入器();
        closeSocketQuietly(serverSock);
    });
    return new Response(null, { status: 101, webSocket: clientSock });
}
function 解析木马请求(buffer, passwordPlainText) {
    const sha224Password = sha224(passwordPlainText);
    if (buffer.byteLength < 56)
        return { hasError: true, message: "invalid data" };
    let crLfIndex = 56;
    if (new Uint8Array(buffer.slice(56, 57))[0] !== 0x0d || new Uint8Array(buffer.slice(57, 58))[0] !== 0x0a)
        return { hasError: true, message: "invalid header format" };
    const password = new TextDecoder().decode(buffer.slice(0, crLfIndex));
    if (password !== sha224Password)
        return { hasError: true, message: "invalid password" };
    const socks5DataBuffer = buffer.slice(crLfIndex + 2);
    if (socks5DataBuffer.byteLength < 6)
        return { hasError: true, message: "invalid S5 request data" };
    const view = new DataView(socks5DataBuffer);
    const cmd = view.getUint8(0);
    if (cmd !== 1 && cmd !== 3)
        return { hasError: true, message: "unsupported command, only TCP/UDP is allowed" };
    const isUDP = cmd === 3;
    const atype = view.getUint8(1);
    let addressLength = 0;
    let addressIndex = 2;
    let address = "";
    switch (atype) {
        case 1:
            addressLength = 4;
            address = new Uint8Array(socks5DataBuffer.slice(addressIndex, addressIndex + addressLength)).join(".");
            break;
        case 3:
            addressLength = new Uint8Array(socks5DataBuffer.slice(addressIndex, addressIndex + 1))[0];
            addressIndex += 1;
            address = new TextDecoder().decode(socks5DataBuffer.slice(addressIndex, addressIndex + addressLength));
            break;
        case 4:
            addressLength = 16;
            const dataView = new DataView(socks5DataBuffer.slice(addressIndex, addressIndex + addressLength));
            const ipv6 = [];
            for (let i = 0; i < 8; i++) {
                ipv6.push(dataView.getUint16(i * 2).toString(16));
            }
            address = ipv6.join(":");
            break;
        default:
            return { hasError: true, message: `invalid addressType is ${atype}` };
    }
    if (!address) {
        return { hasError: true, message: `address is empty, addressType is ${atype}` };
    }
    const portIndex = addressIndex + addressLength;
    const portBuffer = socks5DataBuffer.slice(portIndex, portIndex + 2);
    const portRemote = new DataView(portBuffer).getUint16(0);
    return {
        hasError: false,
        addressType: atype,
        port: portRemote,
        hostname: address,
        isUDP,
        rawClientData: socks5DataBuffer.slice(portIndex + 4)
    };
}
function 解析魏烈思请求(chunk, token) {
    if (chunk.byteLength < 24)
        return { hasError: true, message: 'Invalid data' };
    const version = new Uint8Array(chunk.slice(0, 1));
    if (formatIdentifier(new Uint8Array(chunk.slice(1, 17))) !== token)
        return { hasError: true, message: 'Invalid uuid' };
    const optLen = new Uint8Array(chunk.slice(17, 18))[0];
    const cmd = new Uint8Array(chunk.slice(18 + optLen, 19 + optLen))[0];
    let isUDP = false;
    if (cmd === 1) { }
    else if (cmd === 2) {
        isUDP = true;
    }
    else {
        return { hasError: true, message: 'Invalid command' };
    }
    const portIdx = 19 + optLen;
    const port = new DataView(chunk.slice(portIdx, portIdx + 2)).getUint16(0);
    let addrIdx = portIdx + 2, addrLen = 0, addrValIdx = addrIdx + 1, hostname = '';
    const addressType = new Uint8Array(chunk.slice(addrIdx, addrValIdx))[0];
    switch (addressType) {
        case 1:
            addrLen = 4;
            hostname = new Uint8Array(chunk.slice(addrValIdx, addrValIdx + addrLen)).join('.');
            break;
        case 2:
            addrLen = new Uint8Array(chunk.slice(addrValIdx, addrValIdx + 1))[0];
            addrValIdx += 1;
            hostname = new TextDecoder().decode(chunk.slice(addrValIdx, addrValIdx + addrLen));
            break;
        case 3:
            addrLen = 16;
            const ipv6 = [];
            const ipv6View = new DataView(chunk.slice(addrValIdx, addrValIdx + addrLen));
            for (let i = 0; i < 8; i++)
                ipv6.push(ipv6View.getUint16(i * 2).toString(16));
            hostname = ipv6.join(':');
            break;
        default:
            return { hasError: true, message: `Invalid address type: ${addressType}` };
    }
    if (!hostname)
        return { hasError: true, message: `Invalid address: ${addressType}` };
    return { hasError: false, addressType, port, hostname, isUDP, rawIndex: addrValIdx + addrLen, version };
}
const SS支持加密配置 = {
    'aes-128-gcm': { method: 'aes-128-gcm', keyLen: 16, saltLen: 16, maxChunk: 0x3fff, aesLength: 128 },
    'aes-256-gcm': { method: 'aes-256-gcm', keyLen: 32, saltLen: 32, maxChunk: 0x3fff, aesLength: 256 },
};
const SSAEAD标签长度 = 16, SSNonce长度 = 12;
const SS子密钥信息 = new TextEncoder().encode('ss-subkey');
const SS文本编码器 = new TextEncoder(), SS文本解码器 = new TextDecoder(), SS主密钥缓存 = new Map();
function 数据转Uint8Array(data) {
    if (data instanceof Uint8Array)
        return data;
    if (data instanceof ArrayBuffer)
        return new Uint8Array(data);
    if (ArrayBuffer.isView(data))
        return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return new Uint8Array(data || 0);
}
function 拼接字节数据(...chunkList) {
    if (!chunkList || chunkList.length === 0)
        return new Uint8Array(0);
    const chunks = chunkList.map(数据转Uint8Array);
    const total = chunks.reduce((sum, c) => sum + c.byteLength, 0);
    const result = new Uint8Array(total);
    let offset = 0;
    for (const c of chunks) {
        result.set(c, offset);
        offset += c.byteLength;
    }
    return result;
}
async function 转发木马UDP数据(chunk, webSocket, 上下文) {
    const 当前块 = 数据转Uint8Array(chunk);
    const 缓存块 = 上下文?.缓存 instanceof Uint8Array ? 上下文.缓存 : new Uint8Array(0);
    const input = 缓存块.byteLength ? 拼接字节数据(缓存块, 当前块) : 当前块;
    let cursor = 0;
    while (cursor < input.byteLength) {
        const packetStart = cursor;
        const atype = input[cursor];
        let addrCursor = cursor + 1;
        let addrLen = 0;
        if (atype === 1)
            addrLen = 4;
        else if (atype === 4)
            addrLen = 16;
        else if (atype === 3) {
            if (input.byteLength < addrCursor + 1)
                break;
            addrLen = 1 + input[addrCursor];
        }
        else
            throw new Error(`invalid trojan udp addressType: ${atype}`);
        const portCursor = addrCursor + addrLen;
        if (input.byteLength < portCursor + 6)
            break;
        const port = (input[portCursor] << 8) | input[portCursor + 1];
        const payloadLength = (input[portCursor + 2] << 8) | input[portCursor + 3];
        if (input[portCursor + 4] !== 0x0d || input[portCursor + 5] !== 0x0a)
            throw new Error('invalid trojan udp delimiter');
        const payloadStart = portCursor + 6;
        const payloadEnd = payloadStart + payloadLength;
        if (input.byteLength < payloadEnd)
            break;
        const 地址端口头 = input.slice(packetStart, portCursor + 2);
        const payload = input.slice(payloadStart, payloadEnd);
        cursor = payloadEnd;
        if (port !== 53)
            throw new Error('UDP is not supported');
        if (!payload.byteLength)
            continue;
        let tcpDNS查询 = payload;
        if (payload.byteLength < 2 || ((payload[0] << 8) | payload[1]) !== payload.byteLength - 2) {
            tcpDNS查询 = new Uint8Array(payload.byteLength + 2);
            tcpDNS查询[0] = (payload.byteLength >>> 8) & 0xff;
            tcpDNS查询[1] = payload.byteLength & 0xff;
            tcpDNS查询.set(payload, 2);
        }
        const dns响应上下文 = { 缓存: new Uint8Array(0) };
        await forwardataudp(tcpDNS查询, webSocket, null, (dnsRespChunk) => {
            const 当前响应块 = 数据转Uint8Array(dnsRespChunk);
            const 响应输入 = dns响应上下文.缓存.byteLength ? 拼接字节数据(dns响应上下文.缓存, 当前响应块) : 当前响应块;
            const 响应帧列表 = [];
            let responseCursor = 0;
            while (responseCursor + 2 <= 响应输入.byteLength) {
                const dnsLen = (响应输入[responseCursor] << 8) | 响应输入[responseCursor + 1];
                const dnsStart = responseCursor + 2;
                const dnsEnd = dnsStart + dnsLen;
                if (dnsEnd > 响应输入.byteLength)
                    break;
                const dnsPayload = 响应输入.slice(dnsStart, dnsEnd);
                const frame = new Uint8Array(地址端口头.byteLength + 4 + dnsPayload.byteLength);
                frame.set(地址端口头, 0);
                frame[地址端口头.byteLength] = (dnsPayload.byteLength >>> 8) & 0xff;
                frame[地址端口头.byteLength + 1] = dnsPayload.byteLength & 0xff;
                frame[地址端口头.byteLength + 2] = 0x0d;
                frame[地址端口头.byteLength + 3] = 0x0a;
                frame.set(dnsPayload, 地址端口头.byteLength + 4);
                响应帧列表.push(frame);
                responseCursor = dnsEnd;
            }
            dns响应上下文.缓存 = 响应输入.slice(responseCursor);
            return 响应帧列表.length ? 响应帧列表 : new Uint8Array(0);
        });
    }
    if (上下文)
        上下文.缓存 = input.slice(cursor);
}
function SS递增Nonce计数器(counter) {
    for (let i = 0; i < counter.length; i++) {
        counter[i] = (counter[i] + 1) & 0xff;
        if (counter[i] !== 0)
            return;
    }
}
async function SS派生主密钥(passwordText, keyLen) {
    const cacheKey = `${keyLen}:${passwordText}`;
    if (SS主密钥缓存.has(cacheKey))
        return SS主密钥缓存.get(cacheKey);
    const deriveTask = (async () => {
        const pwBytes = SS文本编码器.encode(passwordText || '');
        let prev = new Uint8Array(0), result = new Uint8Array(0);
        while (result.byteLength < keyLen) {
            const input = new Uint8Array(prev.byteLength + pwBytes.byteLength);
            input.set(prev, 0);
            input.set(pwBytes, prev.byteLength);
            prev = new Uint8Array(await crypto.subtle.digest('MD5', input));
            result = 拼接字节数据(result, prev);
        }
        return result.slice(0, keyLen);
    })();
    SS主密钥缓存.set(cacheKey, deriveTask);
    try {
        return await deriveTask;
    }
    catch (error) {
        SS主密钥缓存.delete(cacheKey);
        throw error;
    }
}
async function SS派生会话密钥(config, masterKey, salt, usages) {
    const hmacOpts = { name: 'HMAC', hash: 'SHA-1' };
    const saltHmacKey = await crypto.subtle.importKey('raw', salt, hmacOpts, false, ['sign']);
    const prk = new Uint8Array(await crypto.subtle.sign('HMAC', saltHmacKey, masterKey));
    const prkHmacKey = await crypto.subtle.importKey('raw', prk, hmacOpts, false, ['sign']);
    const subKey = new Uint8Array(config.keyLen);
    let prev = new Uint8Array(0), written = 0, counter = 1;
    while (written < config.keyLen) {
        const input = 拼接字节数据(prev, SS子密钥信息, new Uint8Array([counter]));
        prev = new Uint8Array(await crypto.subtle.sign('HMAC', prkHmacKey, input));
        const copyLen = Math.min(prev.byteLength, config.keyLen - written);
        subKey.set(prev.subarray(0, copyLen), written);
        written += copyLen;
        counter += 1;
    }
    return crypto.subtle.importKey('raw', subKey, { name: 'AES-GCM', length: config.aesLength }, false, usages);
}
async function SSAEAD加密(cryptoKey, nonceCounter, plaintext) {
    const iv = nonceCounter.slice();
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, tagLength: 128 }, cryptoKey, plaintext);
    SS递增Nonce计数器(nonceCounter);
    return new Uint8Array(ct);
}
async function SSAEAD解密(cryptoKey, nonceCounter, ciphertext) {
    const iv = nonceCounter.slice();
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, tagLength: 128 }, cryptoKey, ciphertext);
    SS递增Nonce计数器(nonceCounter);
    return new Uint8Array(pt);
}
async function forwardataTCP(host, portNum, rawData, ws, respHeader, remoteConnWrapper, yourUUID) {
    log(`[TCP转发] 目标: ${host}:${portNum} | 反代IP: ${反代IP} | 反代兜底: ${启用反代兜底 ? '是' : '否'} | 反代类型: ${启用SOCKS5反代 || 'proxyip'} | 全局: ${启用SOCKS5全局反代 ? '是' : '否'}`);
    const 连接超时毫秒 = 1000;
    let 已通过代理发送首包 = false;
    async function 等待连接建立(remoteSock, timeoutMs = 连接超时毫秒) {
        await Promise.race([
            remoteSock.opened,
            new Promise((_, reject) => setTimeout(() => reject(new Error('连接超时')), timeoutMs))
        ]);
    }
    async function connectDirect(address, port, data = null, 所有反代数组 = null, 反代兜底 = true) {
        let remoteSock;
        if (所有反代数组 && 所有反代数组.length > 0) {
            for (let i = 0; i < 所有反代数组.length; i++) {
                const 反代数组索引 = (缓存反代数组索引 + i) % 所有反代数组.length;
                const [反代地址, 反代端口] = 所有反代数组[反代数组索引];
                try {
                    log(`[反代连接] 尝试连接到: ${反代地址}:${反代端口} (索引: ${反代数组索引})`);
                    remoteSock = connect({ hostname: 反代地址, port: 反代端口 });
                    await 等待连接建立(remoteSock);
                    if (有效数据长度(data) > 0) {
                        const testWriter = remoteSock.writable.getWriter();
                        await testWriter.write(data);
                        testWriter.releaseLock();
                    }
                    log(`[反代连接] 成功连接到: ${反代地址}:${反代端口}`);
                    缓存反代数组索引 = 反代数组索引;
                    return remoteSock;
                }
                catch (err) {
                    log(`[反代连接] 连接失败: ${反代地址}:${反代端口}, 错误: ${err.message}`);
                    try {
                        remoteSock?.close?.();
                    }
                    catch (e) { }
                    continue;
                }
            }
        }
        if (反代兜底) {
            remoteSock = connect({ hostname: address, port: port });
            await 等待连接建立(remoteSock);
            if (有效数据长度(data) > 0) {
                const writer = remoteSock.writable.getWriter();
                await writer.write(data);
                writer.releaseLock();
            }
            return remoteSock;
        }
        else {
            closeSocketQuietly(ws);
            throw new Error('[反代连接] 所有反代连接失败，且未启用反代兜底，连接终止。');
        }
    }
    async function connecttoPry(允许发送首包 = true) {
        if (remoteConnWrapper.connectingPromise) {
            await remoteConnWrapper.connectingPromise;
            return;
        }
        const 本次发送首包 = 允许发送首包 && !已通过代理发送首包 && 有效数据长度(rawData) > 0;
        const 本次首包数据 = 本次发送首包 ? rawData : null;
        const 当前连接任务 = (async () => {
            let newSocket;
            if (启用SOCKS5反代 === 'socks5') {
                log(`[SOCKS5代理] 代理到: ${host}:${portNum}`);
                newSocket = await socks5Connect(host, portNum, 本次首包数据);
            }
            else if (启用SOCKS5反代 === 'http') {
                log(`[HTTP代理] 代理到: ${host}:${portNum}`);
                newSocket = await httpConnect(host, portNum, 本次首包数据);
            }
            else if (启用SOCKS5反代 === 'https') {
                log(`[HTTPS代理] 代理到: ${host}:${portNum}`);
                newSocket = isIPHostname(parsedSocks5Address.hostname)
                    ? await httpsConnect(host, portNum, 本次首包数据)
                    : await httpConnect(host, portNum, 本次首包数据, true);
            }
            else if (启用SOCKS5反代 === 'turn') {
                log(`[TURN代理] 代理到: ${host}:${portNum}`);
                newSocket = await turnConnect(parsedSocks5Address, host, portNum);
                if (有效数据长度(本次首包数据) > 0) {
                    const writer = newSocket.writable.getWriter();
                    try {
                        await writer.write(数据转Uint8Array(本次首包数据));
                    }
                    finally {
                        try {
                            writer.releaseLock();
                        }
                        catch (e) { }
                    }
                }
            }
            else if (启用SOCKS5反代 === 'sstp') {
                log(`[SSTP代理] 代理到: ${host}:${portNum}`);
                newSocket = await sstpConnect(parsedSocks5Address, host, portNum);
                if (有效数据长度(本次首包数据) > 0) {
                    const writer = newSocket.writable.getWriter();
                    try {
                        await writer.write(数据转Uint8Array(本次首包数据));
                    }
                    finally {
                        try {
                            writer.releaseLock();
                        }
                        catch (e) { }
                    }
                }
            }
            else {
                log(`[反代连接] 代理到: ${host}:${portNum}`);
                const 所有反代数组 = await 解析地址端口(反代IP, host, yourUUID);
                newSocket = await connectDirect(atob('UFJPWFlJUC50cDEuMDkwMjI3Lnh5eg=='), 1, 本次首包数据, 所有反代数组, 启用反代兜底);
            }
            if (本次发送首包)
                已通过代理发送首包 = true;
            remoteConnWrapper.socket = newSocket;
            newSocket.closed.catch(() => { }).finally(() => closeSocketQuietly(ws));
            connectStreams(newSocket, ws, respHeader, null);
        })();
        remoteConnWrapper.connectingPromise = 当前连接任务;
        try {
            await 当前连接任务;
        }
        finally {
            if (remoteConnWrapper.connectingPromise === 当前连接任务) {
                remoteConnWrapper.connectingPromise = null;
            }
        }
    }
    remoteConnWrapper.retryConnect = async () => connecttoPry(!已通过代理发送首包);
    if (启用SOCKS5反代 && (启用SOCKS5全局反代 || SOCKS5白名单.some(p => new RegExp(`^${p.replace(/\*/g, '.*')}$`, 'i').test(host)))) {
        log(`[TCP转发] 启用 SOCKS5/HTTP/HTTPS/TURN/SSTP 全局代理`);
        try {
            await connecttoPry();
        }
        catch (err) {
            log(`[TCP转发] SOCKS5/HTTP/HTTPS/TURN/SSTP 代理连接失败: ${err.message}`);
            throw err;
        }
    }
    else {
        try {
            log(`[TCP转发] 尝试直连到: ${host}:${portNum}`);
            const initialSocket = await connectDirect(host, portNum, rawData);
            remoteConnWrapper.socket = initialSocket;
            connectStreams(initialSocket, ws, respHeader, async () => {
                if (remoteConnWrapper.socket !== initialSocket)
                    return;
                await connecttoPry();
            });
        }
        catch (err) {
            log(`[TCP转发] 直连 ${host}:${portNum} 失败: ${err.message}`);
            await connecttoPry();
        }
    }
}
async function forwardataudp(udpChunk, webSocket, respHeader, 响应封装器 = null) {
    const 请求数据 = 数据转Uint8Array(udpChunk);
    const 请求字节数 = 请求数据.byteLength;
    log(`[UDP转发] 收到 DNS 请求: ${请求字节数}B -> 8.8.4.4:53`);
    try {
        const tcpSocket = connect({ hostname: '8.8.4.4', port: 53 });
        let 魏烈思Header = respHeader;
        const writer = tcpSocket.writable.getWriter();
        await writer.write(请求数据);
        log(`[UDP转发] DNS 请求已写入上游: ${请求字节数}B`);
        writer.releaseLock();
        await tcpSocket.readable.pipeTo(new WritableStream({
            async write(chunk) {
                const 原始响应 = 数据转Uint8Array(chunk);
                log(`[UDP转发] 收到 DNS 响应: ${原始响应.byteLength}B`);
                const 封装结果 = 响应封装器 ? await 响应封装器(原始响应) : 原始响应;
                const 发送片段列表 = Array.isArray(封装结果) ? 封装结果 : [封装结果];
                if (!发送片段列表.length)
                    return;
                if (webSocket.readyState === WebSocket.OPEN) {
                    for (const fragment of 发送片段列表) {
                        const 转发响应 = 数据转Uint8Array(fragment);
                        if (!转发响应.byteLength)
                            continue;
                        if (魏烈思Header) {
                            const response = new Uint8Array(魏烈思Header.length + 转发响应.byteLength);
                            response.set(魏烈思Header, 0);
                            response.set(转发响应, 魏烈思Header.length);
                            await WebSocket发送并等待(webSocket, response.buffer);
                            魏烈思Header = null;
                        }
                        else {
                            await WebSocket发送并等待(webSocket, 转发响应);
                        }
                    }
                }
            },
        }));
    }
    catch (error) {
        log(`[UDP转发] DNS 转发失败: ${error?.message || error}`);
    }
}
function closeSocketQuietly(socket) {
    try {
        if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CLOSING) {
            socket.close();
        }
    }
    catch (error) { }
}
function formatIdentifier(arr, offset = 0) {
    const hex = [...arr.slice(offset, offset + 16)].map(b => b.toString(16).padStart(2, '0')).join('');
    return `${hex.substring(0, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}`;
}
async function WebSocket发送并等待(webSocket, payload) {
    const sendResult = webSocket.send(payload);
    if (sendResult && typeof sendResult.then === 'function')
        await sendResult;
}
async function connectStreams(remoteSocket, webSocket, headerData, retryFunc) {
    let header = headerData, hasData = false, reader, useBYOB = false;
    const BYOB缓冲区大小 = 512 * 1024, BYOB单次读取上限 = 64 * 1024, BYOB高吞吐阈值 = 50 * 1024 * 1024;
    const 普通流聚合阈值 = 128 * 1024, 普通流刷新间隔 = 2;
    const BYOB慢速刷新间隔 = 20, BYOB快速刷新间隔 = 2, BYOB安全阈值 = BYOB缓冲区大小 - BYOB单次读取上限;
    const 发送块 = async (chunk) => {
        if (webSocket.readyState !== WebSocket.OPEN)
            throw new Error('ws.readyState is not open');
        if (header) {
            const merged = new Uint8Array(header.length + chunk.byteLength);
            merged.set(header, 0);
            merged.set(chunk, header.length);
            await WebSocket发送并等待(webSocket, merged.buffer);
            header = null;
        }
        else
            await WebSocket发送并等待(webSocket, chunk);
    };
    try {
        reader = remoteSocket.readable.getReader({ mode: 'byob' });
        useBYOB = true;
    }
    catch (e) {
        reader = remoteSocket.readable.getReader();
    }
    try {
        if (!useBYOB) {
            let pendingChunks = [], pendingBytes = 0, flush定时器 = null, flush任务 = null;
            const flush = async () => {
                if (flush任务)
                    return flush任务;
                flush任务 = (async () => {
                    if (flush定时器) {
                        clearTimeout(flush定时器);
                        flush定时器 = null;
                    }
                    if (pendingBytes <= 0)
                        return;
                    const chunks = pendingChunks, bytes = pendingBytes;
                    pendingChunks = [];
                    pendingBytes = 0;
                    const payload = chunks.length === 1 ? chunks[0] : 拼接字节数据(...chunks);
                    if (payload.byteLength || bytes > 0)
                        await 发送块(payload);
                })().finally(() => { flush任务 = null; });
                return flush任务;
            };
            const 推送普通流块 = async (chunk) => {
                const bytes = 数据转Uint8Array(chunk);
                if (!bytes.byteLength)
                    return;
                pendingChunks.push(bytes);
                pendingBytes += bytes.byteLength;
                if (pendingBytes >= 普通流聚合阈值) {
                    await flush();
                    if (pendingBytes >= 普通流聚合阈值)
                        await flush();
                }
                else if (!flush定时器) {
                    flush定时器 = setTimeout(() => { flush().catch(() => closeSocketQuietly(webSocket)); }, 普通流刷新间隔);
                }
            };
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                if (!value || value.byteLength === 0)
                    continue;
                hasData = true;
                await 推送普通流块(value);
            }
            await flush();
        }
        else {
            let mainBuf = new ArrayBuffer(BYOB缓冲区大小), offset = 0, totalBytes = 0;
            let flush间隔毫秒 = BYOB快速刷新间隔, flush定时器 = null, 等待刷新恢复 = null;
            let 正在读取 = false, 读取中待刷新 = false;
            const flush = async () => {
                if (正在读取) {
                    读取中待刷新 = true;
                    return;
                }
                try {
                    if (offset > 0) {
                        const p = new Uint8Array(mainBuf.slice(0, offset));
                        offset = 0;
                        await 发送块(p);
                    }
                }
                finally {
                    读取中待刷新 = false;
                    if (flush定时器) {
                        clearTimeout(flush定时器);
                        flush定时器 = null;
                    }
                    if (等待刷新恢复) {
                        const r = 等待刷新恢复;
                        等待刷新恢复 = null;
                        r();
                    }
                }
            };
            while (true) {
                正在读取 = true;
                const { done, value } = await reader.read(new Uint8Array(mainBuf, offset, BYOB单次读取上限));
                正在读取 = false;
                if (done)
                    break;
                if (!value || value.byteLength === 0) {
                    if (读取中待刷新)
                        await flush();
                    continue;
                }
                hasData = true;
                mainBuf = value.buffer;
                const len = value.byteLength;
                if (value.byteOffset !== offset) {
                    log(`[BYOB] 偏移异常: 预期=${offset}, 实际=${value.byteOffset}`);
                    await 发送块(new Uint8Array(value.buffer, value.byteOffset, len).slice());
                    mainBuf = new ArrayBuffer(BYOB缓冲区大小);
                    offset = 0;
                    totalBytes = 0;
                    continue;
                }
                if (len < BYOB单次读取上限) {
                    flush间隔毫秒 = BYOB快速刷新间隔;
                    if (len < 4096)
                        totalBytes = 0;
                    if (offset > 0) {
                        offset += len;
                        await flush();
                    }
                    else
                        await 发送块(value.slice());
                }
                else {
                    totalBytes += len;
                    offset += len;
                    if (!flush定时器)
                        flush定时器 = setTimeout(() => { flush().catch(() => closeSocketQuietly(webSocket)); }, flush间隔毫秒);
                    if (读取中待刷新)
                        await flush();
                    if (offset > BYOB安全阈值) {
                        if (totalBytes > BYOB高吞吐阈值)
                            flush间隔毫秒 = BYOB慢速刷新间隔;
                        await new Promise(r => { 等待刷新恢复 = r; });
                    }
                }
            }
            正在读取 = false;
            await flush();
            if (flush定时器) {
                clearTimeout(flush定时器);
                flush定时器 = null;
            }
        }
    }
    catch (err) {
        closeSocketQuietly(webSocket);
    }
    finally {
        try {
            reader.cancel();
        }
        catch (e) { }
        try {
            reader.releaseLock();
        }
        catch (e) { }
    }
    if (!hasData && retryFunc)
        await retryFunc();
}
function isSpeedTestSite(hostname) {
    const speedTestDomains = [atob('c3BlZWQuY2xvdWRmbGFyZS5jb20=')];
    if (speedTestDomains.includes(hostname)) {
        return true;
    }
    for (const domain of speedTestDomains) {
        if (hostname.endsWith('.' + domain) || hostname === domain) {
            return true;
        }
    }
    return false;
}
async function socks5Connect(targetHost, targetPort, initialData) {
    const { username, password, hostname, port } = parsedSocks5Address;
    const socket = connect({ hostname, port }), writer = socket.writable.getWriter(), reader = socket.readable.getReader();
    try {
        const authMethods = username && password ? new Uint8Array([0x05, 0x02, 0x00, 0x02]) : new Uint8Array([0x05, 0x01, 0x00]);
        await writer.write(authMethods);
        let response = await reader.read();
        if (response.done || response.value.byteLength < 2)
            throw new Error('S5 method selection failed');
        const selectedMethod = new Uint8Array(response.value)[1];
        if (selectedMethod === 0x02) {
            if (!username || !password)
                throw new Error('S5 requires authentication');
            const userBytes = new TextEncoder().encode(username), passBytes = new TextEncoder().encode(password);
            const authPacket = new Uint8Array([0x01, userBytes.length, ...userBytes, passBytes.length, ...passBytes]);
            await writer.write(authPacket);
            response = await reader.read();
            if (response.done || new Uint8Array(response.value)[1] !== 0x00)
                throw new Error('S5 authentication failed');
        }
        else if (selectedMethod !== 0x00)
            throw new Error(`S5 unsupported auth method: ${selectedMethod}`);
        const hostBytes = new TextEncoder().encode(targetHost);
        const connectPacket = new Uint8Array([0x05, 0x01, 0x00, 0x03, hostBytes.length, ...hostBytes, targetPort >> 8, targetPort & 0xff]);
        await writer.write(connectPacket);
        response = await reader.read();
        if (response.done || new Uint8Array(response.value)[1] !== 0x00)
            throw new Error('S5 connection failed');
        if (有效数据长度(initialData) > 0)
            await writer.write(initialData);
        writer.releaseLock();
        reader.releaseLock();
        return socket;
    }
    catch (error) {
        try {
            writer.releaseLock();
        }
        catch (e) { }
        try {
            reader.releaseLock();
        }
        catch (e) { }
        try {
            socket.close();
        }
        catch (e) { }
        throw error;
    }
}
async function httpConnect(targetHost, targetPort, initialData, HTTPS代理 = false) {
    const { username, password, hostname, port } = parsedSocks5Address;
    const socket = HTTPS代理
        ? connect({ hostname, port }, { secureTransport: 'on', allowHalfOpen: false })
        : connect({ hostname, port });
    const writer = socket.writable.getWriter(), reader = socket.readable.getReader();
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    try {
        if (HTTPS代理)
            await socket.opened;
        const auth = username && password ? `Proxy-Authorization: Basic ${btoa(`${username}:${password}`)}\r\n` : '';
        const request = `CONNECT ${targetHost}:${targetPort} HTTP/1.1\r\nHost: ${targetHost}:${targetPort}\r\n${auth}User-Agent: Mozilla/5.0\r\nConnection: keep-alive\r\n\r\n`;
        await writer.write(encoder.encode(request));
        writer.releaseLock();
        let responseBuffer = new Uint8Array(0), headerEndIndex = -1, bytesRead = 0;
        while (headerEndIndex === -1 && bytesRead < 8192) {
            const { done, value } = await reader.read();
            if (done || !value)
                throw new Error(`${HTTPS代理 ? 'HTTPS' : 'HTTP'} 代理在返回 CONNECT 响应前关闭连接`);
            responseBuffer = new Uint8Array([...responseBuffer, ...value]);
            bytesRead = responseBuffer.length;
            const crlfcrlf = responseBuffer.findIndex((_, i) => i < responseBuffer.length - 3 && responseBuffer[i] === 0x0d && responseBuffer[i + 1] === 0x0a && responseBuffer[i + 2] === 0x0d && responseBuffer[i + 3] === 0x0a);
            if (crlfcrlf !== -1)
                headerEndIndex = crlfcrlf + 4;
        }
        if (headerEndIndex === -1)
            throw new Error('代理 CONNECT 响应头过长或无效');
        const statusMatch = decoder.decode(responseBuffer.slice(0, headerEndIndex)).split('\r\n')[0].match(/HTTP\/\d\.\d\s+(\d+)/);
        const statusCode = statusMatch ? parseInt(statusMatch[1], 10) : NaN;
        if (!Number.isFinite(statusCode) || statusCode < 200 || statusCode >= 300)
            throw new Error(`Connection failed: HTTP ${statusCode}`);
        reader.releaseLock();
        if (有效数据长度(initialData) > 0) {
            const 远端写入器 = socket.writable.getWriter();
            await 远端写入器.write(initialData);
            远端写入器.releaseLock();
        }
        if (bytesRead > headerEndIndex) {
            const { readable, writable } = new TransformStream();
            const transformWriter = writable.getWriter();
            await transformWriter.write(responseBuffer.subarray(headerEndIndex, bytesRead));
            transformWriter.releaseLock();
            socket.readable.pipeTo(writable).catch(() => { });
            return { readable, writable: socket.writable, closed: socket.closed, close: () => socket.close() };
        }
        return socket;
    }
    catch (error) {
        try {
            writer.releaseLock();
        }
        catch (e) { }
        try {
            reader.releaseLock();
        }
        catch (e) { }
        try {
            socket.close();
        }
        catch (e) { }
        throw error;
    }
}
async function httpsConnect(targetHost, targetPort, initialData) {
    const { username, password, hostname, port } = parsedSocks5Address;
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    let tlsSocket = null;
    const tlsServerName = isIPHostname(hostname) ? '' : stripIPv6Brackets(hostname);
    const 打开HTTPS代理TLS = async (allowChacha = false) => {
        const proxySocket = connect({ hostname, port });
        try {
            await proxySocket.opened;
            const socket = new TlsClient(proxySocket, { serverName: tlsServerName, insecure: true, allowChacha });
            await socket.handshake();
            log(`[HTTPS代理] TLS版本: ${socket.isTls13 ? '1.3' : '1.2'} | Cipher: 0x${socket.cipherSuite.toString(16)}${socket.cipherConfig?.chacha ? ' (ChaCha20)' : ' (AES-GCM)'}`);
            return socket;
        }
        catch (error) {
            try {
                proxySocket.close();
            }
            catch (e) { }
            throw error;
        }
    };
    try {
        try {
            tlsSocket = await 打开HTTPS代理TLS(false);
        }
        catch (error) {
            if (!/cipher|handshake|TLS Alert|ServerHello|Finished|Unsupported|Missing TLS/i.test(error?.message || `${error || ''}`))
                throw error;
            log(`[HTTPS代理] AES-GCM TLS 握手失败，回退 ChaCha20 兼容模式: ${error?.message || error}`);
            tlsSocket = await 打开HTTPS代理TLS(true);
        }
        const auth = username && password ? `Proxy-Authorization: Basic ${btoa(`${username}:${password}`)}\r\n` : '';
        const request = `CONNECT ${targetHost}:${targetPort} HTTP/1.1\r\nHost: ${targetHost}:${targetPort}\r\n${auth}User-Agent: Mozilla/5.0\r\nConnection: keep-alive\r\n\r\n`;
        await tlsSocket.write(encoder.encode(request));
        let responseBuffer = new Uint8Array(0), headerEndIndex = -1, bytesRead = 0;
        while (headerEndIndex === -1 && bytesRead < 8192) {
            const value = await tlsSocket.read();
            if (!value)
                throw new Error('HTTPS 代理在返回 CONNECT 响应前关闭连接');
            responseBuffer = 拼接字节数据(responseBuffer, value);
            bytesRead = responseBuffer.length;
            const crlfcrlf = responseBuffer.findIndex((_, i) => i < responseBuffer.length - 3 && responseBuffer[i] === 0x0d && responseBuffer[i + 1] === 0x0a && responseBuffer[i + 2] === 0x0d && responseBuffer[i + 3] === 0x0a);
            if (crlfcrlf !== -1)
                headerEndIndex = crlfcrlf + 4;
        }
        if (headerEndIndex === -1)
            throw new Error('HTTPS 代理 CONNECT 响应头过长或无效');
        const statusMatch = decoder.decode(responseBuffer.slice(0, headerEndIndex)).split('\r\n')[0].match(/HTTP\/\d\.\d\s+(\d+)/);
        const statusCode = statusMatch ? parseInt(statusMatch[1], 10) : NaN;
        if (!Number.isFinite(statusCode) || statusCode < 200 || statusCode >= 300)
            throw new Error(`Connection failed: HTTP ${statusCode}`);
        if (有效数据长度(initialData) > 0)
            await tlsSocket.write(数据转Uint8Array(initialData));
        const bufferedData = bytesRead > headerEndIndex ? responseBuffer.subarray(headerEndIndex, bytesRead) : null;
        let closedSettled = false, resolveClosed, rejectClosed;
        const settleClosed = (settle, value) => {
            if (!closedSettled) {
                closedSettled = true;
                settle(value);
            }
        };
        const closed = new Promise((resolve, reject) => {
            resolveClosed = resolve;
            rejectClosed = reject;
        });
        const close = () => {
            try {
                tlsSocket.close();
            }
            catch (e) { }
            settleClosed(resolveClosed);
        };
        const readable = new ReadableStream({
            async start(controller) {
                try {
                    if (有效数据长度(bufferedData) > 0)
                        controller.enqueue(bufferedData);
                    while (true) {
                        const data = await tlsSocket.read();
                        if (!data)
                            break;
                        if (data.byteLength > 0)
                            controller.enqueue(data);
                    }
                    try {
                        controller.close();
                    }
                    catch (e) { }
                    settleClosed(resolveClosed);
                }
                catch (error) {
                    try {
                        controller.error(error);
                    }
                    catch (e) { }
                    settleClosed(rejectClosed, error);
                }
            },
            cancel() {
                close();
            }
        });
        const writable = new WritableStream({
            async write(chunk) {
                await tlsSocket.write(数据转Uint8Array(chunk));
            },
            close,
            abort(error) {
                close();
                if (error)
                    settleClosed(rejectClosed, error);
            }
        });
        return { readable, writable, closed, close };
    }
    catch (error) {
        try {
            tlsSocket?.close();
        }
        catch (e) { }
        throw error;
    }
}
const TLS_VERSION_10 = 769, TLS_VERSION_12 = 771, TLS_VERSION_13 = 772;
const CONTENT_TYPE_CHANGE_CIPHER_SPEC = 20, CONTENT_TYPE_ALERT = 21, CONTENT_TYPE_HANDSHAKE = 22, CONTENT_TYPE_APPLICATION_DATA = 23;
const HANDSHAKE_TYPE_CLIENT_HELLO = 1, HANDSHAKE_TYPE_SERVER_HELLO = 2, HANDSHAKE_TYPE_NEW_SESSION_TICKET = 4, HANDSHAKE_TYPE_ENCRYPTED_EXTENSIONS = 8, HANDSHAKE_TYPE_CERTIFICATE = 11, HANDSHAKE_TYPE_SERVER_KEY_EXCHANGE = 12, HANDSHAKE_TYPE_CERTIFICATE_REQUEST = 13, HANDSHAKE_TYPE_SERVER_HELLO_DONE = 14, HANDSHAKE_TYPE_CERTIFICATE_VERIFY = 15, HANDSHAKE_TYPE_CLIENT_KEY_EXCHANGE = 16, HANDSHAKE_TYPE_FINISHED = 20, HANDSHAKE_TYPE_KEY_UPDATE = 24;
const EXT_SERVER_NAME = 0, EXT_SUPPORTED_GROUPS = 10, EXT_EC_POINT_FORMATS = 11, EXT_SIGNATURE_ALGORITHMS = 13, EXT_APPLICATION_LAYER_PROTOCOL_NEGOTIATION = 16, EXT_SUPPORTED_VERSIONS = 43, EXT_PSK_KEY_EXCHANGE_MODES = 45, EXT_KEY_SHARE = 51;
const ALERT_CLOSE_NOTIFY = 0, ALERT_LEVEL_WARNING = 1, ALERT_UNRECOGNIZED_NAME = 112;
const shouldIgnoreTlsAlert = fragment => fragment?.[0] === ALERT_LEVEL_WARNING && fragment?.[1] === ALERT_UNRECOGNIZED_NAME;
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();
const EMPTY_BYTES = new Uint8Array(0);
const CIPHER_SUITES_BY_ID = new Map([
    [4865, { id: 4865, keyLen: 16, ivLen: 12, hash: "SHA-256", tls13: !0 }],
    [4866, { id: 4866, keyLen: 32, ivLen: 12, hash: "SHA-384", tls13: !0 }],
    [4867, { id: 4867, keyLen: 32, ivLen: 12, hash: "SHA-256", tls13: !0, chacha: !0 }],
    [49199, { id: 49199, keyLen: 16, ivLen: 4, hash: "SHA-256", kex: "ECDHE" }],
    [49200, { id: 49200, keyLen: 32, ivLen: 4, hash: "SHA-384", kex: "ECDHE" }],
    [52392, { id: 52392, keyLen: 32, ivLen: 12, hash: "SHA-256", kex: "ECDHE", chacha: !0 }],
    [49195, { id: 49195, keyLen: 16, ivLen: 4, hash: "SHA-256", kex: "ECDHE" }],
    [49196, { id: 49196, keyLen: 32, ivLen: 4, hash: "SHA-384", kex: "ECDHE" }],
    [52393, { id: 52393, keyLen: 32, ivLen: 12, hash: "SHA-256", kex: "ECDHE", chacha: !0 }]
]);
const GROUPS_BY_ID = new Map([[29, "X25519"], [23, "P-256"]]);
const SUPPORTED_SIGNATURE_ALGORITHMS = [2052, 2053, 2054, 1025, 1281, 1537, 1027, 1283, 1539];
const tlsBytes = (...parts) => {
    const flattenBytes = values => values.flatMap(value => value instanceof Uint8Array ? [...value] : Array.isArray(value) ? flattenBytes(value) : "number" == typeof value ? [value] : []);
    return new Uint8Array(flattenBytes(parts));
};
const uint16be = value => [value >> 8 & 255, 255 & value];
const readUint16 = (buffer, offset) => buffer[offset] << 8 | buffer[offset + 1];
const readUint24 = (buffer, offset) => buffer[offset] << 16 | buffer[offset + 1] << 8 | buffer[offset + 2];
const concatBytes = (...chunks) => {
    const nonEmptyChunks = chunks.filter((chunk => chunk && chunk.length > 0)), length = nonEmptyChunks.reduce(((total, chunk) => total + chunk.length), 0), result = new Uint8Array(length);
    let offset = 0;
    for (const chunk of nonEmptyChunks)
        result.set(chunk, offset), offset += chunk.length;
    return result;
};
const randomBytes = length => crypto.getRandomValues(new Uint8Array(length));
const constantTimeEqual = (left, right) => {
    if (!left || !right || left.length !== right.length)
        return !1;
    let diff = 0;
    for (let index = 0; index < left.length; index++)
        diff |= left[index] ^ right[index];
    return 0 === diff;
};
const hashByteLength = hash => "SHA-512" === hash ? 64 : "SHA-384" === hash ? 48 : 32;
async function hmac(hash, key, data) {
    const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash }, !1, ["sign"]);
    return new Uint8Array(await crypto.subtle.sign("HMAC", cryptoKey, data));
}
async function digestBytes(hash, data) { return new Uint8Array(await crypto.subtle.digest(hash, data)); }
async function tls12Prf(secret, label, seed, length, hash = "SHA-256") {
    const labelSeed = concatBytes(textEncoder.encode(label), seed);
    let output = new Uint8Array(0), currentA = labelSeed;
    for (; output.length < length;) {
        currentA = await hmac(hash, secret, currentA);
        const block = await hmac(hash, secret, concatBytes(currentA, labelSeed));
        output = concatBytes(output, block);
    }
    return output.slice(0, length);
}
async function hkdfExtract(hash, salt, inputKeyMaterial) {
    return salt && salt.length || (salt = new Uint8Array(hashByteLength(hash))), hmac(hash, salt, inputKeyMaterial);
}
async function hkdfExpandLabel(hash, secret, label, context, length) {
    const fullLabel = textEncoder.encode("tls13 " + label);
    return async function (hash, secret, info, length) {
        const hashLen = hashByteLength(hash), roundCount = Math.ceil(length / hashLen);
        let output = new Uint8Array(0), previousBlock = new Uint8Array(0);
        for (let round = 1; round <= roundCount; round++)
            previousBlock = await hmac(hash, secret, concatBytes(previousBlock, info, [round])), output = concatBytes(output, previousBlock);
        return output.slice(0, length);
    }(hash, secret, tlsBytes(uint16be(length), fullLabel.length, fullLabel, context.length, context), length);
}
async function generateKeyShare(group = "P-256") {
    const algorithm = "X25519" === group ? { name: "X25519" } : { name: "ECDH", namedCurve: group };
    const keyPair = (await crypto.subtle.generateKey(algorithm, !0, ["deriveBits"]));
    const publicKeyRaw = (await crypto.subtle.exportKey("raw", keyPair.publicKey));
    return { keyPair, publicKeyRaw: new Uint8Array(publicKeyRaw) };
}
async function deriveSharedSecret(privateKey, peerPublicKey, group = "P-256") {
    const algorithm = "X25519" === group ? { name: "X25519" } : { name: "ECDH", namedCurve: group }, peerKey = await crypto.subtle.importKey("raw", peerPublicKey, algorithm, !1, []), bits = "P-384" === group ? 384 : "P-521" === group ? 528 : 256;
    return new Uint8Array(await crypto.subtle.deriveBits(({ name: algorithm.name, public: peerKey }), privateKey, bits));
}
async function importAesGcmKey(key, usages) { return crypto.subtle.importKey("raw", key, { name: "AES-GCM" }, !1, usages); }
async function aesGcmEncryptWithKey(cryptoKey, initializationVector, plaintext, additionalData) {
    return new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: initializationVector, additionalData, tagLength: 128 }, cryptoKey, plaintext));
}
async function aesGcmDecryptWithKey(cryptoKey, initializationVector, ciphertext, additionalData) {
    return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: initializationVector, additionalData, tagLength: 128 }, cryptoKey, ciphertext));
}
function rotateLeft32(value, bits) { return (value << bits | value >>> 32 - bits) >>> 0; }
function chachaQuarterRound(state, indexA, indexB, indexC, indexD) {
    state[indexA] = state[indexA] + state[indexB] >>> 0, state[indexD] = rotateLeft32(state[indexD] ^ state[indexA], 16), state[indexC] = state[indexC] + state[indexD] >>> 0, state[indexB] = rotateLeft32(state[indexB] ^ state[indexC], 12), state[indexA] = state[indexA] + state[indexB] >>> 0, state[indexD] = rotateLeft32(state[indexD] ^ state[indexA], 8), state[indexC] = state[indexC] + state[indexD] >>> 0, state[indexB] = rotateLeft32(state[indexB] ^ state[indexC], 7);
}
function chacha20Block(key, counter, nonce) {
    const state = new Uint32Array(16);
    state[0] = 1634760805, state[1] = 857760878, state[2] = 2036477234, state[3] = 1797285236;
    const keyView = new DataView(key.buffer, key.byteOffset, key.byteLength);
    for (let wordIndex = 0; wordIndex < 8; wordIndex++)
        state[4 + wordIndex] = keyView.getUint32(4 * wordIndex, !0);
    state[12] = counter;
    const nonceView = new DataView(nonce.buffer, nonce.byteOffset, nonce.byteLength);
    state[13] = nonceView.getUint32(0, !0), state[14] = nonceView.getUint32(4, !0), state[15] = nonceView.getUint32(8, !0);
    const workingState = new Uint32Array(state);
    for (let round = 0; round < 10; round++)
        chachaQuarterRound(workingState, 0, 4, 8, 12), chachaQuarterRound(workingState, 1, 5, 9, 13), chachaQuarterRound(workingState, 2, 6, 10, 14), chachaQuarterRound(workingState, 3, 7, 11, 15), chachaQuarterRound(workingState, 0, 5, 10, 15), chachaQuarterRound(workingState, 1, 6, 11, 12), chachaQuarterRound(workingState, 2, 7, 8, 13), chachaQuarterRound(workingState, 3, 4, 9, 14);
    for (let wordIndex = 0; wordIndex < 16; wordIndex++)
        workingState[wordIndex] = workingState[wordIndex] + state[wordIndex] >>> 0;
    return new Uint8Array(workingState.buffer.slice(0));
}
function chacha20Xor(key, nonce, data) {
    const output = new Uint8Array(data.length);
    let counter = 1;
    for (let offset = 0; offset < data.length; offset += 64) {
        const block = chacha20Block(key, counter++, nonce), blockLength = Math.min(64, data.length - offset);
        for (let index = 0; index < blockLength; index++)
            output[offset + index] = data[offset + index] ^ block[index];
    }
    return output;
}
function poly1305Mac(key, message) {
    const rKey = function (rBytes) {
        const clamped = new Uint8Array(rBytes);
        return clamped[3] &= 15, clamped[7] &= 15, clamped[11] &= 15, clamped[15] &= 15, clamped[4] &= 252, clamped[8] &= 252, clamped[12] &= 252, clamped;
    }(key.slice(0, 16)), sKey = key.slice(16, 32);
    let accumulator = [0n, 0n, 0n, 0n, 0n];
    const rLimbs = [0x3ffffffn & BigInt(rKey[0] | rKey[1] << 8 | rKey[2] << 16 | rKey[3] << 24), 0x3ffffffn & BigInt(rKey[3] >> 2 | rKey[4] << 6 | rKey[5] << 14 | rKey[6] << 22), 0x3ffffffn & BigInt(rKey[6] >> 4 | rKey[7] << 4 | rKey[8] << 12 | rKey[9] << 20), 0x3ffffffn & BigInt(rKey[9] >> 6 | rKey[10] << 2 | rKey[11] << 10 | rKey[12] << 18), 0x3ffffffn & BigInt(rKey[13] | rKey[14] << 8 | rKey[15] << 16)];
    for (let offset = 0; offset < message.length; offset += 16) {
        const chunk = message.slice(offset, offset + 16), paddedChunk = new Uint8Array(17);
        paddedChunk.set(chunk), paddedChunk[chunk.length] = 1, accumulator[0] += BigInt(paddedChunk[0] | paddedChunk[1] << 8 | paddedChunk[2] << 16 | (3 & paddedChunk[3]) << 24), accumulator[1] += BigInt(paddedChunk[3] >> 2 | paddedChunk[4] << 6 | paddedChunk[5] << 14 | (15 & paddedChunk[6]) << 22), accumulator[2] += BigInt(paddedChunk[6] >> 4 | paddedChunk[7] << 4 | paddedChunk[8] << 12 | (63 & paddedChunk[9]) << 20), accumulator[3] += BigInt(paddedChunk[9] >> 6 | paddedChunk[10] << 2 | paddedChunk[11] << 10 | paddedChunk[12] << 18), accumulator[4] += BigInt(paddedChunk[13] | paddedChunk[14] << 8 | paddedChunk[15] << 16 | paddedChunk[16] << 24);
        const product = [0n, 0n, 0n, 0n, 0n];
        for (let accIndex = 0; accIndex < 5; accIndex++)
            for (let rIndex = 0; rIndex < 5; rIndex++) {
                const limbIndex = accIndex + rIndex;
                limbIndex < 5 ? product[limbIndex] += accumulator[accIndex] * rLimbs[rIndex] : product[limbIndex - 5] += accumulator[accIndex] * rLimbs[rIndex] * 5n;
            }
        let carry = 0n;
        for (let index = 0; index < 5; index++)
            product[index] += carry, accumulator[index] = 0x3ffffffn & product[index], carry = product[index] >> 26n;
        accumulator[0] += 5n * carry, carry = accumulator[0] >> 26n, accumulator[0] &= 0x3ffffffn, accumulator[1] += carry;
    }
    let tagValue = accumulator[0] | accumulator[1] << 26n | accumulator[2] << 52n | accumulator[3] << 78n | accumulator[4] << 104n;
    tagValue = tagValue + sKey.reduce(((total, byte, index) => total + (BigInt(byte) << BigInt(8 * index))), 0n) & (1n << 128n) - 1n;
    const tag = new Uint8Array(16);
    for (let index = 0; index < 16; index++)
        tag[index] = Number(tagValue >> BigInt(8 * index) & 0xffn);
    return tag;
}
function chacha20Poly1305Encrypt(key, nonce, plaintext, additionalData) {
    const polyKey = chacha20Block(key, 0, nonce).slice(0, 32), ciphertext = chacha20Xor(key, nonce, plaintext), aadPadding = (16 - additionalData.length % 16) % 16, ciphertextPadding = (16 - ciphertext.length % 16) % 16, macData = new Uint8Array(additionalData.length + aadPadding + ciphertext.length + ciphertextPadding + 16);
    macData.set(additionalData, 0), macData.set(ciphertext, additionalData.length + aadPadding);
    const lengthView = new DataView(macData.buffer, additionalData.length + aadPadding + ciphertext.length + ciphertextPadding);
    lengthView.setBigUint64(0, BigInt(additionalData.length), !0), lengthView.setBigUint64(8, BigInt(ciphertext.length), !0);
    const tag = poly1305Mac(polyKey, macData);
    return concatBytes(ciphertext, tag);
}
function chacha20Poly1305Decrypt(key, nonce, ciphertext, additionalData) {
    if (ciphertext.length < 16)
        throw new Error("Ciphertext too short");
    const tag = ciphertext.slice(-16), encryptedData = ciphertext.slice(0, -16), polyKey = chacha20Block(key, 0, nonce).slice(0, 32), aadPadding = (16 - additionalData.length % 16) % 16, ciphertextPadding = (16 - encryptedData.length % 16) % 16, macData = new Uint8Array(additionalData.length + aadPadding + encryptedData.length + ciphertextPadding + 16);
    macData.set(additionalData, 0), macData.set(encryptedData, additionalData.length + aadPadding);
    const lengthView = new DataView(macData.buffer, additionalData.length + aadPadding + encryptedData.length + ciphertextPadding);
    lengthView.setBigUint64(0, BigInt(additionalData.length), !0), lengthView.setBigUint64(8, BigInt(encryptedData.length), !0);
    const expectedTag = poly1305Mac(polyKey, macData);
    let diff = 0;
    for (let index = 0; index < 16; index++)
        diff |= tag[index] ^ expectedTag[index];
    if (0 !== diff)
        throw new Error("ChaCha20-Poly1305 authentication failed");
    return chacha20Xor(key, nonce, encryptedData);
}
const TLS_MAX_PLAINTEXT_FRAGMENT = 16 * 1024;
function buildTlsRecord(contentType, fragment, version = TLS_VERSION_12) {
    const data = 数据转Uint8Array(fragment);
    const record = new Uint8Array(5 + data.byteLength);
    record[0] = contentType;
    record[1] = version >> 8 & 255;
    record[2] = version & 255;
    record[3] = data.byteLength >> 8 & 255;
    record[4] = data.byteLength & 255;
    record.set(data, 5);
    return record;
}
function buildHandshakeMessage(handshakeType, body) { return tlsBytes(handshakeType, (length => [length >> 16 & 255, length >> 8 & 255, 255 & length])(body.length), body); }
class TlsRecordParser {
    constructor() { this.buffer = new Uint8Array(0); }
    feed(chunk) {
        const bytes = 数据转Uint8Array(chunk);
        this.buffer = this.buffer.length ? concatBytes(this.buffer, bytes) : bytes;
    }
    next() {
        if (this.buffer.length < 5)
            return null;
        const contentType = this.buffer[0], version = readUint16(this.buffer, 1), length = readUint16(this.buffer, 3);
        if (this.buffer.length < 5 + length)
            return null;
        const fragment = this.buffer.subarray(5, 5 + length);
        return this.buffer = this.buffer.subarray(5 + length), { type: contentType, version, length, fragment };
    }
}
class TlsHandshakeParser {
    constructor() { this.buffer = new Uint8Array(0); }
    feed(chunk) {
        const bytes = 数据转Uint8Array(chunk);
        this.buffer = this.buffer.length ? concatBytes(this.buffer, bytes) : bytes;
    }
    next() {
        if (this.buffer.length < 4)
            return null;
        const handshakeType = this.buffer[0], length = readUint24(this.buffer, 1);
        if (this.buffer.length < 4 + length)
            return null;
        const body = this.buffer.subarray(4, 4 + length), raw = this.buffer.subarray(0, 4 + length);
        return this.buffer = this.buffer.subarray(4 + length), { type: handshakeType, length, body, raw };
    }
}
function parseServerHello(body) {
    let offset = 0;
    const legacyVersion = readUint16(body, offset);
    offset += 2;
    const serverRandom = body.slice(offset, offset + 32);
    offset += 32;
    const sessionIdLength = body[offset++], sessionId = body.slice(offset, offset + sessionIdLength);
    offset += sessionIdLength;
    const cipherSuite = readUint16(body, offset);
    offset += 2;
    const compression = body[offset++];
    let selectedVersion = legacyVersion, keyShare = null, alpn = null;
    if (offset < body.length) {
        const extensionsLength = readUint16(body, offset);
        offset += 2;
        const extensionsEnd = offset + extensionsLength;
        for (; offset + 4 <= extensionsEnd;) {
            const extensionType = readUint16(body, offset);
            offset += 2;
            const extensionLength = readUint16(body, offset);
            offset += 2;
            const extensionData = body.slice(offset, offset + extensionLength);
            if (offset += extensionLength, extensionType === EXT_SUPPORTED_VERSIONS && extensionLength >= 2)
                selectedVersion = readUint16(extensionData, 0);
            else if (extensionType === EXT_KEY_SHARE && extensionLength >= 4) {
                const group = readUint16(extensionData, 0), keyLength = readUint16(extensionData, 2);
                keyShare = { group, key: extensionData.slice(4, 4 + keyLength) };
            }
            else
                extensionType === EXT_APPLICATION_LAYER_PROTOCOL_NEGOTIATION && extensionLength >= 3 && (alpn = textDecoder.decode(extensionData.slice(3, 3 + extensionData[2])));
        }
    }
    const helloRetryRequestRandom = new Uint8Array([207, 33, 173, 116, 229, 154, 97, 17, 190, 29, 140, 2, 30, 101, 184, 145, 194, 162, 17, 22, 122, 187, 140, 94, 7, 158, 9, 226, 200, 168, 51, 156]);
    return { version: legacyVersion, serverRandom, sessionId, cipherSuite, compression, selectedVersion, keyShare, alpn, isHRR: constantTimeEqual(serverRandom, helloRetryRequestRandom), isTls13: selectedVersion === TLS_VERSION_13 };
}
function parseServerKeyExchange(body) {
    let offset = 1;
    const namedCurve = readUint16(body, offset);
    offset += 2;
    const keyLength = body[offset++];
    return { namedCurve, serverPublicKey: body.slice(offset, offset + keyLength) };
}
function extractLeafCertificate(body, hasContext = 0) {
    let offset = 0;
    if (hasContext) {
        const contextLength = body[offset++];
        offset += contextLength;
    }
    if (offset + 3 > body.length)
        return null;
    const certificateListLength = readUint24(body, offset);
    if (offset += 3, !certificateListLength || offset + 3 > body.length)
        return null;
    const certificateLength = readUint24(body, offset);
    return offset += 3, certificateLength ? body.slice(offset, offset + certificateLength) : null;
}
function parseEncryptedExtensions(body) {
    const parsed = { alpn: null };
    let offset = 2;
    const extensionsEnd = 2 + readUint16(body, 0);
    for (; offset + 4 <= extensionsEnd;) {
        const extensionType = readUint16(body, offset);
        offset += 2;
        const extensionLength = readUint16(body, offset);
        if (offset += 2, extensionType === EXT_APPLICATION_LAYER_PROTOCOL_NEGOTIATION && extensionLength >= 3) {
            const protocolLength = body[offset + 2];
            protocolLength > 0 && offset + 3 + protocolLength <= offset + extensionLength && (parsed.alpn = textDecoder.decode(body.slice(offset + 3, offset + 3 + protocolLength)));
        }
        offset += extensionLength;
    }
    return parsed;
}
function buildClientHello(clientRandom, serverName, keyShares, { tls13: enableTls13 = !0, tls12: enableTls12 = !0, alpn = null, chacha = !0 } = {}) {
    const cipherIds = [];
    enableTls13 && cipherIds.push(4865, 4866, ...(chacha ? [4867] : [])), enableTls12 && cipherIds.push(49199, 49200, 49195, 49196, ...(chacha ? [52392, 52393] : []));
    const cipherBytes = tlsBytes(...cipherIds.flatMap(uint16be)), extensions = [tlsBytes(255, 1, 0, 1, 0)];
    if (serverName) {
        const serverNameBytes = textEncoder.encode(serverName), serverNameList = tlsBytes(0, uint16be(serverNameBytes.length), serverNameBytes);
        extensions.push(tlsBytes(uint16be(EXT_SERVER_NAME), uint16be(serverNameList.length + 2), uint16be(serverNameList.length), serverNameList));
    }
    extensions.push(tlsBytes(uint16be(EXT_EC_POINT_FORMATS), 0, 2, 1, 0)), extensions.push(tlsBytes(uint16be(EXT_SUPPORTED_GROUPS), 0, 6, 0, 4, 0, 29, 0, 23));
    const signatureBytes = tlsBytes(...SUPPORTED_SIGNATURE_ALGORITHMS.flatMap(uint16be));
    extensions.push(tlsBytes(uint16be(EXT_SIGNATURE_ALGORITHMS), uint16be(signatureBytes.length + 2), uint16be(signatureBytes.length), signatureBytes));
    const protocols = Array.isArray(alpn) ? alpn.filter(Boolean) : alpn ? [alpn] : [];
    if (protocols.length) {
        const alpnBytes = concatBytes(...protocols.map((protocol => { const protocolBytes = textEncoder.encode(protocol); return tlsBytes(protocolBytes.length, protocolBytes); })));
        extensions.push(tlsBytes(uint16be(EXT_APPLICATION_LAYER_PROTOCOL_NEGOTIATION), uint16be(alpnBytes.length + 2), uint16be(alpnBytes.length), alpnBytes));
    }
    if (enableTls13 && keyShares) {
        let keyShareBytes;
        if (extensions.push(enableTls12 ? tlsBytes(uint16be(EXT_SUPPORTED_VERSIONS), 0, 5, 4, 3, 4, 3, 3) : tlsBytes(uint16be(EXT_SUPPORTED_VERSIONS), 0, 3, 2, 3, 4)), extensions.push(tlsBytes(uint16be(EXT_PSK_KEY_EXCHANGE_MODES), 0, 2, 1, 1)), keyShares?.x25519 && keyShares?.p256)
            keyShareBytes = concatBytes(tlsBytes(0, 29, uint16be(keyShares.x25519.length), keyShares.x25519), tlsBytes(0, 23, uint16be(keyShares.p256.length), keyShares.p256));
        else if (keyShares?.x25519)
            keyShareBytes = tlsBytes(0, 29, uint16be(keyShares.x25519.length), keyShares.x25519);
        else if (keyShares?.p256)
            keyShareBytes = tlsBytes(0, 23, uint16be(keyShares.p256.length), keyShares.p256);
        else {
            if (!(keyShares instanceof Uint8Array))
                throw new Error("Invalid keyShares");
            keyShareBytes = tlsBytes(0, 23, uint16be(keyShares.length), keyShares);
        }
        extensions.push(tlsBytes(uint16be(EXT_KEY_SHARE), uint16be(keyShareBytes.length + 2), uint16be(keyShareBytes.length), keyShareBytes));
    }
    const extensionsBytes = concatBytes(...extensions);
    return buildHandshakeMessage(HANDSHAKE_TYPE_CLIENT_HELLO, tlsBytes(uint16be(TLS_VERSION_12), clientRandom, 0, uint16be(cipherBytes.length), cipherBytes, 1, 0, uint16be(extensionsBytes.length), extensionsBytes));
}
const uint64be = sequenceNumber => { const bytes = new Uint8Array(8); return new DataView(bytes.buffer).setBigUint64(0, sequenceNumber, !1), bytes; }, xorSequenceIntoIv = (initializationVector, sequenceNumber) => {
    const nonce = initializationVector.slice(), sequenceBytes = uint64be(sequenceNumber);
    for (let index = 0; index < 8; index++)
        nonce[nonce.length - 8 + index] ^= sequenceBytes[index];
    return nonce;
}, deriveTrafficKeys = (hash, secret, keyLen, ivLen) => Promise.all([hkdfExpandLabel(hash, secret, "key", EMPTY_BYTES, keyLen), hkdfExpandLabel(hash, secret, "iv", EMPTY_BYTES, ivLen)]);
class TlsClient {
    constructor(socket, options = {}) {
        if (this.socket = socket, this.serverName = options.serverName || "", this.supportTls13 = !1 !== options.tls13, this.supportTls12 = !1 !== options.tls12, !this.supportTls13 && !this.supportTls12)
            throw new Error("At least one TLS version must be enabled");
        this.alpnProtocols = Array.isArray(options.alpn) ? options.alpn : options.alpn ? [options.alpn] : null, this.allowChacha = options.allowChacha !== false, this.timeout = options.timeout ?? 3e4, this.clientRandom = randomBytes(32), this.serverRandom = null, this.handshakeChunks = [], this.handshakeComplete = !1, this.negotiatedAlpn = null, this.cipherSuite = null, this.cipherConfig = null, this.isTls13 = !1, this.masterSecret = null, this.handshakeSecret = null, this.clientWriteKey = null, this.serverWriteKey = null, this.clientWriteIv = null, this.serverWriteIv = null, this.clientHandshakeKey = null, this.serverHandshakeKey = null, this.clientHandshakeIv = null, this.serverHandshakeIv = null, this.clientAppKey = null, this.serverAppKey = null, this.clientAppIv = null, this.serverAppIv = null, this.clientWriteCryptoKey = null, this.serverWriteCryptoKey = null, this.clientHandshakeCryptoKey = null, this.serverHandshakeCryptoKey = null, this.clientAppCryptoKey = null, this.serverAppCryptoKey = null, this.clientSeqNum = 0n, this.serverSeqNum = 0n, this.recordParser = new TlsRecordParser, this.handshakeParser = new TlsHandshakeParser, this.keyPairs = new Map, this.ecdhKeyPair = null, this.sawCert = !1;
    }
    recordHandshake(chunk) { this.handshakeChunks.push(chunk); }
    transcript() { return 1 === this.handshakeChunks.length ? this.handshakeChunks[0] : concatBytes(...this.handshakeChunks); }
    getCipherConfig(cipherSuite) { return CIPHER_SUITES_BY_ID.get(cipherSuite) || null; }
    async readChunk(reader) { return this.timeout ? Promise.race([reader.read(), new Promise(((resolve, reject) => setTimeout((() => reject(new Error("TLS read timeout"))), this.timeout)))]) : reader.read(); }
    async readRecordsUntil(reader, predicate, closedError) {
        for (;;) {
            let record;
            for (; record = this.recordParser.next();)
                if (await predicate(record))
                    return;
            const { value, done } = await this.readChunk(reader);
            if (done)
                throw new Error(closedError);
            this.recordParser.feed(value);
        }
    }
    async readHandshakeUntil(reader, predicate, closedError) {
        for (let message; message = this.handshakeParser.next();)
            if (await predicate(message))
                return;
        return this.readRecordsUntil(reader, (async (record) => {
            if (record.type === CONTENT_TYPE_ALERT) {
                if (shouldIgnoreTlsAlert(record.fragment))
                    return;
                throw new Error(`TLS Alert: ${record.fragment[1]}`);
            }
            if (record.type === CONTENT_TYPE_HANDSHAKE) {
                this.handshakeParser.feed(record.fragment);
                for (let message; message = this.handshakeParser.next();)
                    if (await predicate(message))
                        return 1;
            }
        }), closedError);
    }
    async acceptCertificate(certificate) { if (!certificate?.length)
        throw new Error("Empty certificate"); this.sawCert = !0; }
    async handshake() {
        const [p256Share, x25519Share] = await Promise.all([generateKeyShare("P-256"), generateKeyShare("X25519")]);
        this.keyPairs = new Map([[23, p256Share], [29, x25519Share]]), this.ecdhKeyPair = p256Share.keyPair;
        const reader = this.socket.readable.getReader(), writer = this.socket.writable.getWriter();
        try {
            const clientHello = buildClientHello(this.clientRandom, this.serverName, { x25519: x25519Share.publicKeyRaw, p256: p256Share.publicKeyRaw }, { tls13: this.supportTls13, tls12: this.supportTls12, alpn: this.alpnProtocols, chacha: this.allowChacha });
            this.recordHandshake(clientHello), await writer.write(buildTlsRecord(CONTENT_TYPE_HANDSHAKE, clientHello, TLS_VERSION_10));
            const serverHello = await this.receiveServerHello(reader);
            if (serverHello.isHRR)
                throw new Error("HelloRetryRequest is not supported by TLSClientMini");
            if (serverHello.keyShare?.group && this.keyPairs.has(serverHello.keyShare.group)) {
                const selectedKeyPair = this.keyPairs.get(serverHello.keyShare.group);
                this.ecdhKeyPair = selectedKeyPair.keyPair;
            }
            serverHello.isTls13 ? await this.handshakeTls13(reader, writer, serverHello) : await this.handshakeTls12(reader, writer), this.handshakeComplete = !0;
        }
        finally {
            reader.releaseLock(), writer.releaseLock();
        }
    }
    async receiveServerHello(reader) {
        for (;;) {
            const { value, done } = await this.readChunk(reader);
            if (done)
                throw new Error("Connection closed waiting for ServerHello");
            let record;
            for (this.recordParser.feed(value); record = this.recordParser.next();) {
                if (record.type === CONTENT_TYPE_ALERT) {
                    if (shouldIgnoreTlsAlert(record.fragment))
                        continue;
                    throw new Error(`TLS Alert: level=${record.fragment[0]}, desc=${record.fragment[1]}`);
                }
                if (record.type !== CONTENT_TYPE_HANDSHAKE)
                    continue;
                let message;
                for (this.handshakeParser.feed(record.fragment); message = this.handshakeParser.next();) {
                    if (message.type !== HANDSHAKE_TYPE_SERVER_HELLO)
                        continue;
                    this.recordHandshake(message.raw);
                    const serverHello = parseServerHello(message.body);
                    if (this.serverRandom = serverHello.serverRandom, this.cipherSuite = serverHello.cipherSuite, this.cipherConfig = this.getCipherConfig(serverHello.cipherSuite), this.isTls13 = serverHello.isTls13, this.negotiatedAlpn = serverHello.alpn || null, !this.cipherConfig)
                        throw new Error(`Unsupported cipher suite: 0x${serverHello.cipherSuite.toString(16)}`);
                    return serverHello;
                }
            }
        }
    }
    async handshakeTls12(reader, writer) {
        let serverKeyExchange = null;
        let sawServerHelloDone = !1;
        if (await this.readHandshakeUntil(reader, (async (message) => {
            switch (message.type) {
                case HANDSHAKE_TYPE_CERTIFICATE: {
                    this.recordHandshake(message.raw);
                    const certificate = extractLeafCertificate(message.body, 1);
                    if (!certificate)
                        throw new Error("Missing TLS 1.2 certificate");
                    await this.acceptCertificate(certificate);
                    break;
                }
                case HANDSHAKE_TYPE_SERVER_KEY_EXCHANGE:
                    this.recordHandshake(message.raw), serverKeyExchange = parseServerKeyExchange(message.body);
                    break;
                case HANDSHAKE_TYPE_SERVER_HELLO_DONE:
                    return this.recordHandshake(message.raw), sawServerHelloDone = !0, 1;
                case HANDSHAKE_TYPE_CERTIFICATE_REQUEST:
                    throw new Error("Client certificate is not supported");
                default:
                    this.recordHandshake(message.raw);
            }
        }), "Connection closed during TLS 1.2 handshake"), !this.sawCert)
            throw new Error("Missing TLS 1.2 leaf certificate");
        const serverKeyExchangeData = (serverKeyExchange);
        if (!serverKeyExchangeData)
            throw new Error("Missing TLS 1.2 ServerKeyExchange");
        const curveName = GROUPS_BY_ID.get(serverKeyExchangeData.namedCurve);
        if (!curveName)
            throw new Error(`Unsupported named curve: 0x${serverKeyExchangeData.namedCurve.toString(16)}`);
        const keyShare = this.keyPairs.get(serverKeyExchangeData.namedCurve);
        if (!keyShare)
            throw new Error(`Missing key pair for curve: 0x${serverKeyExchangeData.namedCurve.toString(16)}`);
        const preMasterSecret = await deriveSharedSecret(keyShare.keyPair.privateKey, serverKeyExchangeData.serverPublicKey, curveName), clientKeyExchange = buildHandshakeMessage(HANDSHAKE_TYPE_CLIENT_KEY_EXCHANGE, tlsBytes(keyShare.publicKeyRaw.length, keyShare.publicKeyRaw));
        this.recordHandshake(clientKeyExchange);
        const hashName = this.cipherConfig.hash;
        this.masterSecret = await tls12Prf(preMasterSecret, "master secret", concatBytes(this.clientRandom, this.serverRandom), 48, hashName);
        const keyLen = this.cipherConfig.keyLen, ivLen = this.cipherConfig.ivLen, keyBlock = await tls12Prf(this.masterSecret, "key expansion", concatBytes(this.serverRandom, this.clientRandom), 2 * keyLen + 2 * ivLen, hashName);
        this.clientWriteKey = keyBlock.slice(0, keyLen), this.serverWriteKey = keyBlock.slice(keyLen, 2 * keyLen), this.clientWriteIv = keyBlock.slice(2 * keyLen, 2 * keyLen + ivLen), this.serverWriteIv = keyBlock.slice(2 * keyLen + ivLen, 2 * keyLen + 2 * ivLen);
        if (!this.cipherConfig.chacha)
            [this.clientWriteCryptoKey, this.serverWriteCryptoKey] = await Promise.all([importAesGcmKey(this.clientWriteKey, ["encrypt"]), importAesGcmKey(this.serverWriteKey, ["decrypt"])]);
        await writer.write(buildTlsRecord(CONTENT_TYPE_HANDSHAKE, clientKeyExchange)), await writer.write(buildTlsRecord(CONTENT_TYPE_CHANGE_CIPHER_SPEC, tlsBytes(1)));
        const clientVerifyData = await tls12Prf(this.masterSecret, "client finished", await digestBytes(hashName, this.transcript()), 12, hashName), finishedMessage = buildHandshakeMessage(HANDSHAKE_TYPE_FINISHED, clientVerifyData);
        this.recordHandshake(finishedMessage), await writer.write(buildTlsRecord(CONTENT_TYPE_HANDSHAKE, await this.encryptTls12(finishedMessage, CONTENT_TYPE_HANDSHAKE)));
        let sawChangeCipherSpec = !1;
        await this.readRecordsUntil(reader, (async (record) => {
            if (record.type === CONTENT_TYPE_ALERT) {
                if (shouldIgnoreTlsAlert(record.fragment))
                    return;
                throw new Error(`TLS Alert: ${record.fragment[1]}`);
            }
            if (record.type === CONTENT_TYPE_CHANGE_CIPHER_SPEC)
                return void (sawChangeCipherSpec = !0);
            if (record.type !== CONTENT_TYPE_HANDSHAKE || !sawChangeCipherSpec)
                return;
            const decrypted = await this.decryptTls12(record.fragment, CONTENT_TYPE_HANDSHAKE);
            if (decrypted[0] !== HANDSHAKE_TYPE_FINISHED)
                return;
            const verifyLength = readUint24(decrypted, 1), verifyData = decrypted.slice(4, 4 + verifyLength), expectedVerifyData = await tls12Prf(this.masterSecret, "server finished", await digestBytes(hashName, this.transcript()), 12, hashName);
            if (!constantTimeEqual(verifyData, expectedVerifyData))
                throw new Error("TLS 1.2 server Finished verify failed");
            return 1;
        }), "Connection closed waiting for TLS 1.2 Finished");
    }
    async handshakeTls13(reader, writer, serverHello) {
        const groupName = GROUPS_BY_ID.get(serverHello.keyShare?.group);
        if (!groupName || !serverHello.keyShare?.key?.length)
            throw new Error("Missing TLS 1.3 key_share");
        const hashName = this.cipherConfig.hash, hashLen = hashByteLength(hashName), keyLen = this.cipherConfig.keyLen, ivLen = this.cipherConfig.ivLen, sharedSecret = await deriveSharedSecret(this.ecdhKeyPair.privateKey, serverHello.keyShare.key, groupName), earlySecret = await hkdfExtract(hashName, null, new Uint8Array(hashLen)), derivedSecret = await hkdfExpandLabel(hashName, earlySecret, "derived", await digestBytes(hashName, EMPTY_BYTES), hashLen);
        this.handshakeSecret = await hkdfExtract(hashName, derivedSecret, sharedSecret);
        const transcriptHash = await digestBytes(hashName, this.transcript()), clientHandshakeTrafficSecret = await hkdfExpandLabel(hashName, this.handshakeSecret, "c hs traffic", transcriptHash, hashLen), serverHandshakeTrafficSecret = await hkdfExpandLabel(hashName, this.handshakeSecret, "s hs traffic", transcriptHash, hashLen);
        [this.clientHandshakeKey, this.clientHandshakeIv] = await deriveTrafficKeys(hashName, clientHandshakeTrafficSecret, keyLen, ivLen), [this.serverHandshakeKey, this.serverHandshakeIv] = await deriveTrafficKeys(hashName, serverHandshakeTrafficSecret, keyLen, ivLen);
        if (!this.cipherConfig.chacha)
            [this.clientHandshakeCryptoKey, this.serverHandshakeCryptoKey] = await Promise.all([importAesGcmKey(this.clientHandshakeKey, ["encrypt"]), importAesGcmKey(this.serverHandshakeKey, ["decrypt"])]);
        const serverFinishedKey = await hkdfExpandLabel(hashName, serverHandshakeTrafficSecret, "finished", EMPTY_BYTES, hashLen);
        let serverFinishedReceived = !1;
        const handleHandshakeMessage = async (message) => {
            switch (message.type) {
                case HANDSHAKE_TYPE_ENCRYPTED_EXTENSIONS: {
                    const encryptedExtensions = parseEncryptedExtensions(message.body);
                    encryptedExtensions.alpn && (this.negotiatedAlpn = encryptedExtensions.alpn), this.recordHandshake(message.raw);
                    break;
                }
                case HANDSHAKE_TYPE_CERTIFICATE: {
                    const certificate = extractLeafCertificate(message.body);
                    if (!certificate)
                        throw new Error("Missing TLS 1.3 certificate");
                    await this.acceptCertificate(certificate), this.recordHandshake(message.raw);
                    break;
                }
                case HANDSHAKE_TYPE_CERTIFICATE_REQUEST:
                    throw new Error("Client certificate is not supported");
                case HANDSHAKE_TYPE_CERTIFICATE_VERIFY:
                    this.recordHandshake(message.raw);
                    break;
                case HANDSHAKE_TYPE_FINISHED: {
                    const expectedVerifyData = await hmac(hashName, serverFinishedKey, await digestBytes(hashName, this.transcript()));
                    if (!constantTimeEqual(expectedVerifyData, message.body))
                        throw new Error("TLS 1.3 server Finished verify failed");
                    this.recordHandshake(message.raw), serverFinishedReceived = !0;
                    break;
                }
                default:
                    this.recordHandshake(message.raw);
            }
        };
        await this.readRecordsUntil(reader, (async (record) => {
            if (record.type === CONTENT_TYPE_CHANGE_CIPHER_SPEC || record.type === CONTENT_TYPE_HANDSHAKE)
                return;
            if (record.type === CONTENT_TYPE_ALERT) {
                if (shouldIgnoreTlsAlert(record.fragment))
                    return;
                throw new Error(`TLS Alert: ${record.fragment[1]}`);
            }
            if (record.type !== CONTENT_TYPE_APPLICATION_DATA)
                return;
            const decrypted = await this.decryptTls13Handshake(record.fragment), innerType = decrypted[decrypted.length - 1], plaintext = decrypted.slice(0, -1);
            if (innerType === CONTENT_TYPE_HANDSHAKE) {
                this.handshakeParser.feed(plaintext);
                for (let message; message = this.handshakeParser.next();)
                    if (await handleHandshakeMessage(message), serverFinishedReceived)
                        return 1;
            }
        }), "Connection closed during TLS 1.3 handshake");
        const applicationTranscriptHash = await digestBytes(hashName, this.transcript()), masterDerivedSecret = await hkdfExpandLabel(hashName, this.handshakeSecret, "derived", await digestBytes(hashName, EMPTY_BYTES), hashLen), masterSecret = await hkdfExtract(hashName, masterDerivedSecret, new Uint8Array(hashLen)), clientAppTrafficSecret = await hkdfExpandLabel(hashName, masterSecret, "c ap traffic", applicationTranscriptHash, hashLen), serverAppTrafficSecret = await hkdfExpandLabel(hashName, masterSecret, "s ap traffic", applicationTranscriptHash, hashLen);
        [this.clientAppKey, this.clientAppIv] = await deriveTrafficKeys(hashName, clientAppTrafficSecret, keyLen, ivLen), [this.serverAppKey, this.serverAppIv] = await deriveTrafficKeys(hashName, serverAppTrafficSecret, keyLen, ivLen);
        if (!this.cipherConfig.chacha)
            [this.clientAppCryptoKey, this.serverAppCryptoKey] = await Promise.all([importAesGcmKey(this.clientAppKey, ["encrypt"]), importAesGcmKey(this.serverAppKey, ["decrypt"])]);
        const clientFinishedKey = await hkdfExpandLabel(hashName, clientHandshakeTrafficSecret, "finished", EMPTY_BYTES, hashLen), clientFinishedVerifyData = await hmac(hashName, clientFinishedKey, await digestBytes(hashName, this.transcript())), clientFinishedMessage = buildHandshakeMessage(HANDSHAKE_TYPE_FINISHED, clientFinishedVerifyData);
        this.recordHandshake(clientFinishedMessage), await writer.write(buildTlsRecord(CONTENT_TYPE_APPLICATION_DATA, await this.encryptTls13Handshake(concatBytes(clientFinishedMessage, [CONTENT_TYPE_HANDSHAKE])))), this.clientSeqNum = 0n, this.serverSeqNum = 0n;
    }
    async encryptTls12(plaintext, contentType) {
        const sequenceNumber = this.clientSeqNum++, sequenceBytes = uint64be(sequenceNumber), additionalData = concatBytes(sequenceBytes, [contentType], uint16be(TLS_VERSION_12), uint16be(plaintext.length));
        if (this.cipherConfig.chacha) {
            const nonce = xorSequenceIntoIv(this.clientWriteIv, sequenceNumber);
            return chacha20Poly1305Encrypt(this.clientWriteKey, nonce, plaintext, additionalData);
        }
        const explicitNonce = randomBytes(8);
        if (!this.clientWriteCryptoKey)
            this.clientWriteCryptoKey = await importAesGcmKey(this.clientWriteKey, ["encrypt"]);
        return concatBytes(explicitNonce, await aesGcmEncryptWithKey(this.clientWriteCryptoKey, concatBytes(this.clientWriteIv, explicitNonce), plaintext, additionalData));
    }
    async decryptTls12(ciphertext, contentType) {
        const sequenceNumber = this.serverSeqNum++, sequenceBytes = uint64be(sequenceNumber);
        if (this.cipherConfig.chacha) {
            const nonce = xorSequenceIntoIv(this.serverWriteIv, sequenceNumber);
            return chacha20Poly1305Decrypt(this.serverWriteKey, nonce, ciphertext, concatBytes(sequenceBytes, [contentType], uint16be(TLS_VERSION_12), uint16be(ciphertext.length - 16)));
        }
        const explicitNonce = ciphertext.subarray(0, 8), encryptedData = ciphertext.subarray(8);
        if (!this.serverWriteCryptoKey)
            this.serverWriteCryptoKey = await importAesGcmKey(this.serverWriteKey, ["decrypt"]);
        return aesGcmDecryptWithKey(this.serverWriteCryptoKey, concatBytes(this.serverWriteIv, explicitNonce), encryptedData, concatBytes(sequenceBytes, [contentType], uint16be(TLS_VERSION_12), uint16be(encryptedData.length - 16)));
    }
    async encryptTls13Handshake(plaintext) {
        const nonce = xorSequenceIntoIv(this.clientHandshakeIv, this.clientSeqNum++), additionalData = tlsBytes(CONTENT_TYPE_APPLICATION_DATA, 3, 3, uint16be(plaintext.length + 16));
        if (this.cipherConfig.chacha)
            return chacha20Poly1305Encrypt(this.clientHandshakeKey, nonce, plaintext, additionalData);
        if (!this.clientHandshakeCryptoKey)
            this.clientHandshakeCryptoKey = await importAesGcmKey(this.clientHandshakeKey, ["encrypt"]);
        return aesGcmEncryptWithKey(this.clientHandshakeCryptoKey, nonce, plaintext, additionalData);
    }
    async decryptTls13Handshake(ciphertext) {
        const nonce = xorSequenceIntoIv(this.serverHandshakeIv, this.serverSeqNum++), additionalData = tlsBytes(CONTENT_TYPE_APPLICATION_DATA, 3, 3, uint16be(ciphertext.length));
        const decrypted = this.cipherConfig.chacha ? await chacha20Poly1305Decrypt(this.serverHandshakeKey, nonce, ciphertext, additionalData) : await aesGcmDecryptWithKey(this.serverHandshakeCryptoKey || (this.serverHandshakeCryptoKey = await importAesGcmKey(this.serverHandshakeKey, ["decrypt"])), nonce, ciphertext, additionalData);
        let innerTypeIndex = decrypted.length - 1;
        for (; innerTypeIndex >= 0 && !decrypted[innerTypeIndex];)
            innerTypeIndex--;
        return innerTypeIndex < 0 ? EMPTY_BYTES : decrypted.slice(0, innerTypeIndex + 1);
    }
    async encryptTls13(data) {
        const plaintext = concatBytes(data, [CONTENT_TYPE_APPLICATION_DATA]), nonce = xorSequenceIntoIv(this.clientAppIv, this.clientSeqNum++), additionalData = tlsBytes(CONTENT_TYPE_APPLICATION_DATA, 3, 3, uint16be(plaintext.length + 16));
        if (this.cipherConfig.chacha)
            return chacha20Poly1305Encrypt(this.clientAppKey, nonce, plaintext, additionalData);
        if (!this.clientAppCryptoKey)
            this.clientAppCryptoKey = await importAesGcmKey(this.clientAppKey, ["encrypt"]);
        return aesGcmEncryptWithKey(this.clientAppCryptoKey, nonce, plaintext, additionalData);
    }
    async decryptTls13(ciphertext) {
        const nonce = xorSequenceIntoIv(this.serverAppIv, this.serverSeqNum++), additionalData = tlsBytes(CONTENT_TYPE_APPLICATION_DATA, 3, 3, uint16be(ciphertext.length)), plaintext = this.cipherConfig.chacha ? await chacha20Poly1305Decrypt(this.serverAppKey, nonce, ciphertext, additionalData) : await aesGcmDecryptWithKey(this.serverAppCryptoKey || (this.serverAppCryptoKey = await importAesGcmKey(this.serverAppKey, ["decrypt"])), nonce, ciphertext, additionalData);
        let innerTypeIndex = plaintext.length - 1;
        for (; innerTypeIndex >= 0 && !plaintext[innerTypeIndex];)
            innerTypeIndex--;
        if (innerTypeIndex < 0)
            return {
                data: EMPTY_BYTES,
                type: 0
            };
        return {
            data: plaintext.slice(0, innerTypeIndex),
            type: plaintext[innerTypeIndex]
        };
    }
    async write(data) {
        if (!this.handshakeComplete)
            throw new Error("Handshake not complete");
        const plaintext = 数据转Uint8Array(data);
        if (!plaintext.byteLength)
            return;
        const writer = this.socket.writable.getWriter();
        try {
            const records = [];
            for (let offset = 0; offset < plaintext.byteLength; offset += TLS_MAX_PLAINTEXT_FRAGMENT) {
                const chunk = plaintext.subarray(offset, Math.min(offset + TLS_MAX_PLAINTEXT_FRAGMENT, plaintext.byteLength));
                const encrypted = this.isTls13 ? await this.encryptTls13(chunk) : await this.encryptTls12(chunk, CONTENT_TYPE_APPLICATION_DATA);
                records.push(buildTlsRecord(CONTENT_TYPE_APPLICATION_DATA, encrypted));
            }
            await writer.write(records.length === 1 ? records[0] : concatBytes(...records));
        }
        finally {
            writer.releaseLock();
        }
    }
    async read() {
        for (;;) {
            let record;
            for (; record = this.recordParser.next();) {
                if (record.type === CONTENT_TYPE_ALERT) {
                    if (record.fragment[1] === ALERT_CLOSE_NOTIFY)
                        return null;
                    throw new Error(`TLS Alert: ${record.fragment[1]}`);
                }
                if (record.type !== CONTENT_TYPE_APPLICATION_DATA)
                    continue;
                if (!this.isTls13)
                    return this.decryptTls12(record.fragment, CONTENT_TYPE_APPLICATION_DATA);
                const { data, type } = await this.decryptTls13(record.fragment);
                if (type === CONTENT_TYPE_APPLICATION_DATA)
                    return data;
                if (type === CONTENT_TYPE_ALERT) {
                    if (data[1] === ALERT_CLOSE_NOTIFY)
                        return null;
                    throw new Error(`TLS Alert: ${data[1]}`);
                }
                if (type !== CONTENT_TYPE_HANDSHAKE)
                    continue;
                let message;
                for (this.handshakeParser.feed(data); message = this.handshakeParser.next();)
                    if (message.type !== HANDSHAKE_TYPE_NEW_SESSION_TICKET && message.type === HANDSHAKE_TYPE_KEY_UPDATE)
                        throw new Error("TLS 1.3 KeyUpdate is not supported by TLSClientMini");
            }
            const reader = this.socket.readable.getReader();
            try {
                const { value, done } = await this.readChunk(reader);
                if (done)
                    return null;
                this.recordParser.feed(value);
            }
            finally {
                reader.releaseLock();
            }
        }
    }
    close() { this.socket.close(); }
}
function stripIPv6Brackets(hostname = '') {
    const host = String(hostname || '').trim();
    return host.startsWith('[') && host.endsWith(']') ? host.slice(1, -1) : host;
}
function isIPHostname(hostname = '') {
    const host = stripIPv6Brackets(hostname);
    const ipv4Regex = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
    if (ipv4Regex.test(host))
        return true;
    if (!host.includes(':'))
        return false;
    try {
        new URL(`http://[${host}]/`);
        return true;
    }
    catch (e) {
        return false;
    }
}
const CONNECT_TIMEOUT_MS = 9999;
const TURN_STUN_MAGIC_COOKIE = new Uint8Array([0x21, 0x12, 0xa4, 0x42]);
const TURN_STUN_TYPE = {
    ALLOCATE_REQUEST: 0x0003, ALLOCATE_SUCCESS: 0x0103, ALLOCATE_ERROR: 0x0113,
    CREATE_PERMISSION_REQUEST: 0x0008, CREATE_PERMISSION_SUCCESS: 0x0108,
    CONNECT_REQUEST: 0x000a, CONNECT_SUCCESS: 0x010a,
    CONNECTION_BIND_REQUEST: 0x000b, CONNECTION_BIND_SUCCESS: 0x010b
};
const TURN_STUN_ATTR = {
    USERNAME: 0x0006, MESSAGE_INTEGRITY: 0x0008, ERROR_CODE: 0x0009,
    XOR_PEER_ADDRESS: 0x0012, REALM: 0x0014, NONCE: 0x0015,
    REQUESTED_TRANSPORT: 0x0019, CONNECTION_ID: 0x002a
};
async function withTimeout(promise, timeoutMs, message) {
    let timer;
    try {
        return await Promise.race([
            promise,
            new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), timeoutMs); })
        ]);
    }
    finally {
        clearTimeout(timer);
    }
}
function isIPv4(value) {
    const parts = String(value || '').split('.');
    return parts.length === 4 && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) >= 0 && Number(part) <= 255);
}
function turnStunPadding(length) {
    return -length & 3;
}
function createTurnStunAttribute(type, value) {
    const body = 数据转Uint8Array(value);
    const attribute = new Uint8Array(4 + body.byteLength + turnStunPadding(body.byteLength));
    const view = new DataView(attribute.buffer);
    view.setUint16(0, type);
    view.setUint16(2, body.byteLength);
    attribute.set(body, 4);
    return attribute;
}
function createTurnStunMessage(type, transactionId, attributes) {
    const body = 拼接字节数据(...attributes);
    const header = new Uint8Array(20);
    const view = new DataView(header.buffer);
    view.setUint16(0, type);
    view.setUint16(2, body.byteLength);
    header.set(TURN_STUN_MAGIC_COOKIE, 4);
    header.set(transactionId, 8);
    return 拼接字节数据(header, body);
}
function parseTurnErrorCode(data) {
    return data?.byteLength >= 4 ? (data[2] & 7) * 100 + data[3] : 0;
}
function randomTurnTransactionId() {
    return crypto.getRandomValues(new Uint8Array(12));
}
async function addTurnMessageIntegrity(message, key) {
    const signedMessage = new Uint8Array(message);
    const view = new DataView(signedMessage.buffer);
    view.setUint16(2, view.getUint16(2) + 24);
    const hmacKey = await crypto.subtle.importKey('raw', key, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
    const signature = await crypto.subtle.sign('HMAC', hmacKey, signedMessage);
    return 拼接字节数据(signedMessage, createTurnStunAttribute(TURN_STUN_ATTR.MESSAGE_INTEGRITY, new Uint8Array(signature)));
}
async function readTurnStunMessage(reader, bufferedData = null, timeoutMessage = 'TURN response timed out') {
    let buffer = 有效数据长度(bufferedData) ? 数据转Uint8Array(bufferedData) : new Uint8Array(0);
    const pull = async () => {
        const { done, value } = await withTimeout(reader.read(), CONNECT_TIMEOUT_MS, timeoutMessage);
        if (done)
            throw new Error('TURN server closed connection');
        if (value?.byteLength)
            buffer = 拼接字节数据(buffer, value);
    };
    while (buffer.byteLength < 20)
        await pull();
    const messageLength = 20 + ((buffer[2] << 8) | buffer[3]);
    if (messageLength > 65555)
        throw new Error('TURN response is too large');
    while (buffer.byteLength < messageLength)
        await pull();
    const messageBuffer = buffer.subarray(0, messageLength);
    if (TURN_STUN_MAGIC_COOKIE.some((value, index) => messageBuffer[4 + index] !== value))
        throw new Error('Invalid TURN/STUN response');
    const view = new DataView(messageBuffer.buffer, messageBuffer.byteOffset, messageBuffer.byteLength);
    const attributes = {};
    for (let offset = 20; offset + 4 <= messageLength;) {
        const type = view.getUint16(offset);
        const length = view.getUint16(offset + 2);
        if (offset + 4 + length > messageBuffer.byteLength)
            break;
        attributes[type] = messageBuffer.slice(offset + 4, offset + 4 + length);
        offset += 4 + length + turnStunPadding(length);
    }
    return {
        message: { type: view.getUint16(0), attributes },
        extraData: buffer.byteLength > messageLength ? buffer.subarray(messageLength) : null
    };
}
async function writeTurnBytes(writer, bytes, timeoutMessage) {
    await withTimeout(writer.write(bytes), CONNECT_TIMEOUT_MS, timeoutMessage);
}
async function turnConnect(proxy, targetHost, targetPort) {
    proxy = { ...proxy, username: proxy.username ?? null, password: proxy.password ?? null };
    const resolvedTargetHost = stripIPv6Brackets(targetHost);
    let targetIp = isIPv4(resolvedTargetHost) ? resolvedTargetHost : null;
    if (!targetIp) {
        const records = await DoH查询(resolvedTargetHost, 'A');
        const recordData = records.find(item => item.type === 1 && isIPv4(item.data))?.data;
        targetIp = typeof recordData === 'string' ? recordData : null;
    }
    if (!targetIp)
        throw new Error(`Could not resolve ${targetHost} to an IPv4 address for TURN CONNECT`);
    const turnHost = stripIPv6Brackets(proxy.hostname);
    let controlSocket = null, dataSocket = null, controlWriter = null, controlReader = null, dataWriter = null, dataReader = null, dataReaderReleased = false;
    const close = () => {
        try {
            controlSocket?.close?.();
        }
        catch (e) { }
        try {
            dataSocket?.close?.();
        }
        catch (e) { }
    };
    const releaseDataReader = () => {
        if (dataReaderReleased)
            return;
        dataReaderReleased = true;
        try {
            dataReader?.releaseLock?.();
        }
        catch (e) { }
    };
    try {
        controlSocket = connect({ hostname: turnHost, port: proxy.port });
        await withTimeout(controlSocket.opened, CONNECT_TIMEOUT_MS, 'TURN server connection timed out');
        controlWriter = controlSocket.writable.getWriter();
        controlReader = controlSocket.readable.getReader();
        const xorPeerAddress = new Uint8Array(8);
        xorPeerAddress[1] = 1;
        new DataView(xorPeerAddress.buffer).setUint16(2, targetPort ^ 0x2112);
        targetIp.split('.').forEach((value, index) => {
            xorPeerAddress[4 + index] = Number(value) ^ TURN_STUN_MAGIC_COOKIE[index];
        });
        const peerAddress = createTurnStunAttribute(TURN_STUN_ATTR.XOR_PEER_ADDRESS, xorPeerAddress);
        const requestedTransport = new Uint8Array([6, 0, 0, 0]);
        await writeTurnBytes(controlWriter, createTurnStunMessage(TURN_STUN_TYPE.ALLOCATE_REQUEST, randomTurnTransactionId(), [createTurnStunAttribute(TURN_STUN_ATTR.REQUESTED_TRANSPORT, requestedTransport)]), 'TURN Allocate request timed out');
        let turnResponse = await readTurnStunMessage(controlReader, null, 'TURN Allocate response timed out');
        let message = turnResponse.message;
        let bufferedData = turnResponse.extraData;
        let integrityKey = null;
        let authAttributes = [];
        const sign = messageToSign => integrityKey ? addTurnMessageIntegrity(messageToSign, integrityKey) : Promise.resolve(messageToSign);
        if (message.type === TURN_STUN_TYPE.ALLOCATE_ERROR
            && proxy.username !== null
            && proxy.password !== null
            && parseTurnErrorCode(message.attributes[TURN_STUN_ATTR.ERROR_CODE]) === 401) {
            const realmBytes = message.attributes[TURN_STUN_ATTR.REALM];
            const nonce = message.attributes[TURN_STUN_ATTR.NONCE];
            if (!realmBytes?.byteLength || !nonce?.byteLength)
                throw new Error('TURN authentication challenge is missing realm or nonce');
            const realm = textDecoder.decode(realmBytes);
            integrityKey = new Uint8Array(await crypto.subtle.digest('MD5', textEncoder.encode(`${proxy.username}:${realm}:${proxy.password}`)));
            authAttributes = [
                createTurnStunAttribute(TURN_STUN_ATTR.USERNAME, textEncoder.encode(proxy.username)),
                createTurnStunAttribute(TURN_STUN_ATTR.REALM, textEncoder.encode(realm)),
                createTurnStunAttribute(TURN_STUN_ATTR.NONCE, nonce)
            ];
            const allocateRequest = await addTurnMessageIntegrity(createTurnStunMessage(TURN_STUN_TYPE.ALLOCATE_REQUEST, randomTurnTransactionId(), [
                createTurnStunAttribute(TURN_STUN_ATTR.REQUESTED_TRANSPORT, requestedTransport),
                ...authAttributes
            ]), integrityKey);
            const pipelinedMessages = await Promise.all([
                sign(createTurnStunMessage(TURN_STUN_TYPE.CREATE_PERMISSION_REQUEST, randomTurnTransactionId(), [peerAddress, ...authAttributes])),
                sign(createTurnStunMessage(TURN_STUN_TYPE.CONNECT_REQUEST, randomTurnTransactionId(), [peerAddress, ...authAttributes]))
            ]);
            await writeTurnBytes(controlWriter, 拼接字节数据(allocateRequest, ...pipelinedMessages), 'TURN authenticated Allocate request timed out');
            turnResponse = await readTurnStunMessage(controlReader, bufferedData, 'TURN authenticated Allocate response timed out');
            message = turnResponse.message;
            bufferedData = turnResponse.extraData;
        }
        else if (message.type === TURN_STUN_TYPE.ALLOCATE_SUCCESS) {
            const pipelinedMessages = await Promise.all([
                sign(createTurnStunMessage(TURN_STUN_TYPE.CREATE_PERMISSION_REQUEST, randomTurnTransactionId(), [peerAddress, ...authAttributes])),
                sign(createTurnStunMessage(TURN_STUN_TYPE.CONNECT_REQUEST, randomTurnTransactionId(), [peerAddress, ...authAttributes]))
            ]);
            if (pipelinedMessages.length)
                await writeTurnBytes(controlWriter, 拼接字节数据(...pipelinedMessages), 'TURN pipelined request timed out');
        }
        if (message.type !== TURN_STUN_TYPE.ALLOCATE_SUCCESS) {
            const errorCode = parseTurnErrorCode(message.attributes[TURN_STUN_ATTR.ERROR_CODE]);
            throw new Error(errorCode ? `TURN Allocate failed with ${errorCode}` : 'TURN Allocate failed');
        }
        dataSocket = connect({ hostname: turnHost, port: proxy.port });
        turnResponse = await readTurnStunMessage(controlReader, bufferedData, 'TURN CreatePermission response timed out');
        message = turnResponse.message;
        bufferedData = turnResponse.extraData;
        if (message.type !== TURN_STUN_TYPE.CREATE_PERMISSION_SUCCESS)
            throw new Error('TURN CreatePermission failed');
        turnResponse = await readTurnStunMessage(controlReader, bufferedData, 'TURN CONNECT response timed out');
        message = turnResponse.message;
        bufferedData = turnResponse.extraData;
        if (message.type !== TURN_STUN_TYPE.CONNECT_SUCCESS || !message.attributes[TURN_STUN_ATTR.CONNECTION_ID])
            throw new Error('TURN CONNECT failed');
        await withTimeout(dataSocket.opened, CONNECT_TIMEOUT_MS, 'TURN data connection timed out');
        dataWriter = dataSocket.writable.getWriter();
        dataReader = dataSocket.readable.getReader();
        await writeTurnBytes(dataWriter, await sign(createTurnStunMessage(TURN_STUN_TYPE.CONNECTION_BIND_REQUEST, randomTurnTransactionId(), [
            createTurnStunAttribute(TURN_STUN_ATTR.CONNECTION_ID, message.attributes[TURN_STUN_ATTR.CONNECTION_ID]),
            ...authAttributes
        ])), 'TURN ConnectionBind request timed out');
        turnResponse = await readTurnStunMessage(dataReader, null, 'TURN ConnectionBind response timed out');
        message = turnResponse.message;
        const extraPayload = turnResponse.extraData;
        if (message.type !== TURN_STUN_TYPE.CONNECTION_BIND_SUCCESS)
            throw new Error('TURN ConnectionBind failed');
        controlWriter.releaseLock();
        controlWriter = null;
        controlReader.releaseLock();
        controlReader = null;
        dataWriter.releaseLock();
        dataWriter = null;
        const readable = new ReadableStream({
            start(controller) {
                if (extraPayload?.byteLength)
                    controller.enqueue(extraPayload);
            },
            pull(controller) {
                return dataReader.read().then(({ done, value }) => {
                    if (done) {
                        releaseDataReader();
                        controller.close();
                    }
                    else if (value?.byteLength)
                        controller.enqueue(new Uint8Array(value));
                });
            },
            cancel() {
                try {
                    dataReader?.cancel?.();
                }
                catch (e) { }
                releaseDataReader();
                close();
            }
        });
        return { readable, writable: dataSocket.writable, closed: dataSocket.closed, close };
    }
    catch (error) {
        try {
            controlWriter?.releaseLock?.();
        }
        catch (e) { }
        try {
            controlReader?.releaseLock?.();
        }
        catch (e) { }
        try {
            dataWriter?.releaseLock?.();
        }
        catch (e) { }
        releaseDataReader();
        close();
        throw error;
    }
}
const SSTP_TCP_MSS = 1400;
const SSTP_EMPTY_BYTES = new Uint8Array(0);
function readSstpUint16(bytes, offset = 0) {
    return (bytes[offset] << 8) | bytes[offset + 1];
}
function readSstpUint32(bytes, offset = 0) {
    return ((bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3]) >>> 0;
}
function randomSstpUint16() {
    return readSstpUint16(crypto.getRandomValues(new Uint8Array(2)));
}
function internetChecksum(bytes, offset, length) {
    let sum = 0;
    for (let index = offset; index < offset + length - 1; index += 2)
        sum += readSstpUint16(bytes, index);
    if (length & 1)
        sum += bytes[offset + length - 1] << 8;
    while (sum >> 16)
        sum = (sum & 0xffff) + (sum >> 16);
    return (~sum) & 0xffff;
}
async function sstpConnect(proxy, targetHost, targetPort) {
    proxy = { ...proxy, username: proxy.username ?? null, password: proxy.password ?? null };
    let bufferedBytes = SSTP_EMPTY_BYTES, pppIdentifier = 1, socket = null, reader = null, writer = null;
    let closedSettled = false, resolveClosed, rejectClosed;
    const closed = new Promise((resolve, reject) => {
        resolveClosed = resolve;
        rejectClosed = reject;
    });
    const settleClosed = (settle, value) => {
        if (closedSettled)
            return;
        closedSettled = true;
        settle(value);
    };
    const close = () => {
        try {
            reader?.cancel?.().catch?.(() => { });
        }
        catch (e) { }
        try {
            reader?.releaseLock?.();
        }
        catch (e) { }
        try {
            writer?.close?.().catch?.(() => { });
        }
        catch (e) { }
        try {
            writer?.releaseLock?.();
        }
        catch (e) { }
        try {
            socket?.close?.();
        }
        catch (e) { }
        settleClosed(resolveClosed);
    };
    const readSocketChunk = async () => {
        const { value, done } = await reader.read();
        if (done || !value)
            throw new Error('SSTP socket closed');
        return 数据转Uint8Array(value);
    };
    const readBytes = async (length) => {
        while (bufferedBytes.byteLength < length) {
            const chunk = await readSocketChunk();
            bufferedBytes = bufferedBytes.byteLength ? 拼接字节数据(bufferedBytes, chunk) : chunk;
        }
        const result = bufferedBytes.subarray(0, length);
        bufferedBytes = bufferedBytes.subarray(length);
        return result;
    };
    const readHttpLine = async () => {
        for (;;) {
            const lineEnd = bufferedBytes.indexOf(10);
            if (lineEnd >= 0) {
                const line = textDecoder.decode(bufferedBytes.subarray(0, lineEnd));
                bufferedBytes = bufferedBytes.subarray(lineEnd + 1);
                return line.replace(/\r$/, '');
            }
            const chunk = await readSocketChunk();
            bufferedBytes = bufferedBytes.byteLength ? 拼接字节数据(bufferedBytes, chunk) : chunk;
        }
    };
    const readPacket = async (timeoutMs = CONNECT_TIMEOUT_MS) => {
        const header = await withTimeout(readBytes(4), timeoutMs, 'SSTP read timeout');
        const length = readSstpUint16(header, 2) & 0x0fff;
        if (length < 4)
            throw new Error('Invalid SSTP packet length');
        return {
            isControl: (header[1] & 1) !== 0,
            body: length > 4 ? await withTimeout(readBytes(length - 4), timeoutMs, 'SSTP packet body read timeout') : SSTP_EMPTY_BYTES
        };
    };
    const buildSstpDataPacket = pppFrame => {
        const packetLength = 6 + pppFrame.byteLength;
        const packet = new Uint8Array(packetLength);
        packet.set([0x10, 0x00, ((packetLength >> 8) & 0x0f) | 0x80, packetLength & 0xff, 0xff, 0x03]);
        packet.set(pppFrame, 6);
        return packet;
    };
    const buildPppConfigurePacket = (protocol, code, id, options = []) => {
        const optionsLength = options.reduce((size, option) => size + 2 + option.data.byteLength, 0);
        const frame = new Uint8Array(6 + optionsLength);
        const view = new DataView(frame.buffer);
        view.setUint16(0, protocol);
        frame[2] = code;
        frame[3] = id;
        view.setUint16(4, 4 + optionsLength);
        options.reduce((offset, option) => {
            frame[offset] = option.type;
            frame[offset + 1] = 2 + option.data.byteLength;
            frame.set(option.data, offset + 2);
            return offset + 2 + option.data.byteLength;
        }, 6);
        return frame;
    };
    const parsePPPFrame = data => {
        const offset = data.byteLength >= 2 && data[0] === 0xff && data[1] === 0x03 ? 2 : 0;
        if (data.byteLength - offset < 4)
            return null;
        const protocol = readSstpUint16(data, offset);
        if (protocol === 0x0021)
            return { protocol, ipPacket: data.subarray(offset + 2) };
        if (data.byteLength - offset < 6)
            return null;
        return { protocol, code: data[offset + 2], id: data[offset + 3], payload: data.subarray(offset + 6), rawPacket: data.subarray(offset) };
    };
    const parsePppOptions = data => {
        const options = [];
        for (let offset = 0; offset + 2 <= data.byteLength;) {
            const type = data[offset];
            const length = data[offset + 1];
            if (length < 2 || offset + length > data.byteLength)
                break;
            options.push({ type, data: data.subarray(offset + 2, offset + length) });
            offset += length;
        }
        return options;
    };
    try {
        const serverHost = stripIPv6Brackets(proxy.hostname);
        const serverPort = proxy.port;
        socket = connect({ hostname: serverHost, port: serverPort }, { secureTransport: 'on', allowHalfOpen: false });
        await withTimeout(socket.opened, CONNECT_TIMEOUT_MS, 'SSTP server connection timed out');
        reader = socket.readable.getReader();
        writer = socket.writable.getWriter();
        const displayHost = serverHost.includes(':') ? `[${serverHost}]` : serverHost;
        const httpRequest = textEncoder.encode(`SSTP_DUPLEX_POST /sra_{BA195980-CD49-458b-9E23-C84EE0ADCD75}/ HTTP/1.1\r\n`
            + `Host: ${Number(serverPort) === 443 ? displayHost : `${displayHost}:${serverPort}`}\r\n`
            + 'Content-Length: 18446744073709551615\r\n'
            + `SSTPCORRELATIONID: {${crypto.randomUUID()}}\r\n\r\n`);
        const encapsulatedProtocol = new Uint8Array(2);
        new DataView(encapsulatedProtocol.buffer).setUint16(0, 1);
        const maximumReceiveUnit = new Uint8Array(2);
        new DataView(maximumReceiveUnit.buffer).setUint16(0, 1500);
        const sstpConnectRequest = new Uint8Array(12 + encapsulatedProtocol.byteLength);
        const sstpConnectView = new DataView(sstpConnectRequest.buffer);
        sstpConnectRequest[0] = 0x10;
        sstpConnectRequest[1] = 0x01;
        sstpConnectView.setUint16(2, sstpConnectRequest.byteLength | 0x8000);
        sstpConnectView.setUint16(4, 0x0001);
        sstpConnectView.setUint16(6, 1);
        sstpConnectRequest[9] = 1;
        sstpConnectView.setUint16(10, 4 + encapsulatedProtocol.byteLength);
        sstpConnectRequest.set(encapsulatedProtocol, 12);
        await withTimeout(writer.write(拼接字节数据(httpRequest, sstpConnectRequest, buildSstpDataPacket(buildPppConfigurePacket(0xc021, 1, pppIdentifier++, [
            { type: 1, data: maximumReceiveUnit }
        ])))), CONNECT_TIMEOUT_MS, 'SSTP HTTP handshake request timed out');
        const statusLine = await withTimeout(readHttpLine(), CONNECT_TIMEOUT_MS, 'SSTP HTTP handshake timed out');
        for (;;) {
            const line = await withTimeout(readHttpLine(), CONNECT_TIMEOUT_MS, 'SSTP HTTP header read timed out');
            if (line === '')
                break;
        }
        if (!/HTTP\/\d(?:\.\d)?\s+2\d\d/i.test(statusLine))
            throw new Error(`SSTP HTTP handshake failed: ${statusLine || 'invalid status'}`);
        let localLcpAcked = false, peerLcpAcked = false, papRequired = false, papSent = false, papDone = false, ipcpStarted = false, ipcpFinished = false, sourceIp = null;
        const sendPapIfReady = async () => {
            if (!localLcpAcked || !peerLcpAcked || !papRequired || papSent)
                return;
            if (proxy.username === null || proxy.password === null)
                throw new Error('SSTP server requires PAP authentication');
            const username = textEncoder.encode(proxy.username);
            const password = textEncoder.encode(proxy.password);
            if (username.byteLength > 255 || password.byteLength > 255)
                throw new Error('SSTP username/password is too long');
            const papLength = 6 + username.byteLength + password.byteLength;
            const frame = new Uint8Array(2 + papLength);
            const view = new DataView(frame.buffer);
            view.setUint16(0, 0xc023);
            frame[2] = 1;
            frame[3] = pppIdentifier++;
            view.setUint16(4, papLength);
            frame[6] = username.byteLength;
            frame.set(username, 7);
            frame[7 + username.byteLength] = password.byteLength;
            frame.set(password, 8 + username.byteLength);
            await withTimeout(writer.write(buildSstpDataPacket(frame)), CONNECT_TIMEOUT_MS, 'SSTP PAP authentication request timed out');
            papSent = true;
        };
        const startIpcpIfReady = async () => {
            if (!localLcpAcked || !peerLcpAcked || ipcpStarted || (papRequired && !papDone))
                return;
            await withTimeout(writer.write(buildSstpDataPacket(buildPppConfigurePacket(0x8021, 1, pppIdentifier++, [
                { type: 3, data: new Uint8Array(4) }
            ]))), CONNECT_TIMEOUT_MS, 'SSTP IPCP request timed out');
            ipcpStarted = true;
        };
        for (let round = 0; round < 50 && !ipcpFinished; round++) {
            const packet = await readPacket(CONNECT_TIMEOUT_MS);
            if (packet.isControl)
                continue;
            const ppp = parsePPPFrame(packet.body);
            if (!ppp)
                continue;
            if (ppp.protocol === 0xc021) {
                if (ppp.code === 1) {
                    const authOption = parsePppOptions(ppp.payload).find(option => option.type === 3);
                    if (authOption?.data?.byteLength >= 2) {
                        const authProtocol = readSstpUint16(authOption.data);
                        if (authProtocol !== 0xc023)
                            throw new Error(`SSTP unsupported PPP authentication protocol: 0x${authProtocol.toString(16)}`);
                        papRequired = true;
                    }
                    const ack = new Uint8Array(ppp.rawPacket);
                    ack[2] = 2;
                    await withTimeout(writer.write(buildSstpDataPacket(ack)), CONNECT_TIMEOUT_MS, 'SSTP LCP Configure-Ack timed out');
                    peerLcpAcked = true;
                    await sendPapIfReady();
                    await startIpcpIfReady();
                }
                else if (ppp.code === 2) {
                    localLcpAcked = true;
                    await sendPapIfReady();
                    await startIpcpIfReady();
                }
                continue;
            }
            if (ppp.protocol === 0xc023) {
                if (ppp.code === 2) {
                    papDone = true;
                    await startIpcpIfReady();
                }
                else if (ppp.code === 3)
                    throw new Error('SSTP PAP authentication failed');
                continue;
            }
            if (ppp.protocol === 0x8021) {
                if (ppp.code === 1) {
                    const ack = new Uint8Array(ppp.rawPacket);
                    ack[2] = 2;
                    await withTimeout(writer.write(buildSstpDataPacket(ack)), CONNECT_TIMEOUT_MS, 'SSTP IPCP Configure-Ack timed out');
                    await startIpcpIfReady();
                }
                else if (ppp.code === 3) {
                    const addressOption = parsePppOptions(ppp.payload).find(option => option.type === 3);
                    if (addressOption?.data?.byteLength === 4) {
                        sourceIp = [...addressOption.data].join('.');
                        await withTimeout(writer.write(buildSstpDataPacket(buildPppConfigurePacket(0x8021, 1, pppIdentifier++, [
                            { type: 3, data: addressOption.data }
                        ]))), CONNECT_TIMEOUT_MS, 'SSTP IPCP address request timed out');
                        ipcpStarted = true;
                    }
                }
                else if (ppp.code === 2) {
                    const addressOption = parsePppOptions(ppp.payload).find(option => option.type === 3);
                    if (addressOption?.data?.byteLength === 4)
                        sourceIp = [...addressOption.data].join('.');
                    ipcpFinished = true;
                }
            }
        }
        if (!sourceIp)
            throw new Error('SSTP did not assign an IPv4 address');
        const target = stripIPv6Brackets(targetHost);
        let targetIp = isIPv4(target) ? target : null;
        if (!targetIp) {
            const records = await DoH查询(target, 'A');
            const recordData = records.find(item => item.type === 1 && isIPv4(item.data))?.data;
            targetIp = typeof recordData === 'string' ? recordData : null;
        }
        if (!targetIp)
            throw new Error(`Could not resolve ${targetHost} to an IPv4 address for SSTP`);
        const sourcePort = 10000 + (randomSstpUint16() % 50000);
        const sourceAddress = new Uint8Array(String(sourceIp || '').split('.').map(Number));
        const destinationAddress = new Uint8Array(String(targetIp || '').split('.').map(Number));
        let sequenceNumber = readSstpUint32(crypto.getRandomValues(new Uint8Array(4)));
        let acknowledgementNumber = 0;
        const ipHeaderTemplate = new Uint8Array(20);
        ipHeaderTemplate.set([0x45, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 64, 6]);
        ipHeaderTemplate.set(sourceAddress, 12);
        ipHeaderTemplate.set(destinationAddress, 16);
        const tcpPseudoHeader = new Uint8Array(1432);
        tcpPseudoHeader.set(sourceAddress);
        tcpPseudoHeader.set(destinationAddress, 4);
        tcpPseudoHeader[9] = 6;
        const buildTcpFrame = (flags, payload = SSTP_EMPTY_BYTES) => {
            const bytes = 数据转Uint8Array(payload);
            const payloadLength = bytes.byteLength;
            const tcpLength = 20 + payloadLength;
            const ipLength = 20 + tcpLength;
            const sstpLength = 8 + ipLength;
            const frame = new Uint8Array(sstpLength);
            const view = new DataView(frame.buffer);
            frame.set([0x10, 0x00, ((sstpLength >> 8) & 0x0f) | 0x80, sstpLength & 0xff, 0xff, 0x03, 0x00, 0x21]);
            frame.set(ipHeaderTemplate, 8);
            view.setUint16(10, ipLength);
            view.setUint16(12, randomSstpUint16());
            view.setUint16(18, internetChecksum(frame, 8, 20));
            view.setUint16(28, sourcePort);
            view.setUint16(30, targetPort);
            view.setUint32(32, sequenceNumber);
            view.setUint32(36, acknowledgementNumber);
            frame[40] = 0x50;
            frame[41] = flags;
            view.setUint16(42, 65535);
            if (payloadLength)
                frame.set(bytes, 48);
            tcpPseudoHeader[10] = tcpLength >> 8;
            tcpPseudoHeader[11] = tcpLength & 0xff;
            tcpPseudoHeader.set(frame.subarray(28, 28 + tcpLength), 12);
            view.setUint16(44, internetChecksum(tcpPseudoHeader, 0, 12 + tcpLength));
            return frame;
        };
        const matchIncomingIpPacket = ipPacket => {
            if (ipPacket.byteLength < 40 || ipPacket[9] !== 6)
                return null;
            const ipHeaderLength = (ipPacket[0] & 0x0f) * 4;
            if (ipPacket.byteLength < ipHeaderLength + 20)
                return null;
            if (readSstpUint16(ipPacket, ipHeaderLength) !== targetPort)
                return null;
            if (readSstpUint16(ipPacket, ipHeaderLength + 2) !== sourcePort)
                return null;
            return {
                flags: ipPacket[ipHeaderLength + 13],
                sequence: readSstpUint32(ipPacket, ipHeaderLength + 4),
                payloadOffset: ipHeaderLength + ((ipPacket[ipHeaderLength + 12] >> 4) & 0x0f) * 4
            };
        };
        await withTimeout(writer.write(buildTcpFrame(0x02)), CONNECT_TIMEOUT_MS, 'SSTP TCP SYN write timed out');
        sequenceNumber = (sequenceNumber + 1) >>> 0;
        let tcpReady = false;
        for (let attempt = 0; attempt < 30; attempt++) {
            const packet = await readPacket(CONNECT_TIMEOUT_MS);
            if (packet.isControl)
                continue;
            const ppp = parsePPPFrame(packet.body);
            if (!ppp || ppp.protocol !== 0x0021)
                continue;
            const tcp = matchIncomingIpPacket(ppp.ipPacket);
            if (!tcp || (tcp.flags & 0x12) !== 0x12)
                continue;
            acknowledgementNumber = (tcp.sequence + 1) >>> 0;
            await withTimeout(writer.write(buildTcpFrame(0x10)), CONNECT_TIMEOUT_MS, 'SSTP TCP ACK write timed out');
            tcpReady = true;
            break;
        }
        if (!tcpReady)
            throw new Error('TCP handshake through SSTP timed out');
        let streamController = null;
        const readable = new ReadableStream({
            start(controller) {
                streamController = controller;
            },
            cancel() {
                close();
            }
        });
        (async () => {
            try {
                let pendingChunks = [], pendingLength = 0;
                const flush = () => {
                    if (!pendingLength)
                        return;
                    if (!streamController)
                        throw new Error('SSTP readable stream is not ready');
                    streamController.enqueue(pendingChunks.length === 1 ? pendingChunks[0] : 拼接字节数据(...pendingChunks));
                    pendingChunks = [];
                    pendingLength = 0;
                    writer.write(buildTcpFrame(0x10)).catch(() => { });
                };
                for (;;) {
                    const packet = await readPacket(60000);
                    if (packet.isControl)
                        continue;
                    const ppp = parsePPPFrame(packet.body);
                    if (!ppp || ppp.protocol !== 0x0021)
                        continue;
                    const incoming = matchIncomingIpPacket(ppp.ipPacket);
                    if (!incoming)
                        continue;
                    if (incoming.payloadOffset < ppp.ipPacket.byteLength) {
                        const payload = ppp.ipPacket.subarray(incoming.payloadOffset);
                        if (payload.byteLength) {
                            acknowledgementNumber = (incoming.sequence + payload.byteLength) >>> 0;
                            pendingChunks.push(new Uint8Array(payload));
                            pendingLength += payload.byteLength;
                        }
                    }
                    if (incoming.flags & 0x01) {
                        flush();
                        acknowledgementNumber = (acknowledgementNumber + 1) >>> 0;
                        writer.write(buildTcpFrame(0x11)).catch(() => { });
                        const controller = streamController;
                        if (controller) {
                            try {
                                controller.close();
                            }
                            catch (e) { }
                        }
                        close();
                        return;
                    }
                    if (bufferedBytes.byteLength < 4 || pendingLength >= 32768)
                        flush();
                }
            }
            catch (error) {
                const controller = streamController;
                if (controller) {
                    try {
                        controller.error(error);
                    }
                    catch (e) { }
                }
                settleClosed(rejectClosed, error);
                try {
                    socket?.close?.();
                }
                catch (e) { }
            }
        })();
        const writable = new WritableStream({
            async write(chunk) {
                const bytes = 数据转Uint8Array(chunk);
                if (!bytes.byteLength)
                    return;
                if (bytes.byteLength <= SSTP_TCP_MSS) {
                    await writer.write(buildTcpFrame(0x18, bytes));
                    sequenceNumber = (sequenceNumber + bytes.byteLength) >>> 0;
                    return;
                }
                const frames = [];
                for (let offset = 0; offset < bytes.byteLength; offset += SSTP_TCP_MSS) {
                    const segment = bytes.subarray(offset, Math.min(offset + SSTP_TCP_MSS, bytes.byteLength));
                    frames.push(buildTcpFrame(0x18, segment));
                    sequenceNumber = (sequenceNumber + segment.byteLength) >>> 0;
                }
                await writer.write(拼接字节数据(...frames));
            },
            close() {
                return writer.write(buildTcpFrame(0x11)).catch(() => { });
            },
            abort(error) {
                close();
                if (error)
                    settleClosed(rejectClosed, error);
            }
        });
        return { readable, writable, closed, close };
    }
    catch (error) {
        close();
        throw error;
    }
}
function base64SecretEncode(plaintext, secret) {
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const key = encoder.encode(secret);
    const mixed = new Uint8Array(data.length);
    for (let i = 0; i < data.length; i++) {
        mixed[i] = data[i] ^ key[i % key.length];
    }
    let binary = '';
    for (let i = 0; i < mixed.length; i++) {
        binary += String.fromCharCode(mixed[i]);
    }
    return btoa(binary);
}
function base64SecretDecode(encoded, secret) {
    const binary = atob(encoded);
    const mixed = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        mixed[i] = binary.charCodeAt(i);
    }
    const encoder = new TextEncoder();
    const key = encoder.encode(secret);
    const data = new Uint8Array(mixed.length);
    for (let i = 0; i < mixed.length; i++) {
        data[i] = mixed[i] ^ key[i % key.length];
    }
    const decoder = new TextDecoder();
    return decoder.decode(data);
}
function 获取传输协议配置(配置 = {}) {
    const 是gRPC = 配置.传输协议 === 'grpc';
    return {
        type: 是gRPC ? (配置.gRPC模式 === 'multi' ? 'grpc&mode=multi' : 'grpc&mode=gun') : (配置.传输协议 === 'xhttp' ? 'xhttp&mode=stream-one' : 'ws'),
        路径字段名: 是gRPC ? 'serviceName' : 'path',
        域名字段名: 是gRPC ? 'authority' : 'host'
    };
}
function 获取传输路径参数值(配置 = {}, 节点路径 = '/', 作为优选订阅生成器 = false) {
    const 路径值 = 作为优选订阅生成器 ? '/' : (配置.随机路径 ? 随机路径(节点路径) : 节点路径);
    if (配置.传输协议 !== 'grpc')
        return 路径值;
    return 路径值.split('?')[0] || '/';
}
function log(...args) {
    if (调试日志打印)
        console.log(...args);
}
function Clash订阅配置文件热补丁(Clash_原始订阅内容, config_JSON = {}) {
    const uuid = config_JSON?.UUID || null;
    const ECH启用 = Boolean(config_JSON?.ECH);
    const HOSTS = Array.isArray(config_JSON?.HOSTS) ? [...config_JSON.HOSTS] : [];
    const ECH_SNI = config_JSON?.ECHConfig?.SNI || null;
    const ECH_DNS = config_JSON?.ECHConfig?.DNS;
    const 需要处理ECH = Boolean(uuid && ECH启用);
    const gRPCUserAgent = (typeof config_JSON?.gRPCUserAgent === 'string' && config_JSON.gRPCUserAgent.trim()) ? config_JSON.gRPCUserAgent.trim() : null;
    const 需要处理gRPC = config_JSON?.传输协议 === "grpc" && Boolean(gRPCUserAgent);
    const gRPCUserAgentYAML = gRPCUserAgent ? JSON.stringify(gRPCUserAgent) : null;
    let clash_yaml = Clash_原始订阅内容.replace(/mode:\s*Rule\b/g, 'mode: rule');
    const baseDnsBlock = `dns:
  enable: true
  default-nameserver:
    - 223.5.5.5
    - 119.29.29.29
    - 114.114.114.114
  use-hosts: true
  nameserver:
    - https://sm2.doh.pub/dns-query
    - https://dns.alidns.com/dns-query
  fallback:
    - 8.8.4.4
    - 208.67.220.220
  fallback-filter:
    geoip: true
    geoip-code: CN
    ipcidr:
      - 240.0.0.0/4
      - 127.0.0.1/32
      - 0.0.0.0/32
    domain:
      - '+.google.com'
      - '+.facebook.com'
      - '+.youtube.com'
`;
    const 添加InlineGrpcUserAgent = (text) => text.replace(/grpc-opts:\s*\{([\s\S]*?)\}/i, (all, inner) => {
        if (/grpc-user-agent\s*:/i.test(inner))
            return all;
        let content = inner.trim();
        if (content.endsWith(','))
            content = content.slice(0, -1).trim();
        const patchedContent = content ? `${content}, grpc-user-agent: ${gRPCUserAgentYAML}` : `grpc-user-agent: ${gRPCUserAgentYAML}`;
        return `grpc-opts: {${patchedContent}}`;
    });
    const 匹配到gRPC网络 = (text) => /(?:^|[,{])\s*network:\s*(?:"grpc"|'grpc'|grpc)(?=\s*(?:[,}\n#]|$))/mi.test(text);
    const 获取代理类型 = (nodeText) => nodeText.match(/type:\s*(\w+)/)?.[1] || 'vl' + 'ess';
    const 获取凭据值 = (nodeText, isFlowStyle) => {
        const credentialField = 获取代理类型(nodeText) === 'trojan' ? 'password' : 'uuid';
        const pattern = new RegExp(`${credentialField}:\\s*${isFlowStyle ? '([^,}\\n]+)' : '([^\\n]+)'}`);
        return nodeText.match(pattern)?.[1]?.trim() || null;
    };
    const 插入NameserverPolicy = (yaml, hostsEntries) => {
        if (/^\s{2}nameserver-policy:\s*(?:\n|$)/m.test(yaml)) {
            return yaml.replace(/^(\s{2}nameserver-policy:\s*\n)/m, `$1${hostsEntries}\n`);
        }
        const lines = yaml.split('\n');
        let dnsBlockEndIndex = -1;
        let inDnsBlock = false;
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (/^dns:\s*$/.test(line)) {
                inDnsBlock = true;
                continue;
            }
            if (inDnsBlock && /^[a-zA-Z]/.test(line)) {
                dnsBlockEndIndex = i;
                break;
            }
        }
        const nameserverPolicyBlock = `  nameserver-policy:\n${hostsEntries}`;
        if (dnsBlockEndIndex !== -1)
            lines.splice(dnsBlockEndIndex, 0, nameserverPolicyBlock);
        else
            lines.push(nameserverPolicyBlock);
        return lines.join('\n');
    };
    const 添加Flow格式gRPCUserAgent = (nodeText) => {
        if (!匹配到gRPC网络(nodeText) || /grpc-user-agent\s*:/i.test(nodeText))
            return nodeText;
        if (/grpc-opts:\s*\{/i.test(nodeText))
            return 添加InlineGrpcUserAgent(nodeText);
        return nodeText.replace(/\}(\s*)$/, `, grpc-opts: {grpc-user-agent: ${gRPCUserAgentYAML}}}$1`);
    };
    const 添加Block格式gRPCUserAgent = (nodeLines, topLevelIndent) => {
        const 顶级缩进 = ' '.repeat(topLevelIndent);
        let grpcOptsIndex = -1;
        for (let idx = 0; idx < nodeLines.length; idx++) {
            const line = nodeLines[idx];
            if (!line.trim())
                continue;
            const indent = line.search(/\S/);
            if (indent !== topLevelIndent)
                continue;
            if (/^\s*grpc-opts:\s*(?:#.*)?$/.test(line) || /^\s*grpc-opts:\s*\{.*\}\s*(?:#.*)?$/.test(line)) {
                grpcOptsIndex = idx;
                break;
            }
        }
        if (grpcOptsIndex === -1) {
            let insertIndex = -1;
            for (let j = nodeLines.length - 1; j >= 0; j--) {
                if (nodeLines[j].trim()) {
                    insertIndex = j;
                    break;
                }
            }
            if (insertIndex >= 0)
                nodeLines.splice(insertIndex + 1, 0, `${顶级缩进}grpc-opts:`, `${顶级缩进}  grpc-user-agent: ${gRPCUserAgentYAML}`);
            return nodeLines;
        }
        const grpcLine = nodeLines[grpcOptsIndex];
        if (/^\s*grpc-opts:\s*\{.*\}\s*(?:#.*)?$/.test(grpcLine)) {
            if (!/grpc-user-agent\s*:/i.test(grpcLine))
                nodeLines[grpcOptsIndex] = 添加InlineGrpcUserAgent(grpcLine);
            return nodeLines;
        }
        let blockEndIndex = nodeLines.length;
        let 子级缩进 = topLevelIndent + 2;
        let 已有gRPCUserAgent = false;
        for (let idx = grpcOptsIndex + 1; idx < nodeLines.length; idx++) {
            const line = nodeLines[idx];
            const trimmed = line.trim();
            if (!trimmed)
                continue;
            const indent = line.search(/\S/);
            if (indent <= topLevelIndent) {
                blockEndIndex = idx;
                break;
            }
            if (indent > topLevelIndent && 子级缩进 === topLevelIndent + 2)
                子级缩进 = indent;
            if (/^grpc-user-agent\s*:/.test(trimmed)) {
                已有gRPCUserAgent = true;
                break;
            }
        }
        if (!已有gRPCUserAgent)
            nodeLines.splice(blockEndIndex, 0, `${' '.repeat(子级缩进)}grpc-user-agent: ${gRPCUserAgentYAML}`);
        return nodeLines;
    };
    const 添加Block格式ECHOpts = (nodeLines, topLevelIndent) => {
        let insertIndex = -1;
        for (let j = nodeLines.length - 1; j >= 0; j--) {
            if (nodeLines[j].trim()) {
                insertIndex = j;
                break;
            }
        }
        if (insertIndex < 0)
            return nodeLines;
        const indent = ' '.repeat(topLevelIndent);
        const echOptsLines = [`${indent}ech-opts:`, `${indent}  enable: true`];
        if (ECH_SNI)
            echOptsLines.push(`${indent}  query-server-name: ${ECH_SNI}`);
        nodeLines.splice(insertIndex + 1, 0, ...echOptsLines);
        return nodeLines;
    };
    if (!/^dns:\s*(?:\n|$)/m.test(clash_yaml))
        clash_yaml = baseDnsBlock + clash_yaml;
    if (ECH_SNI && !HOSTS.includes(ECH_SNI))
        HOSTS.push(ECH_SNI);
    if (ECH启用 && HOSTS.length > 0) {
        const hostsEntries = HOSTS.map(host => `    "${host}": ${ECH_DNS ? ECH_DNS : ''}`).join('\n');
        clash_yaml = 插入NameserverPolicy(clash_yaml, hostsEntries);
    }
    if (!需要处理ECH && !需要处理gRPC)
        return clash_yaml;
    const lines = clash_yaml.split('\n');
    const processedLines = [];
    let i = 0;
    while (i < lines.length) {
        const line = lines[i];
        const trimmedLine = line.trim();
        if (trimmedLine.startsWith('- {')) {
            let fullNode = line;
            let braceCount = (line.match(/\{/g) || []).length - (line.match(/\}/g) || []).length;
            while (braceCount > 0 && i + 1 < lines.length) {
                i++;
                fullNode += '\n' + lines[i];
                braceCount += (lines[i].match(/\{/g) || []).length - (lines[i].match(/\}/g) || []).length;
            }
            if (需要处理gRPC)
                fullNode = 添加Flow格式gRPCUserAgent(fullNode);
            if (需要处理ECH && 获取凭据值(fullNode, true) === uuid.trim()) {
                fullNode = fullNode.replace(/\}(\s*)$/, `, ech-opts: {enable: true${ECH_SNI ? `, query-server-name: ${ECH_SNI}` : ''}}}$1`);
            }
            processedLines.push(fullNode);
            i++;
        }
        else if (trimmedLine.startsWith('- name:')) {
            let nodeLines = [line];
            let baseIndent = line.search(/\S/);
            let topLevelIndent = baseIndent + 2;
            i++;
            while (i < lines.length) {
                const nextLine = lines[i];
                const nextTrimmed = nextLine.trim();
                if (!nextTrimmed) {
                    nodeLines.push(nextLine);
                    i++;
                    break;
                }
                const nextIndent = nextLine.search(/\S/);
                if (nextIndent <= baseIndent && nextTrimmed.startsWith('- ')) {
                    break;
                }
                if (nextIndent < baseIndent && nextTrimmed) {
                    break;
                }
                nodeLines.push(nextLine);
                i++;
            }
            let nodeText = nodeLines.join('\n');
            if (需要处理gRPC && 匹配到gRPC网络(nodeText)) {
                nodeLines = 添加Block格式gRPCUserAgent(nodeLines, topLevelIndent);
                nodeText = nodeLines.join('\n');
            }
            if (需要处理ECH && 获取凭据值(nodeText, false) === uuid.trim())
                nodeLines = 添加Block格式ECHOpts(nodeLines, topLevelIndent);
            processedLines.push(...nodeLines);
        }
        else {
            processedLines.push(line);
            i++;
        }
    }
    return processedLines.join('\n');
}
async function Singbox订阅配置文件热补丁(SingBox_原始订阅内容, config_JSON = {}) {
    const uuid = config_JSON?.UUID || null;
    const fingerprint = config_JSON?.Fingerprint || "chrome";
    const ECH启用 = Boolean(config_JSON?.ECH);
    const ECH_SNI = config_JSON?.ECHConfig?.SNI || "cloudflare-ech.com";
    const sb_json_text = SingBox_原始订阅内容.replace('1.1.1.1', '8.8.8.8').replace('1.0.0.1', '8.8.4.4');
    try {
        const config = JSON.parse(sb_json_text);
        const 数组化 = value => value === undefined || value === null ? [] : (Array.isArray(value) ? value : [value]);
        const 确保Route = () => config.route = config.route && typeof config.route === 'object' ? config.route : {};
        const 获取DNS规则服务器 = rule => rule && typeof rule === 'object' && !Array.isArray(rule) && typeof rule.server === 'string' ? rule.server : null;
        const 添加规则集 = (type, code) => {
            if (!code || typeof code !== 'string')
                return null;
            const route = 确保Route(), tag = `${type}-${code}`, ruleSet = Array.isArray(route.rule_set) ? route.rule_set : 数组化(route.rule_set);
            if (!ruleSet.some(item => item?.tag === tag)) {
                const legacyOptions = type === 'geoip' ? route.geoip : route.geosite;
                ruleSet.push({ tag, type: 'remote', format: 'binary', url: `https://raw.githubusercontent.com/SagerNet/sing-${type}/rule-set/${tag}.srs`, ...(legacyOptions?.download_detour ? { download_detour: legacyOptions.download_detour } : {}) });
                config.experimental = config.experimental && typeof config.experimental === 'object' ? config.experimental : {};
                config.experimental.cache_file = config.experimental.cache_file && typeof config.experimental.cache_file === 'object' ? config.experimental.cache_file : {};
                config.experimental.cache_file.enabled ??= true;
            }
            route.rule_set = ruleSet;
            return tag;
        };
        const 迁移规则集字段 = rule => {
            if (!rule || typeof rule !== 'object' || Array.isArray(rule))
                return rule;
            if (rule.type === 'logical' && Array.isArray(rule.rules)) {
                rule.rules = rule.rules.map(迁移规则集字段);
                return rule;
            }
            const tags = [];
            for (const geoip of 数组化(rule.geoip)) {
                if (typeof geoip !== 'string')
                    continue;
                if (geoip.toLowerCase() === 'private')
                    rule.ip_is_private = true;
                else
                    tags.push(添加规则集('geoip', geoip));
            }
            for (const sourceGeoip of 数组化(rule.source_geoip)) {
                if (typeof sourceGeoip !== 'string')
                    continue;
                tags.push(添加规则集('geoip', sourceGeoip));
                rule.rule_set_ip_cidr_match_source = true;
            }
            for (const geosite of 数组化(rule.geosite))
                if (typeof geosite === 'string')
                    tags.push(添加规则集('geosite', geosite));
            if (tags.length)
                rule.rule_set = [...new Set([...数组化(rule.rule_set), ...tags].filter(Boolean))];
            delete rule.geoip;
            delete rule.source_geoip;
            delete rule.geosite;
            return rule;
        };
        const 迁移DNS规则 = (rule, rcodeServerMap) => {
            rule = 迁移规则集字段(rule);
            if (!rule || typeof rule !== 'object' || Array.isArray(rule))
                return rule;
            if (rule.type === 'logical' && Array.isArray(rule.rules)) {
                rule.rules = rule.rules.map(childRule => 迁移DNS规则(childRule, rcodeServerMap));
                return rule;
            }
            const serverTag = 获取DNS规则服务器(rule);
            if (serverTag && rcodeServerMap.has(serverTag)) {
                for (const key of ['server', 'strategy', 'disable_cache', 'rewrite_ttl', 'client_subnet', 'timeout'])
                    delete rule[key];
                rule.action = 'predefined';
                rule.rcode = rcodeServerMap.get(serverTag);
            }
            else if (serverTag && !rule.action)
                rule.action = 'route';
            return rule;
        };
        if (Array.isArray(config.inbounds)) {
            for (const inbound of config.inbounds) {
                if (!inbound || typeof inbound !== 'object' || inbound.type !== 'tun')
                    continue;
                for (const migration of [
                    { targetKey: 'address', sourceKeys: ['inet4_address', 'inet6_address'] },
                    { targetKey: 'route_address', sourceKeys: ['inet4_route_address', 'inet6_route_address'] },
                    { targetKey: 'route_exclude_address', sourceKeys: ['inet4_route_exclude_address', 'inet6_route_exclude_address'] }
                ]) {
                    const values = 数组化(inbound[migration.targetKey]);
                    for (const sourceKey of migration.sourceKeys)
                        values.push(...数组化(inbound[sourceKey]));
                    if (values.length)
                        inbound[migration.targetKey] = [...new Set(values)];
                    for (const sourceKey of migration.sourceKeys)
                        delete inbound[sourceKey];
                }
                if (inbound.tag) {
                    const addedRules = [];
                    if (inbound.domain_strategy)
                        addedRules.push({ inbound: inbound.tag, action: 'resolve', strategy: inbound.domain_strategy });
                    if (inbound.sniff) {
                        const sniffRule = { inbound: inbound.tag, action: 'sniff' };
                        if (inbound.sniff_timeout)
                            sniffRule.timeout = inbound.sniff_timeout;
                        addedRules.push(sniffRule);
                    }
                    if (addedRules.length) {
                        const route = 确保Route();
                        route.rules = [...addedRules, ...数组化(route.rules)];
                    }
                }
                delete inbound.sniff;
                delete inbound.sniff_timeout;
                delete inbound.domain_strategy;
            }
        }
        if (config?.route && typeof config.route === 'object' && Array.isArray(config.route.rules)) {
            const 修补路由规则 = rule => {
                rule = 迁移规则集字段(rule);
                if (rule?.type === 'logical' && Array.isArray(rule.rules))
                    rule.rules = rule.rules.map(修补路由规则);
                else if (rule && typeof rule === 'object' && !Array.isArray(rule) && rule.outbound && !rule.action)
                    rule.action = 'route';
                return rule;
            };
            config.route.rules = config.route.rules.map(修补路由规则);
        }
        const dns = config?.dns;
        if (dns && typeof dns === 'object') {
            const legacyFakeIP = dns.fakeip && typeof dns.fakeip === 'object' ? dns.fakeip : null;
            const rcodeServerMap = new Map();
            const DNS地址协议类型 = { 'tcp:': 'tcp', 'udp:': 'udp', 'tls:': 'tls', 'quic:': 'quic', 'https:': 'https', 'h3:': 'h3' };
            const RCode映射 = { success: 'NOERROR', format_error: 'FORMERR', server_failure: 'SERVFAIL', name_error: 'NXDOMAIN', not_implemented: 'NOTIMP', refused: 'REFUSED' };
            let hasFakeIPServer = false;
            if (Array.isArray(dns.servers)) {
                const migratedServers = [];
                for (const originalServer of dns.servers) {
                    if (!originalServer || typeof originalServer !== 'object' || Array.isArray(originalServer)) {
                        migratedServers.push(originalServer);
                        continue;
                    }
                    const server = { ...originalServer };
                    let parsedAddress = null, parsedRCode = '', rawAddress = typeof server.address === 'string' ? server.address.trim() : '';
                    if (rawAddress) {
                        const lowerAddress = rawAddress.toLowerCase();
                        if (lowerAddress === 'fakeip')
                            parsedAddress = { type: 'fakeip' };
                        else if (lowerAddress === 'local')
                            parsedAddress = { type: 'local' };
                        else if (lowerAddress.startsWith('rcode://')) {
                            parsedAddress = { type: 'rcode' };
                            parsedRCode = rawAddress.slice('rcode://'.length).toLowerCase();
                        }
                        else if (lowerAddress.startsWith('dhcp://')) {
                            const dhcpInterface = rawAddress.slice('dhcp://'.length);
                            parsedAddress = dhcpInterface && dhcpInterface.toLowerCase() !== 'auto' ? { type: 'dhcp', interface: dhcpInterface } : { type: 'dhcp' };
                        }
                        else {
                            try {
                                const addressURL = new URL(rawAddress);
                                const type = DNS地址协议类型[addressURL.protocol.toLowerCase()];
                                if (type) {
                                    const parsedServer = addressURL.hostname?.startsWith('[') && addressURL.hostname.endsWith(']') ? addressURL.hostname.slice(1, -1) : addressURL.hostname;
                                    parsedAddress = {
                                        type,
                                        server: parsedServer || addressURL.host || rawAddress,
                                        ...(addressURL.port ? { server_port: Number(addressURL.port) } : {}),
                                        ...((type === 'https' || type === 'h3') && addressURL.pathname && addressURL.pathname !== '/dns-query' ? { path: addressURL.pathname } : {})
                                    };
                                }
                            }
                            catch (_) { }
                            if (!parsedAddress)
                                parsedAddress = { type: 'udp', server: rawAddress };
                        }
                    }
                    if (parsedAddress?.type === 'rcode') {
                        const rcode = RCode映射[parsedRCode] || 'NOERROR';
                        if (typeof server.tag === 'string' && server.tag) {
                            rcodeServerMap.set(server.tag, rcode);
                            rcodeServerMap.set(server.tag.startsWith('dns_') ? server.tag.slice(4) : `dns_${server.tag}`, rcode);
                        }
                        continue;
                    }
                    if (parsedAddress) {
                        delete server.address;
                        Object.assign(server, parsedAddress);
                    }
                    if (server.address_resolver !== undefined && server.domain_resolver === undefined)
                        server.domain_resolver = server.address_resolver;
                    if (server.address_strategy !== undefined && server.domain_strategy === undefined)
                        server.domain_strategy = server.address_strategy;
                    delete server.address_resolver;
                    delete server.address_strategy;
                    if (server.detour === 'DIRECT')
                        delete server.detour;
                    if (server.type === 'fakeip') {
                        hasFakeIPServer = true;
                        if (legacyFakeIP) {
                            for (const key of ['inet4_range', 'inet6_range']) {
                                if (legacyFakeIP[key] !== undefined && server[key] === undefined)
                                    server[key] = legacyFakeIP[key];
                            }
                        }
                    }
                    migratedServers.push(server);
                }
                dns.servers = migratedServers;
            }
            if (legacyFakeIP && !hasFakeIPServer && legacyFakeIP.enabled !== false) {
                const fakeIPServer = { type: 'fakeip', tag: 'fakeip' };
                for (const rule of Array.isArray(dns.rules) ? dns.rules : []) {
                    const serverTag = 获取DNS规则服务器(rule);
                    if (serverTag && serverTag.toLowerCase().includes('fakeip')) {
                        fakeIPServer.tag = serverTag;
                        break;
                    }
                }
                for (const key of ['inet4_range', 'inet6_range']) {
                    if (legacyFakeIP[key] !== undefined)
                        fakeIPServer[key] = legacyFakeIP[key];
                }
                if (Array.isArray(dns.servers))
                    dns.servers.push(fakeIPServer);
                else
                    dns.servers = [fakeIPServer];
            }
            if (Array.isArray(dns.rules)) {
                const migratedRules = [];
                for (const rule of dns.rules) {
                    const serverTag = 获取DNS规则服务器(rule);
                    const outbound = 数组化(rule?.outbound);
                    const DNS路由选项字段 = new Set(['outbound', 'server', 'action', 'strategy', 'disable_cache', 'rewrite_ttl', 'client_subnet', 'timeout']);
                    const isOutboundAnyDNSRule = rule && typeof rule === 'object' && !Array.isArray(rule) && rule.type !== 'logical'
                        && serverTag && outbound.includes('any') && Object.keys(rule).every(key => DNS路由选项字段.has(key));
                    if (isOutboundAnyDNSRule) {
                        const route = 确保Route();
                        if (route.default_domain_resolver === undefined) {
                            const resolver = { server: serverTag };
                            for (const key of ['strategy', 'disable_cache', 'rewrite_ttl', 'client_subnet', 'timeout']) {
                                if (rule[key] !== undefined)
                                    resolver[key] = rule[key];
                            }
                            route.default_domain_resolver = Object.keys(resolver).length === 1 ? resolver.server : resolver;
                        }
                        continue;
                    }
                    migratedRules.push(迁移DNS规则(rule, rcodeServerMap));
                }
                dns.rules = migratedRules;
            }
            delete dns.fakeip;
            delete dns.independent_cache;
        }
        if (config?.route && typeof config.route === 'object') {
            delete config.route.geoip;
            delete config.route.geosite;
        }
        if (config?.ntp?.detour === 'DIRECT')
            delete config.ntp.detour;
        if (Array.isArray(config.outbounds)) {
            const outboundTags = new Set(config.outbounds.map(outbound => outbound?.tag).filter(Boolean));
            const 引用REJECT = value => value === 'REJECT' || (value && typeof value === 'object' && (Array.isArray(value) ? value.some(引用REJECT) : Object.values(value).some(引用REJECT)));
            if (!outboundTags.has('REJECT') && 引用REJECT({ outbounds: config.outbounds, route: config.route }))
                config.outbounds.push({ type: 'block', tag: 'REJECT' });
        }
        if (uuid) {
            config.outbounds?.forEach(outbound => {
                if ((outbound.uuid && outbound.uuid === uuid) || (outbound.password && outbound.password === uuid)) {
                    if (!outbound.tls) {
                        outbound.tls = { enabled: true };
                    }
                    if (fingerprint) {
                        outbound.tls.utls = {
                            enabled: true,
                            fingerprint: fingerprint
                        };
                    }
                    if (ECH启用) {
                        outbound.tls.ech = {
                            enabled: true,
                            query_server_name: ECH_SNI,
                        };
                    }
                }
            });
        }
        return JSON.stringify(config, null, 2);
    }
    catch (e) {
        console.error("Singbox热补丁执行失败:", e);
        return JSON.stringify(JSON.parse(sb_json_text), null, 2);
    }
}
function Surge订阅配置文件热补丁(content, url, config_JSON) {
    const 每行内容 = content.includes('\r\n') ? content.split('\r\n') : content.split('\n');
    const 完整节点路径 = config_JSON.随机路径 ? 随机路径(config_JSON.完整节点路径) : config_JSON.完整节点路径;
    let 输出内容 = "";
    for (let x of 每行内容) {
        if (x.includes('= tro' + 'jan,') && !x.includes('ws=true') && !x.includes('ws-path=')) {
            const host = x.split("sni=")[1].split(",")[0];
            const 备改内容 = `sni=${host}, skip-cert-verify=${config_JSON.跳过证书验证}`;
            const 正确内容 = `sni=${host}, skip-cert-verify=${config_JSON.跳过证书验证}, ws=true, ws-path=${完整节点路径.replace(/,/g, '%2C')}, ws-headers=Host:"${host}"`;
            输出内容 += x.replace(new RegExp(备改内容, 'g'), 正确内容).replace("[", "").replace("]", "") + '\n';
        }
        else {
            输出内容 += x + '\n';
        }
    }
    输出内容 = `#!MANAGED-CONFIG ${url} interval=${config_JSON.优选订阅生成.SUBUpdateTime * 60 * 60} strict=false` + 输出内容.substring(输出内容.indexOf('\n'));
    return 输出内容;
}
async function 请求日志记录(env, request, 访问IP, 请求类型 = "Get_SUB", config_JSON, 是否写入KV日志 = true) {
    try {
        const 当前时间 = new Date();
        const 日志内容 = { TYPE: 请求类型, IP: 访问IP, ASN: `AS${request.cf.asn || '0'} ${request.cf.asOrganization || 'Unknown'}`, CC: `${request.cf.country || 'N/A'} ${request.cf.city || 'N/A'}`, URL: request.url, UA: request.headers.get('User-Agent') || 'Unknown', TIME: 当前时间.getTime() };
        if (config_JSON.TG.启用) {
            try {
                const TG_TXT = await env.KV.get('tg.json');
                const TG_JSON = JSON.parse(TG_TXT);
                if (TG_JSON?.BotToken && TG_JSON?.ChatID) {
                    const 请求时间 = new Date(日志内容.TIME).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
                    const 请求URL = new URL(日志内容.URL);
                    const msg = `<b>#${config_JSON.优选订阅生成.SUBNAME} 日志通知</b>\n\n` +
                        `📌 <b>类型：</b>#${日志内容.TYPE}\n` +
                        `🌐 <b>IP：</b><code>${日志内容.IP}</code>\n` +
                        `📍 <b>位置：</b>${日志内容.CC}\n` +
                        `🏢 <b>ASN：</b>${日志内容.ASN}\n` +
                        `🔗 <b>域名：</b><code>${请求URL.host}</code>\n` +
                        `🔍 <b>路径：</b><code>${请求URL.pathname + 请求URL.search}</code>\n` +
                        `🤖 <b>UA：</b><code>${日志内容.UA}</code>\n` +
                        `📅 <b>时间：</b>${请求时间}\n` +
                        `${config_JSON.CF.Usage.success ? `📊 <b>请求用量：</b>${config_JSON.CF.Usage.total}/${config_JSON.CF.Usage.max} <b>${((config_JSON.CF.Usage.total / config_JSON.CF.Usage.max) * 100).toFixed(2)}%</b>\n` : ''}`;
                    await fetch(`https://api.telegram.org/bot${TG_JSON.BotToken}/sendMessage?chat_id=${TG_JSON.ChatID}&parse_mode=HTML&text=${encodeURIComponent(msg)}`, {
                        method: 'GET',
                        headers: {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'User-Agent': 日志内容.UA || 'Unknown',
                        }
                    });
                }
            }
            catch (error) {
                console.error(`读取tg.json出错: ${error.message}`);
            }
        }
        是否写入KV日志 = ['1', 'true'].includes(env.OFF_LOG) ? false : 是否写入KV日志;
        if (!是否写入KV日志)
            return;
        let 日志数组 = [];
        const 现有日志 = await env.KV.get('log.json'), KV容量限制 = 4;
        if (现有日志) {
            try {
                日志数组 = JSON.parse(现有日志);
                if (!Array.isArray(日志数组)) {
                    日志数组 = [日志内容];
                }
                else if (请求类型 !== "Get_SUB") {
                    const 三十分钟前时间戳 = 当前时间.getTime() - 30 * 60 * 1000;
                    if (日志数组.some(log => log.TYPE !== "Get_SUB" && log.IP === 访问IP && log.URL === request.url && log.UA === (request.headers.get('User-Agent') || 'Unknown') && log.TIME >= 三十分钟前时间戳))
                        return;
                    日志数组.push(日志内容);
                    while (JSON.stringify(日志数组, null, 2).length > KV容量限制 * 1024 * 1024 && 日志数组.length > 0)
                        日志数组.shift();
                }
                else {
                    日志数组.push(日志内容);
                    while (JSON.stringify(日志数组, null, 2).length > KV容量限制 * 1024 * 1024 && 日志数组.length > 0)
                        日志数组.shift();
                }
            }
            catch (e) {
                日志数组 = [日志内容];
            }
        }
        else {
            日志数组 = [日志内容];
        }
        await env.KV.put('log.json', JSON.stringify(日志数组, null, 2));
    }
    catch (error) {
        console.error(`日志记录失败: ${error.message}`);
    }
}
function 掩码敏感信息(文本, 前缀长度 = 3, 后缀长度 = 2) {
    if (!文本 || typeof 文本 !== 'string')
        return 文本;
    if (文本.length <= 前缀长度 + 后缀长度)
        return 文本;
    const 前缀 = 文本.slice(0, 前缀长度);
    const 后缀 = 文本.slice(-后缀长度);
    const 星号数量 = 文本.length - 前缀长度 - 后缀长度;
    return `${前缀}${'*'.repeat(星号数量)}${后缀}`;
}
async function MD5MD5(文本) {
    const 编码器 = new TextEncoder();
    const 第一次哈希 = await crypto.subtle.digest('MD5', 编码器.encode(文本));
    const 第一次哈希数组 = Array.from(new Uint8Array(第一次哈希));
    const 第一次十六进制 = 第一次哈希数组.map(字节 => 字节.toString(16).padStart(2, '0')).join('');
    const 第二次哈希 = await crypto.subtle.digest('MD5', 编码器.encode(第一次十六进制.slice(7, 27)));
    const 第二次哈希数组 = Array.from(new Uint8Array(第二次哈希));
    const 第二次十六进制 = 第二次哈希数组.map(字节 => 字节.toString(16).padStart(2, '0')).join('');
    return 第二次十六进制.toLowerCase();
}
function 随机路径(完整节点路径 = "/") {
    const 常用路径目录 = ["about", "account", "acg", "act", "activity", "ad", "ads", "ajax", "album", "albums", "anime", "api", "app", "apps", "archive", "archives", "article", "articles", "ask", "auth", "avatar", "bbs", "bd", "blog", "blogs", "book", "books", "bt", "buy", "cart", "category", "categories", "cb", "channel", "channels", "chat", "china", "city", "class", "classify", "clip", "clips", "club", "cn", "code", "collect", "collection", "comic", "comics", "community", "company", "config", "contact", "content", "course", "courses", "cp", "data", "detail", "details", "dh", "directory", "discount", "discuss", "dl", "dload", "doc", "docs", "document", "documents", "doujin", "download", "downloads", "drama", "edu", "en", "ep", "episode", "episodes", "event", "events", "f", "faq", "favorite", "favourites", "favs", "feedback", "file", "files", "film", "films", "forum", "forums", "friend", "friends", "game", "games", "gif", "go", "go.html", "go.php", "group", "groups", "help", "home", "hot", "htm", "html", "image", "images", "img", "index", "info", "intro", "item", "items", "ja", "jp", "jump", "jump.html", "jump.php", "jumping", "knowledge", "lang", "lesson", "lessons", "lib", "library", "link", "links", "list", "live", "lives", "m", "mag", "magnet", "mall", "manhua", "map", "member", "members", "message", "messages", "mobile", "movie", "movies", "music", "my", "new", "news", "note", "novel", "novels", "online", "order", "out", "out.html", "out.php", "outbound", "p", "page", "pages", "pay", "payment", "pdf", "photo", "photos", "pic", "pics", "picture", "pictures", "play", "player", "playlist", "post", "posts", "product", "products", "program", "programs", "project", "qa", "question", "rank", "ranking", "read", "readme", "redirect", "redirect.html", "redirect.php", "reg", "register", "res", "resource", "retrieve", "sale", "search", "season", "seasons", "section", "seller", "series", "service", "services", "setting", "settings", "share", "shop", "show", "shows", "site", "soft", "sort", "source", "special", "star", "stars", "static", "stock", "store", "stream", "streaming", "streams", "student", "study", "tag", "tags", "task", "teacher", "team", "tech", "temp", "test", "thread", "tool", "tools", "topic", "topics", "torrent", "trade", "travel", "tv", "txt", "type", "u", "upload", "uploads", "url", "urls", "user", "users", "v", "version", "videos", "view", "vip", "vod", "watch", "web", "wenku", "wiki", "work", "www", "zh", "zh-cn", "zh-tw", "zip"];
    const 随机数 = Math.floor(Math.random() * 3 + 1);
    const 随机路径 = 常用路径目录.sort(() => 0.5 - Math.random()).slice(0, 随机数).join('/');
    if (完整节点路径 === "/")
        return `/${随机路径}`;
    else
        return `/${随机路径 + 完整节点路径.replace('/?', '?')}`;
}
function 替换星号为随机字符(内容) {
    if (typeof 内容 !== 'string' || !内容.includes('*'))
        return 内容;
    const 字符集 = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return 内容.replace(/\*/g, () => {
        let s = '';
        for (let i = 0; i < Math.floor(Math.random() * 14) + 3; i++)
            s += 字符集[Math.floor(Math.random() * 字符集.length)];
        return s;
    });
}
async function DoH查询(域名, 记录类型, DoH解析服务 = "https://cloudflare-dns.com/dns-query") {
    const 开始时间 = performance.now();
    log(`[DoH查询] 开始查询 ${域名} ${记录类型} via ${DoH解析服务}`);
    try {
        const 类型映射 = { 'A': 1, 'NS': 2, 'CNAME': 5, 'MX': 15, 'TXT': 16, 'AAAA': 28, 'SRV': 33, 'HTTPS': 65 };
        const qtype = 类型映射[记录类型.toUpperCase()] || 1;
        const 编码域名 = (name) => {
            const parts = name.endsWith('.') ? name.slice(0, -1).split('.') : name.split('.');
            const bufs = [];
            for (const label of parts) {
                const enc = new TextEncoder().encode(label);
                bufs.push(new Uint8Array([enc.length]), enc);
            }
            bufs.push(new Uint8Array([0]));
            const total = bufs.reduce((s, b) => s + b.length, 0);
            const result = new Uint8Array(total);
            let off = 0;
            for (const b of bufs) {
                result.set(b, off);
                off += b.length;
            }
            return result;
        };
        const qname = 编码域名(域名);
        const query = new Uint8Array(12 + qname.length + 4);
        const qview = new DataView(query.buffer);
        qview.setUint16(0, crypto.getRandomValues(new Uint16Array(1))[0]);
        qview.setUint16(2, 0x0100);
        qview.setUint16(4, 1);
        query.set(qname, 12);
        qview.setUint16(12 + qname.length, qtype);
        qview.setUint16(12 + qname.length + 2, 1);
        log(`[DoH查询] 发送查询报文 ${域名} via ${DoH解析服务} (type=${qtype}, ${query.length}字节)`);
        const response = await fetch(DoH解析服务, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/dns-message',
                'Accept': 'application/dns-message',
            },
            body: query,
        });
        if (!response.ok) {
            console.warn(`[DoH查询] 请求失败 ${域名} ${记录类型} via ${DoH解析服务} 响应代码:${response.status}`);
            return [];
        }
        const buf = new Uint8Array(await response.arrayBuffer());
        const dv = new DataView(buf.buffer);
        const qdcount = dv.getUint16(4);
        const ancount = dv.getUint16(6);
        log(`[DoH查询] 收到响应 ${域名} ${记录类型} via ${DoH解析服务} (${buf.length}字节, ${ancount}条应答)`);
        const 解析域名 = (pos) => {
            const labels = [];
            let p = pos, jumped = false, endPos = -1, safe = 128;
            while (p < buf.length && safe-- > 0) {
                const len = buf[p];
                if (len === 0) {
                    if (!jumped)
                        endPos = p + 1;
                    break;
                }
                if ((len & 0xC0) === 0xC0) {
                    if (!jumped)
                        endPos = p + 2;
                    p = ((len & 0x3F) << 8) | buf[p + 1];
                    jumped = true;
                    continue;
                }
                labels.push(new TextDecoder().decode(buf.slice(p + 1, p + 1 + len)));
                p += len + 1;
            }
            if (endPos === -1)
                endPos = p + 1;
            return [labels.join('.'), endPos];
        };
        let offset = 12;
        for (let i = 0; i < qdcount; i++) {
            const [, end] = 解析域名(offset);
            offset = (end) + 4;
        }
        const answers = [];
        for (let i = 0; i < ancount && offset < buf.length; i++) {
            const [name, nameEnd] = 解析域名(offset);
            offset = (nameEnd);
            const type = dv.getUint16(offset);
            offset += 2;
            offset += 2;
            const ttl = dv.getUint32(offset);
            offset += 4;
            const rdlen = dv.getUint16(offset);
            offset += 2;
            const rdata = buf.slice(offset, offset + rdlen);
            offset += rdlen;
            let data;
            if (type === 1 && rdlen === 4) {
                data = `${rdata[0]}.${rdata[1]}.${rdata[2]}.${rdata[3]}`;
            }
            else if (type === 28 && rdlen === 16) {
                const segs = [];
                for (let j = 0; j < 16; j += 2)
                    segs.push(((rdata[j] << 8) | rdata[j + 1]).toString(16));
                data = segs.join(':');
            }
            else if (type === 16) {
                let tOff = 0;
                const parts = [];
                while (tOff < rdlen) {
                    const tLen = rdata[tOff++];
                    parts.push(new TextDecoder().decode(rdata.slice(tOff, tOff + tLen)));
                    tOff += tLen;
                }
                data = parts.join('');
            }
            else if (type === 5) {
                const [cname] = 解析域名(offset - rdlen);
                data = cname;
            }
            else {
                data = Array.from(rdata).map(b => b.toString(16).padStart(2, '0')).join('');
            }
            answers.push({ name, type, TTL: ttl, data, rdata });
        }
        const 耗时 = (performance.now() - 开始时间).toFixed(2);
        log(`[DoH查询] 查询完成 ${域名} ${记录类型} via ${DoH解析服务} ${耗时}ms 共${answers.length}条结果${answers.length > 0 ? '\n' + answers.map((a, i) => `  ${i + 1}. ${a.name} type=${a.type} TTL=${a.TTL} data=${a.data}`).join('\n') : ''}`);
        return answers;
    }
    catch (error) {
        const 耗时 = (performance.now() - 开始时间).toFixed(2);
        console.error(`[DoH查询] 查询失败 ${域名} ${记录类型} via ${DoH解析服务} ${耗时}ms:`, error);
        return [];
    }
}
async function 读取config_JSON(env, hostname, userID, UA = "Mozilla/5.0", 重置配置 = false) {
    const _p = atob("UFJPWFlJUA==");
    const host = hostname, Ali_DoH = "https://dns.alidns.com/dns-query", ECH_SNI = "cloudflare-ech.com", 占位符 = '{{IP:PORT}}', 初始化开始时间 = performance.now(), 默认配置JSON = {
        TIME: new Date().toISOString(),
        HOST: host,
        HOSTS: [hostname],
        UUID: userID,
        PATH: "/",
        协议类型: "v" + "le" + "ss",
        传输协议: "ws",
        gRPC模式: "gun",
        gRPCUserAgent: UA,
        跳过证书验证: false,
        启用0RTT: false,
        TLS分片: null,
        随机路径: false,
        ECH: false,
        ECHConfig: {
            DNS: Ali_DoH,
            SNI: ECH_SNI,
        },
        SS: {
            加密方式: "aes-128-gcm",
            TLS: true,
        },
        Fingerprint: "chrome",
        优选订阅生成: {
            local: true,
            本地IP库: {
                随机IP: true,
                随机数量: 16,
                指定端口: -1,
            },
            SUB: null,
            SUBNAME: "edge" + "tunnel",
            SUBUpdateTime: 3,
            TOKEN: await MD5MD5(hostname + userID),
        },
        订阅转换配置: {
            SUBAPI: "https://SUBAPI.cmliussss.net",
            SUBCONFIG: "https://raw.githubusercontent.com/cmliu/ACL4SSR/refs/heads/main/Clash/config/ACL4SSR_Online_Mini_MultiMode_CF.ini",
            SUBEMOJI: false,
        },
        反代: {
            [_p]: "auto",
            SOCKS5: {
                启用: 启用SOCKS5反代,
                全局: 启用SOCKS5全局反代,
                账号: 我的SOCKS5账号,
                白名单: SOCKS5白名单,
            },
            路径模板: {
                [_p]: "proxyip=" + 占位符,
                SOCKS5: {
                    全局: "socks5://" + 占位符,
                    标准: "socks5=" + 占位符
                },
                HTTP: {
                    全局: "http://" + 占位符,
                    标准: "http=" + 占位符
                },
                HTTPS: {
                    全局: "https://" + 占位符,
                    标准: "https=" + 占位符
                },
                TURN: {
                    全局: "turn://" + 占位符,
                    标准: "turn=" + 占位符
                },
                SSTP: {
                    全局: "sstp://" + 占位符,
                    标准: "sstp=" + 占位符
                },
            },
        },
        TG: {
            启用: false,
            BotToken: null,
            ChatID: null,
        },
        CF: {
            Email: null,
            GlobalAPIKey: null,
            AccountID: null,
            APIToken: null,
            UsageAPI: null,
            Usage: {
                success: false,
                pages: 0,
                workers: 0,
                total: 0,
                max: 100000,
            },
        }
    };
    try {
        let configJSON = await env.KV.get('config.json');
        if (!configJSON || 重置配置 == true) {
            await env.KV.put('config.json', JSON.stringify(默认配置JSON, null, 2));
            config_JSON = 默认配置JSON;
        }
        else {
            config_JSON = JSON.parse(configJSON);
        }
    }
    catch (error) {
        console.error(`读取config_JSON出错: ${error.message}`);
        config_JSON = 默认配置JSON;
    }
    if (!config_JSON.gRPCUserAgent)
        config_JSON.gRPCUserAgent = UA;
    config_JSON.HOST = host;
    if (!config_JSON.HOSTS)
        config_JSON.HOSTS = [hostname];
    if (env.HOST)
        config_JSON.HOSTS = (await 整理成数组(env.HOST)).map(h => h.toLowerCase().replace(/^https?:\/\//, '').split('/')[0].split(':')[0]);
    config_JSON.UUID = userID;
    if (!config_JSON.随机路径)
        config_JSON.随机路径 = false;
    if (!config_JSON.启用0RTT)
        config_JSON.启用0RTT = false;
    if (env.PATH)
        config_JSON.PATH = env.PATH.startsWith('/') ? env.PATH : '/' + env.PATH;
    else if (!config_JSON.PATH)
        config_JSON.PATH = '/';
    if (!config_JSON.gRPC模式)
        config_JSON.gRPC模式 = 'gun';
    if (!config_JSON.SS)
        config_JSON.SS = { 加密方式: "aes-128-gcm", TLS: false };
    if (!config_JSON.反代.路径模板?.[_p]) {
        config_JSON.反代.路径模板 = {
            [_p]: "proxyip=" + 占位符,
            SOCKS5: {
                全局: "socks5://" + 占位符,
                标准: "socks5=" + 占位符
            },
            HTTP: {
                全局: "http://" + 占位符,
                标准: "http=" + 占位符
            },
            HTTPS: {
                全局: "https://" + 占位符,
                标准: "https=" + 占位符
            },
            TURN: {
                全局: "turn://" + 占位符,
                标准: "turn=" + 占位符
            },
            SSTP: {
                全局: "sstp://" + 占位符,
                标准: "sstp=" + 占位符
            },
        };
    }
    if (!config_JSON.反代.路径模板.HTTPS)
        config_JSON.反代.路径模板.HTTPS = { 全局: "https://" + 占位符, 标准: "https=" + 占位符 };
    if (!config_JSON.反代.路径模板.TURN)
        config_JSON.反代.路径模板.TURN = { 全局: "turn://" + 占位符, 标准: "turn=" + 占位符 };
    if (!config_JSON.反代.路径模板.SSTP)
        config_JSON.反代.路径模板.SSTP = { 全局: "sstp://" + 占位符, 标准: "sstp=" + 占位符 };
    const 代理配置 = config_JSON.反代.路径模板[config_JSON.反代.SOCKS5.启用?.toUpperCase()];
    let 路径反代参数 = '';
    if (代理配置 && config_JSON.反代.SOCKS5.账号)
        路径反代参数 = (config_JSON.反代.SOCKS5.全局 ? 代理配置.全局 : 代理配置.标准).replace(占位符, config_JSON.反代.SOCKS5.账号);
    else if (config_JSON.反代[_p] !== 'auto')
        路径反代参数 = config_JSON.反代.路径模板[_p].replace(占位符, config_JSON.反代[_p]);
    let 反代查询参数 = '';
    if (路径反代参数.includes('?')) {
        const [反代路径部分, 反代查询部分] = 路径反代参数.split('?');
        路径反代参数 = 反代路径部分;
        反代查询参数 = 反代查询部分;
    }
    config_JSON.PATH = config_JSON.PATH.replace(路径反代参数, '').replace('//', '/');
    const normalizedPath = config_JSON.PATH === '/' ? '' : config_JSON.PATH.replace(/\/+(?=\?|$)/, '').replace(/\/+$/, '');
    const [路径部分, ...查询数组] = normalizedPath.split('?');
    const 查询部分 = 查询数组.length ? '?' + 查询数组.join('?') : '';
    const 最终查询部分 = 反代查询参数 ? (查询部分 ? 查询部分 + '&' + 反代查询参数 : '?' + 反代查询参数) : 查询部分;
    config_JSON.完整节点路径 = (路径部分 || '/') + (路径部分 && 路径反代参数 ? '/' : '') + 路径反代参数 + 最终查询部分 + (config_JSON.启用0RTT ? (最终查询部分 ? '&' : '?') + 'ed=2560' : '');
    if (!config_JSON.TLS分片 && config_JSON.TLS分片 !== null)
        config_JSON.TLS分片 = null;
    const TLS分片参数 = config_JSON.TLS分片 == 'Shadowrocket' ? `&fragment=${encodeURIComponent('1,40-60,30-50,tlshello')}` : config_JSON.TLS分片 == 'Happ' ? `&fragment=${encodeURIComponent('3,1,tlshello')}` : '';
    if (!config_JSON.Fingerprint)
        config_JSON.Fingerprint = "chrome";
    if (!config_JSON.ECH)
        config_JSON.ECH = false;
    if (!config_JSON.ECHConfig)
        config_JSON.ECHConfig = { DNS: Ali_DoH, SNI: ECH_SNI };
    const ECHLINK参数 = config_JSON.ECH ? `&ech=${encodeURIComponent((config_JSON.ECHConfig.SNI ? config_JSON.ECHConfig.SNI + '+' : '') + config_JSON.ECHConfig.DNS)}` : '';
    const { type: 传输协议, 路径字段名, 域名字段名 } = 获取传输协议配置(config_JSON);
    const 传输路径参数值 = 获取传输路径参数值(config_JSON, config_JSON.完整节点路径);
    config_JSON.LINK = config_JSON.协议类型 === 'ss'
        ? `${config_JSON.协议类型}://${btoa(config_JSON.SS.加密方式 + ':' + userID)}@${host}:${config_JSON.SS.TLS ? '443' : '80'}?plugin=v2${encodeURIComponent(`ray-plugin;mode=websocket;host=${host};path=${((config_JSON.完整节点路径.includes('?') ? config_JSON.完整节点路径.replace('?', '?enc=' + config_JSON.SS.加密方式 + '&') : (config_JSON.完整节点路径 + '?enc=' + config_JSON.SS.加密方式)) + (config_JSON.SS.TLS ? ';tls' : ''))};mux=0`) + ECHLINK参数}#${encodeURIComponent(config_JSON.优选订阅生成.SUBNAME)}`
        : `${config_JSON.协议类型}://${userID}@${host}:443?security=tls&type=${传输协议 + ECHLINK参数}&${域名字段名}=${host}&fp=${config_JSON.Fingerprint}&sni=${host}&${路径字段名}=${encodeURIComponent(传输路径参数值) + TLS分片参数}&encryption=none${config_JSON.跳过证书验证 ? '&insecure=1&allowInsecure=1' : ''}#${encodeURIComponent(config_JSON.优选订阅生成.SUBNAME)}`;
    config_JSON.优选订阅生成.TOKEN = await MD5MD5(hostname + userID);
    const 初始化TG_JSON = { BotToken: null, ChatID: null };
    config_JSON.TG = { 启用: config_JSON.TG.启用 ? config_JSON.TG.启用 : false, ...初始化TG_JSON };
    try {
        const TG_TXT = await env.KV.get('tg.json');
        if (!TG_TXT) {
            await env.KV.put('tg.json', JSON.stringify(初始化TG_JSON, null, 2));
        }
        else {
            const TG_JSON = JSON.parse(TG_TXT);
            config_JSON.TG.ChatID = TG_JSON.ChatID ? TG_JSON.ChatID : null;
            config_JSON.TG.BotToken = TG_JSON.BotToken ? 掩码敏感信息(TG_JSON.BotToken) : null;
        }
    }
    catch (error) {
        console.error(`读取tg.json出错: ${error.message}`);
    }
    const 初始化CF_JSON = { Email: null, GlobalAPIKey: null, AccountID: null, APIToken: null, UsageAPI: null };
    config_JSON.CF = { ...初始化CF_JSON, Usage: { success: false, pages: 0, workers: 0, total: 0, max: 100000 } };
    try {
        const CF_TXT = await env.KV.get('cf.json');
        if (!CF_TXT) {
            await env.KV.put('cf.json', JSON.stringify(初始化CF_JSON, null, 2));
        }
        else {
            const CF_JSON = JSON.parse(CF_TXT);
            if (CF_JSON.UsageAPI) {
                try {
                    const response = await fetch(CF_JSON.UsageAPI);
                    const Usage = await response.json();
                    config_JSON.CF.Usage = Usage;
                }
                catch (err) {
                    console.error(`请求 CF_JSON.UsageAPI 失败: ${err.message}`);
                }
            }
            else {
                config_JSON.CF.Email = CF_JSON.Email ? CF_JSON.Email : null;
                config_JSON.CF.GlobalAPIKey = CF_JSON.GlobalAPIKey ? 掩码敏感信息(CF_JSON.GlobalAPIKey) : null;
                config_JSON.CF.AccountID = CF_JSON.AccountID ? 掩码敏感信息(CF_JSON.AccountID) : null;
                config_JSON.CF.APIToken = CF_JSON.APIToken ? 掩码敏感信息(CF_JSON.APIToken) : null;
                config_JSON.CF.UsageAPI = null;
                const Usage = await getCloudflareUsage(CF_JSON.Email, CF_JSON.GlobalAPIKey, CF_JSON.AccountID, CF_JSON.APIToken);
                config_JSON.CF.Usage = Usage;
            }
        }
    }
    catch (error) {
        console.error(`读取cf.json出错: ${error.message}`);
    }
    config_JSON.加载时间 = (performance.now() - 初始化开始时间).toFixed(2) + 'ms';
    return config_JSON;
}
function 识别运营商(request) {
    const cf = request?.cf;
    const ASN运营商映射 = {
        '4134': 'ct',
        '4809': 'ct',
        '4811': 'ct',
        '4812': 'ct',
        '4815': 'ct',
        '4837': 'cu',
        '4814': 'cu',
        '9929': 'cu',
        '17623': 'cu',
        '17816': 'cu',
        '9808': 'cmcc',
        '24400': 'cmcc',
        '56040': 'cmcc',
        '56041': 'cmcc',
        '56044': 'cmcc',
    };
    const 运营商关键词映射 = [
        { code: 'ct', pattern: /chinanet|chinatelecom|china telecom|cn2|shtel/ },
        { code: 'cmcc', pattern: /cmi|cmnet|chinamobile|china mobile|cmcc|mobile communications/ },
        { code: 'cu', pattern: /china169|china unicom|chinaunicom|cucc|cncgroup|cuii|netcom/ },
    ];
    if (String(cf?.country || '').toLowerCase() !== 'cn')
        return 'cf';
    const 组织名称 = String(cf?.asOrganization || '').toLowerCase();
    const 命中运营商 = 运营商关键词映射.find(({ pattern }) => pattern.test(组织名称))?.code;
    return 命中运营商 || ASN运营商映射[String(cf?.asn || '')] || 'cf';
}
async function 生成随机IP(request, count = 16, 指定端口 = -1, TLS = true) {
    const url = new URL(request.url);
    const 查询参数运营商 = String(url.searchParams.get('asOrg') || '').toLowerCase();
    const 运营商文件标识 = ['ct', 'cu', 'cmcc', 'cf'].includes(查询参数运营商) ? 查询参数运营商 : 识别运营商(request);
    const 运营商名称映射 = {
        cmcc: 'CF移动优选',
        cu: 'CF联通优选',
        ct: 'CF电信优选',
        cf: 'CF官方优选',
    };
    const cidr_url = 运营商文件标识 === 'cf' ? 'https://raw.githubusercontent.com/cmliu/cmliu/main/CF-CIDR.txt' : `https://raw.githubusercontent.com/cmliu/cmliu/main/CF-CIDR/${运营商文件标识}.txt`;
    const cfname = 运营商名称映射[运营商文件标识] || 'CF官方优选';
    const cfport = TLS ? [443, 2053, 2083, 2087, 2096, 8443] : [80, 8080, 8880, 2052, 2082, 2086, 2095];
    let cidrList = [];
    try {
        const res = await fetch(cidr_url);
        cidrList = res.ok ? await 整理成数组(await res.text()) : ['104.16.0.0/13'];
    }
    catch {
        cidrList = ['104.16.0.0/13'];
    }
    const generateRandomIPFromCIDR = (cidr) => {
        const [baseIP, prefixLength] = cidr.split('/'), prefix = parseInt(prefixLength), hostBits = 32 - prefix;
        const ipInt = baseIP.split('.').reduce((a, p, i) => a | (parseInt(p) << (24 - i * 8)), 0);
        const randomOffset = Math.floor(Math.random() * Math.pow(2, hostBits));
        const mask = (0xFFFFFFFF << hostBits) >>> 0, randomIP = (((ipInt & mask) >>> 0) + randomOffset) >>> 0;
        return [(randomIP >>> 24) & 0xFF, (randomIP >>> 16) & 0xFF, (randomIP >>> 8) & 0xFF, randomIP & 0xFF].join('.');
    };
    const TLS端口 = [443, 2053, 2083, 2087, 2096, 8443];
    const NOTLS端口 = [80, 2052, 2082, 2086, 2095, 8080];
    const randomIPs = Array.from({ length: count }, (_, index) => {
        const ip = generateRandomIPFromCIDR(cidrList[Math.floor(Math.random() * cidrList.length)]);
        const 目标端口 = 指定端口 === -1
            ? cfport[Math.floor(Math.random() * cfport.length)]
            : (TLS ? 指定端口 : (NOTLS端口[TLS端口.indexOf(Number(指定端口))] ?? 指定端口));
        return `${ip}:${目标端口}#${cfname}${index + 1}`;
    });
    return [randomIPs, randomIPs.join('\n')];
}
async function 整理成数组(内容) {
    var 替换后的内容 = 内容.replace(/[	"'\r\n]+/g, ',').replace(/,+/g, ',');
    if (替换后的内容.charAt(0) == ',')
        替换后的内容 = 替换后的内容.slice(1);
    if (替换后的内容.charAt(替换后的内容.length - 1) == ',')
        替换后的内容 = 替换后的内容.slice(0, 替换后的内容.length - 1);
    const 地址数组 = 替换后的内容.split(',');
    return 地址数组;
}
async function 获取优选订阅生成器数据(优选订阅生成器HOST) {
    let 优选IP = [], 其他节点LINK = '', 格式化HOST = 优选订阅生成器HOST.replace(/^sub:\/\//i, 'https://').split('#')[0].split('?')[0];
    if (!/^https?:\/\//i.test(格式化HOST))
        格式化HOST = `https://${格式化HOST}`;
    try {
        const url = new URL(格式化HOST);
        格式化HOST = url.origin;
    }
    catch (error) {
        优选IP.push(`127.0.0.1:1234#${优选订阅生成器HOST}优选订阅生成器格式化异常:${error.message}`);
        return [优选IP, 其他节点LINK];
    }
    const 优选订阅生成器URL = `${格式化HOST}/sub?host=example.com&uuid=00000000-0000-4000-8000-000000000000`;
    try {
        const response = await fetch(优选订阅生成器URL, {
            headers: { 'User-Agent': 'v2rayN/edge' + 'tunnel (https://github.com/cmliu/edge' + 'tunnel)' }
        });
        if (!response.ok) {
            优选IP.push(`127.0.0.1:1234#${优选订阅生成器HOST}优选订阅生成器异常:${response.statusText}`);
            return [优选IP, 其他节点LINK];
        }
        const 优选订阅生成器返回订阅内容 = atob(await response.text());
        const 订阅行列表 = 优选订阅生成器返回订阅内容.includes('\r\n')
            ? 优选订阅生成器返回订阅内容.split('\r\n')
            : 优选订阅生成器返回订阅内容.split('\n');
        for (const 行内容 of 订阅行列表) {
            if (!行内容.trim())
                continue;
            if (行内容.includes('00000000-0000-4000-8000-000000000000') && 行内容.includes('example.com')) {
                const 地址匹配 = 行内容.match(/:\/\/[^@]+@([^?]+)/);
                if (地址匹配) {
                    let 地址端口 = 地址匹配[1], 备注 = '';
                    const 备注匹配 = 行内容.match(/#(.+)$/);
                    if (备注匹配)
                        备注 = '#' + decodeURIComponent(备注匹配[1]);
                    优选IP.push(地址端口 + 备注);
                }
            }
            else {
                其他节点LINK += 行内容 + '\n';
            }
        }
    }
    catch (error) {
        优选IP.push(`127.0.0.1:1234#${优选订阅生成器HOST}优选订阅生成器异常:${error.message}`);
    }
    return [优选IP, 其他节点LINK];
}
async function 请求优选API(urls, 默认端口 = '443', 超时时间 = 3000) {
    if (!urls?.length)
        return [[], [], [], []];
    const results = new Set(), 反代IP池 = new Set();
    let 订阅链接响应的明文LINK内容 = '', 需要订阅转换订阅URLs = [];
    await Promise.allSettled(urls.map(async (url) => {
        const hashIndex = url.indexOf('#');
        const urlWithoutHash = hashIndex > -1 ? url.substring(0, hashIndex) : url;
        const API备注名 = hashIndex > -1 ? decodeURIComponent(url.substring(hashIndex + 1)) : null;
        const 优选IP作为反代IP = url.toLowerCase().includes('proxyip=true');
        if (urlWithoutHash.toLowerCase().startsWith('sub://')) {
            try {
                const [优选IP, 其他节点LINK] = await 获取优选订阅生成器数据(urlWithoutHash);
                if (API备注名) {
                    for (const ip of 优选IP) {
                        const 处理后IP = ip.includes('#')
                            ? `${ip} [${API备注名}]`
                            : `${ip}#[${API备注名}]`;
                        results.add(处理后IP);
                        if (优选IP作为反代IP)
                            反代IP池.add(ip.split('#')[0]);
                    }
                }
                else {
                    for (const ip of 优选IP) {
                        results.add(ip);
                        if (优选IP作为反代IP)
                            反代IP池.add(ip.split('#')[0]);
                    }
                }
                if (其他节点LINK && typeof 其他节点LINK === 'string' && API备注名) {
                    const 处理后LINK内容 = 其他节点LINK.replace(/([a-z][a-z0-9+\-.]*:\/\/[^\r\n]*?)(\r?\n|$)/gi, (match, link, lineEnd) => {
                        const 完整链接 = link.includes('#')
                            ? `${link}${encodeURIComponent(` [${API备注名}]`)}`
                            : `${link}${encodeURIComponent(`#[${API备注名}]`)}`;
                        return `${完整链接}${lineEnd}`;
                    });
                    订阅链接响应的明文LINK内容 += 处理后LINK内容;
                }
                else if (其他节点LINK && typeof 其他节点LINK === 'string') {
                    订阅链接响应的明文LINK内容 += 其他节点LINK;
                }
            }
            catch (e) { }
            return;
        }
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 超时时间);
            const response = await fetch(urlWithoutHash, { signal: controller.signal });
            clearTimeout(timeoutId);
            let text = '';
            try {
                const buffer = await response.arrayBuffer();
                const contentType = (response.headers.get('content-type') || '').toLowerCase();
                const charset = contentType.match(/charset=([^\s;]+)/i)?.[1]?.toLowerCase() || '';
                let decoders = ['utf-8', 'gb2312'];
                if (charset.includes('gb') || charset.includes('gbk') || charset.includes('gb2312')) {
                    decoders = ['gb2312', 'utf-8'];
                }
                let decodeSuccess = false;
                for (const decoder of decoders) {
                    try {
                        const decoded = new TextDecoder(decoder).decode(buffer);
                        if (decoded && decoded.length > 0 && !decoded.includes('\ufffd')) {
                            text = decoded;
                            decodeSuccess = true;
                            break;
                        }
                        else if (decoded && decoded.length > 0) {
                            continue;
                        }
                    }
                    catch (e) {
                        continue;
                    }
                }
                if (!decodeSuccess) {
                    text = await response.text();
                }
                if (!text || text.trim().length === 0) {
                    return;
                }
            }
            catch (e) {
                console.error('Failed to decode response:', e);
                return;
            }
            let 预处理订阅明文内容 = text;
            const cleanText = typeof text === 'string' ? text.replace(/\s/g, '') : '';
            if (cleanText.length > 0 && cleanText.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(cleanText)) {
                try {
                    const bytes = new Uint8Array(atob(cleanText).split('').map(c => c.charCodeAt(0)));
                    预处理订阅明文内容 = new TextDecoder('utf-8').decode(bytes);
                }
                catch { }
            }
            if (预处理订阅明文内容.split('#')[0].includes('://')) {
                if (API备注名) {
                    const 处理后LINK内容 = 预处理订阅明文内容.replace(/([a-z][a-z0-9+\-.]*:\/\/[^\r\n]*?)(\r?\n|$)/gi, (match, link, lineEnd) => {
                        const 完整链接 = link.includes('#')
                            ? `${link}${encodeURIComponent(` [${API备注名}]`)}`
                            : `${link}${encodeURIComponent(`#[${API备注名}]`)}`;
                        return `${完整链接}${lineEnd}`;
                    });
                    订阅链接响应的明文LINK内容 += 处理后LINK内容 + '\n';
                }
                else {
                    订阅链接响应的明文LINK内容 += 预处理订阅明文内容 + '\n';
                }
                return;
            }
            const lines = text.trim().split('\n').map(l => l.trim()).filter(l => l);
            const isCSV = lines.length > 1 && lines[0].includes(',');
            const IPV6_PATTERN = /^[^\[\]]*:[^\[\]]*:[^\[\]]/;
            const parsedUrl = new URL(urlWithoutHash);
            if (!isCSV) {
                lines.forEach(line => {
                    const lineHashIndex = line.indexOf('#');
                    const [hostPart, remark] = lineHashIndex > -1 ? [line.substring(0, lineHashIndex), line.substring(lineHashIndex)] : [line, ''];
                    let hasPort = false;
                    if (hostPart.startsWith('[')) {
                        hasPort = /\]:(\d+)$/.test(hostPart);
                    }
                    else {
                        const colonIndex = hostPart.lastIndexOf(':');
                        hasPort = colonIndex > -1 && /^\d+$/.test(hostPart.substring(colonIndex + 1));
                    }
                    const port = parsedUrl.searchParams.get('port') || 默认端口;
                    const ipItem = hasPort ? line : `${hostPart}:${port}${remark}`;
                    if (API备注名) {
                        const 处理后IP = ipItem.includes('#')
                            ? `${ipItem} [${API备注名}]`
                            : `${ipItem}#[${API备注名}]`;
                        results.add(处理后IP);
                    }
                    else {
                        results.add(ipItem);
                    }
                    if (优选IP作为反代IP)
                        反代IP池.add(ipItem.split('#')[0]);
                });
            }
            else {
                const headers = lines[0].split(',').map(h => h.trim());
                const dataLines = lines.slice(1);
                if (headers.includes('IP地址') && headers.includes('端口') && headers.includes('数据中心')) {
                    const ipIdx = headers.indexOf('IP地址'), portIdx = headers.indexOf('端口');
                    const remarkIdx = headers.indexOf('国家') > -1 ? headers.indexOf('国家') :
                        headers.indexOf('城市') > -1 ? headers.indexOf('城市') : headers.indexOf('数据中心');
                    const tlsIdx = headers.indexOf('TLS');
                    dataLines.forEach(line => {
                        const cols = line.split(',').map(c => c.trim());
                        if (tlsIdx !== -1 && cols[tlsIdx]?.toLowerCase() !== 'true')
                            return;
                        const wrappedIP = IPV6_PATTERN.test(cols[ipIdx]) ? `[${cols[ipIdx]}]` : cols[ipIdx];
                        const ipItem = `${wrappedIP}:${cols[portIdx]}#${cols[remarkIdx]}`;
                        if (API备注名) {
                            const 处理后IP = `${ipItem} [${API备注名}]`;
                            results.add(处理后IP);
                        }
                        else {
                            results.add(ipItem);
                        }
                        if (优选IP作为反代IP)
                            反代IP池.add(`${wrappedIP}:${cols[portIdx]}`);
                    });
                }
                else if (headers.some(h => h.includes('IP')) && headers.some(h => h.includes('延迟')) && headers.some(h => h.includes('下载速度'))) {
                    const ipIdx = headers.findIndex(h => h.includes('IP'));
                    const delayIdx = headers.findIndex(h => h.includes('延迟'));
                    const speedIdx = headers.findIndex(h => h.includes('下载速度'));
                    const port = parsedUrl.searchParams.get('port') || 默认端口;
                    dataLines.forEach(line => {
                        const cols = line.split(',').map(c => c.trim());
                        const wrappedIP = IPV6_PATTERN.test(cols[ipIdx]) ? `[${cols[ipIdx]}]` : cols[ipIdx];
                        const ipItem = `${wrappedIP}:${port}#CF优选 ${cols[delayIdx]}ms ${cols[speedIdx]}MB/s`;
                        if (API备注名) {
                            const 处理后IP = `${ipItem} [${API备注名}]`;
                            results.add(处理后IP);
                        }
                        else {
                            results.add(ipItem);
                        }
                        if (优选IP作为反代IP)
                            反代IP池.add(`${wrappedIP}:${port}`);
                    });
                }
            }
        }
        catch (e) { }
    }));
    const LINK数组 = 订阅链接响应的明文LINK内容.trim() ? [...new Set(订阅链接响应的明文LINK内容.split(/\r?\n/).filter(line => line.trim() !== ''))] : [];
    return [Array.from(results), LINK数组, 需要订阅转换订阅URLs, Array.from(反代IP池)];
}
async function 反代参数获取(url, uuid) {
    const { searchParams } = url;
    const pathname = decodeURIComponent(url.pathname);
    const pathLower = pathname.toLowerCase();
    const 链式代理路径匹配 = pathname.match(/\/video\/(.+)$/i);
    if (链式代理路径匹配) {
        try {
            const 链式代理明文 = base64SecretDecode(链式代理路径匹配[1], uuid);
            const { type, ...链式代理地址 } = JSON.parse(链式代理明文);
            if (!type || !反代协议默认端口[String(type).toLowerCase()])
                throw new Error('链式代理类型无效');
            if (!链式代理地址.hostname || !链式代理地址.port)
                throw new Error('链式代理地址缺少 hostname 或 port');
            我的SOCKS5账号 = '';
            反代IP = '链式代理';
            启用反代兜底 = false;
            启用SOCKS5全局反代 = true;
            启用SOCKS5反代 = String(type).toLowerCase();
            parsedSocks5Address = {
                username: 链式代理地址.username,
                password: 链式代理地址.password,
                hostname: 链式代理地址.hostname,
                port: Number(链式代理地址.port)
            };
            if (isNaN(parsedSocks5Address.port))
                throw new Error('链式代理端口无效');
            return;
        }
        catch (err) {
            console.error('解析链式代理参数失败:', err.message);
        }
    }
    我的SOCKS5账号 = searchParams.get('socks5') || searchParams.get('http') || searchParams.get('https') || searchParams.get('turn') || searchParams.get('sstp') || null;
    启用SOCKS5全局反代 = searchParams.has('globalproxy');
    if (searchParams.get('socks5'))
        启用SOCKS5反代 = 'socks5';
    else if (searchParams.get('http'))
        启用SOCKS5反代 = 'http';
    else if (searchParams.get('https'))
        启用SOCKS5反代 = 'https';
    else if (searchParams.get('turn'))
        启用SOCKS5反代 = 'turn';
    else if (searchParams.get('sstp'))
        启用SOCKS5反代 = 'sstp';
    const 解析代理URL = (值, 强制全局 = true) => {
        const 匹配 = /^(socks5|http|https|turn|sstp):\/\/(.+)$/i.exec(值 || '');
        if (!匹配)
            return false;
        启用SOCKS5反代 = 匹配[1].toLowerCase();
        我的SOCKS5账号 = 匹配[2].split('/')[0];
        if (强制全局)
            启用SOCKS5全局反代 = true;
        return true;
    };
    const 设置反代IP = (值) => {
        反代IP = 值;
        启用SOCKS5反代 = null;
        启用反代兜底 = false;
    };
    const 提取路径值 = (值) => {
        if (!值.includes('://')) {
            const 斜杠索引 = 值.indexOf('/');
            return 斜杠索引 > 0 ? 值.slice(0, 斜杠索引) : 值;
        }
        const 协议拆分 = 值.split('://');
        if (协议拆分.length !== 2)
            return 值;
        const 斜杠索引 = 协议拆分[1].indexOf('/');
        return 斜杠索引 > 0 ? `${协议拆分[0]}://${协议拆分[1].slice(0, 斜杠索引)}` : 值;
    };
    const 查询反代IP = searchParams.get('proxyip');
    if (查询反代IP !== null) {
        if (!解析代理URL(查询反代IP))
            return 设置反代IP(查询反代IP);
    }
    else {
        let 匹配 = /\/(socks5?|http|https|turn|sstp):\/?\/?([^/?#\s]+)/i.exec(pathname);
        if (匹配) {
            const 类型 = 匹配[1].toLowerCase();
            启用SOCKS5反代 = 类型 === 'sock' || 类型 === 'socks' ? 'socks5' : 类型;
            我的SOCKS5账号 = 匹配[2].split('/')[0];
            启用SOCKS5全局反代 = true;
        }
        else if ((匹配 = /\/(g?s5|socks5|g?http|g?https|g?turn|g?sstp)=([^/?#\s]+)/i.exec(pathname))) {
            const 类型 = 匹配[1].toLowerCase();
            我的SOCKS5账号 = 匹配[2].split('/')[0];
            启用SOCKS5反代 = 类型.includes('sstp') ? 'sstp' : (类型.includes('turn') ? 'turn' : (类型.includes('https') ? 'https' : (类型.includes('http') ? 'http' : 'socks5')));
            if (类型.startsWith('g'))
                启用SOCKS5全局反代 = true;
        }
        else if ((匹配 = /\/(proxyip[.=]|pyip=|ip=)([^?#\s]+)/.exec(pathLower))) {
            const 路径反代值 = 提取路径值(匹配[2]);
            if (!解析代理URL(路径反代值))
                return 设置反代IP(路径反代值);
        }
    }
    if (!我的SOCKS5账号) {
        启用SOCKS5反代 = null;
        return;
    }
    try {
        parsedSocks5Address = await 获取SOCKS5账号(我的SOCKS5账号, 获取代理默认端口(启用SOCKS5反代));
        if (searchParams.get('socks5'))
            启用SOCKS5反代 = 'socks5';
        else if (searchParams.get('http'))
            启用SOCKS5反代 = 'http';
        else if (searchParams.get('https'))
            启用SOCKS5反代 = 'https';
        else if (searchParams.get('turn'))
            启用SOCKS5反代 = 'turn';
        else if (searchParams.get('sstp'))
            启用SOCKS5反代 = 'sstp';
        else
            启用SOCKS5反代 = 启用SOCKS5反代 || 'socks5';
    }
    catch (err) {
        console.error('解析SOCKS5地址失败:', err.message);
        启用SOCKS5反代 = null;
    }
}
const 反代协议默认端口 = { socks5: 1080, http: 80, https: 443, turn: 3478, sstp: 443 };
function 获取代理默认端口(类型) {
    return 反代协议默认端口[String(类型 || '').toLowerCase()] || 80;
}
const SOCKS5账号Base64正则 = /^(?:[A-Z0-9+/]{4})*(?:[A-Z0-9+/]{2}==|[A-Z0-9+/]{3}=)?$/i, IPv6方括号正则 = /^\[.*\]$/;
function 获取SOCKS5账号(address, 默认端口 = 80) {
    address = String(address || '').trim().replace(/^(socks5|http|https|turn|sstp):\/\//i, '').split('#')[0].trim();
    const firstAt = address.lastIndexOf("@");
    if (firstAt !== -1) {
        let auth = address.slice(0, firstAt).replaceAll("%3D", "=");
        if (!auth.includes(":") && SOCKS5账号Base64正则.test(auth))
            auth = atob(auth);
        address = `${auth}@${address.slice(firstAt + 1)}`;
    }
    const atIndex = address.lastIndexOf("@");
    const hostPart = (atIndex === -1 ? address : address.slice(atIndex + 1)).split('/')[0];
    const authPart = atIndex === -1 ? "" : address.slice(0, atIndex);
    const [username, password] = authPart ? authPart.split(":") : [];
    if (authPart && !password)
        throw new Error('无效的 SOCKS 地址格式：认证部分必须是 "username:password" 的形式');
    let hostname = hostPart, port = 默认端口;
    if (hostPart.includes("]:")) {
        const [ipv6Host, ipv6Port = ""] = hostPart.split("]:");
        hostname = ipv6Host + "]";
        port = Number(ipv6Port.replace(/[^\d]/g, ""));
    }
    else if (!hostPart.startsWith("[")) {
        const parts = hostPart.split(":");
        if (parts.length === 2) {
            hostname = parts[0];
            port = Number(parts[1].replace(/[^\d]/g, ""));
        }
    }
    if (isNaN(port))
        throw new Error('无效的 SOCKS 地址格式：端口号必须是数字');
    if (hostname.includes(":") && !IPv6方括号正则.test(hostname))
        throw new Error('无效的 SOCKS 地址格式：IPv6 地址必须用方括号括起来，如 [2001:db8::1]');
    return { username, password, hostname, port };
}
async function getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken) {
    const API = "https://api.cloudflare.com/client/v4";
    const sum = (a) => a?.reduce((t, i) => t + (i?.sum?.requests || 0), 0) || 0;
    const cfg = { "Content-Type": "application/json" };
    try {
        if (!AccountID && (!Email || !GlobalAPIKey))
            return { success: false, pages: 0, workers: 0, total: 0, max: 100000 };
        if (!AccountID) {
            const r = await fetch(`${API}/accounts`, {
                method: "GET",
                headers: { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey }
            });
            if (!r.ok)
                throw new Error(`账户获取失败: ${r.status}`);
            const d = await r.json();
            if (!d?.result?.length)
                throw new Error("未找到账户");
            const idx = d.result.findIndex(a => a.name?.toLowerCase().startsWith(Email.toLowerCase()));
            AccountID = d.result[idx >= 0 ? idx : 0]?.id;
        }
        const now = new Date();
        now.setUTCHours(0, 0, 0, 0);
        const hdr = APIToken ? { ...cfg, "Authorization": `Bearer ${APIToken}` } : { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey };
        const res = await fetch(`${API}/graphql`, {
            method: "POST",
            headers: hdr,
            body: JSON.stringify({
                query: `query getBillingMetrics($AccountID: String!, $filter: AccountWorkersInvocationsAdaptiveFilter_InputObject) {
					viewer { accounts(filter: {accountTag: $AccountID}) {
						pagesFunctionsInvocationsAdaptiveGroups(limit: 1000, filter: $filter) { sum { requests } }
						workersInvocationsAdaptive(limit: 10000, filter: $filter) { sum { requests } }
					} }
				}`,
                variables: { AccountID, filter: { datetime_geq: now.toISOString(), datetime_leq: new Date().toISOString() } }
            })
        });
        if (!res.ok)
            throw new Error(`查询失败: ${res.status}`);
        const result = await res.json();
        if (result.errors?.length)
            throw new Error(result.errors[0].message);
        const acc = result?.data?.viewer?.accounts?.[0];
        if (!acc)
            throw new Error("未找到账户数据");
        const pages = sum(acc.pagesFunctionsInvocationsAdaptiveGroups);
        const workers = sum(acc.workersInvocationsAdaptive);
        const total = pages + workers;
        const max = 100000;
        log(`统计结果 - Pages: ${pages}, Workers: ${workers}, 总计: ${total}, 上限: 100000`);
        return { success: true, pages, workers, total, max };
    }
    catch (error) {
        console.error('获取使用量错误:', error.message);
        return { success: false, pages: 0, workers: 0, total: 0, max: 100000 };
    }
}
function sha224(s) {
    const K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
    const r = (n, b) => ((n >>> b) | (n << (32 - b))) >>> 0;
    s = unescape(encodeURIComponent(s));
    const l = s.length * 8;
    s += String.fromCharCode(0x80);
    while ((s.length * 8) % 512 !== 448)
        s += String.fromCharCode(0);
    const h = [0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939, 0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4];
    const hi = Math.floor(l / 0x100000000), lo = l & 0xFFFFFFFF;
    s += String.fromCharCode((hi >>> 24) & 0xFF, (hi >>> 16) & 0xFF, (hi >>> 8) & 0xFF, hi & 0xFF, (lo >>> 24) & 0xFF, (lo >>> 16) & 0xFF, (lo >>> 8) & 0xFF, lo & 0xFF);
    const w = [];
    for (let i = 0; i < s.length; i += 4)
        w.push((s.charCodeAt(i) << 24) | (s.charCodeAt(i + 1) << 16) | (s.charCodeAt(i + 2) << 8) | s.charCodeAt(i + 3));
    for (let i = 0; i < w.length; i += 16) {
        const x = new Array(64).fill(0);
        for (let j = 0; j < 16; j++)
            x[j] = w[i + j];
        for (let j = 16; j < 64; j++) {
            const s0 = r(x[j - 15], 7) ^ r(x[j - 15], 18) ^ (x[j - 15] >>> 3);
            const s1 = r(x[j - 2], 17) ^ r(x[j - 2], 19) ^ (x[j - 2] >>> 10);
            x[j] = (x[j - 16] + s0 + x[j - 7] + s1) >>> 0;
        }
        let [a, b, c, d, e, f, g, h0] = h;
        for (let j = 0; j < 64; j++) {
            const S1 = r(e, 6) ^ r(e, 11) ^ r(e, 25), ch = (e & f) ^ (~e & g), t1 = (h0 + S1 + ch + K[j] + x[j]) >>> 0;
            const S0 = r(a, 2) ^ r(a, 13) ^ r(a, 22), maj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + maj) >>> 0;
            h0 = g;
            g = f;
            f = e;
            e = (d + t1) >>> 0;
            d = c;
            c = b;
            b = a;
            a = (t1 + t2) >>> 0;
        }
        for (let j = 0; j < 8; j++)
            h[j] = (h[j] + (j === 0 ? a : j === 1 ? b : j === 2 ? c : j === 3 ? d : j === 4 ? e : j === 5 ? f : j === 6 ? g : h0)) >>> 0;
    }
    let hex = '';
    for (let i = 0; i < 7; i++) {
        for (let j = 24; j >= 0; j -= 8)
            hex += ((h[i] >>> j) & 0xFF).toString(16).padStart(2, '0');
    }
    return hex;
}
async function 解析地址端口(proxyIP, 目标域名 = 'dash.cloudflare.com', UUID = '00000000-0000-4000-8000-000000000000') {
    if (!缓存反代IP || !缓存反代解析数组 || 缓存反代IP !== proxyIP) {
        proxyIP = proxyIP.toLowerCase();
        function 解析地址端口字符串(str) {
            let 地址 = str, 端口 = 443;
            if (str.includes(']:')) {
                const parts = str.split(']:');
                地址 = parts[0] + ']';
                端口 = parseInt(parts[1], 10) || 端口;
            }
            else if ((str.match(/:/g) || []).length === 1 && !str.startsWith('[')) {
                const colonIndex = str.lastIndexOf(':');
                地址 = str.slice(0, colonIndex);
                端口 = parseInt(str.slice(colonIndex + 1), 10) || 端口;
            }
            return [地址, 端口];
        }
        function 解析TXT反代记录(txtData) {
            return txtData.flatMap(data => {
                if (data.startsWith('"') && data.endsWith('"'))
                    data = data.slice(1, -1);
                return data.replace(/\\010/g, ',').replace(/\n/g, ',').split(',').map(s => s.trim()).filter(Boolean);
            }).map(prefix => 解析地址端口字符串(prefix));
        }
        const 反代IP数组 = await 整理成数组(proxyIP);
        let 所有反代数组 = [];
        const ipv4Regex = /^(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
        const ipv6Regex = /^\[?(?:[a-fA-F0-9]{0,4}:){1,7}[a-fA-F0-9]{0,4}\]?$/;
        for (const singleProxyIP of 反代IP数组) {
            let [地址, 端口] = 解析地址端口字符串(singleProxyIP);
            if (singleProxyIP.includes('.tp')) {
                const tpMatch = singleProxyIP.match(/\.tp(\d+)/);
                if (tpMatch)
                    端口 = parseInt(tpMatch[1], 10);
            }
            if (ipv4Regex.test(地址) || ipv6Regex.test(地址)) {
                log(`[反代解析] ${地址} 为IP地址，直接使用`);
                所有反代数组.push([地址, 端口]);
                continue;
            }
            const [txtRecords, aRecords] = await Promise.all([
                DoH查询(地址, 'TXT'),
                DoH查询(地址, 'A')
            ]);
            const txtData = txtRecords.filter(r => r.type === 16).map(r => (r.data));
            const txtAddresses = 解析TXT反代记录(txtData);
            if (txtAddresses.length > 0) {
                log(`[反代解析] ${地址} 使用TXT记录，共${txtAddresses.length}个结果`);
                所有反代数组.push(...txtAddresses);
                continue;
            }
            const ipv4List = aRecords.filter(r => r.type === 1).map(r => r.data);
            if (ipv4List.length > 0) {
                log(`[反代解析] ${地址} 未获取到TXT记录，使用A记录，共${ipv4List.length}个结果`);
                所有反代数组.push(...ipv4List.map(ip => [ip, 端口]));
                continue;
            }
            const aaaaRecords = await DoH查询(地址, 'AAAA');
            const ipv6List = aaaaRecords.filter(r => r.type === 28).map(r => `[${r.data}]`);
            if (ipv6List.length > 0) {
                log(`[反代解析] ${地址} 未获取到TXT和A记录，使用AAAA记录，共${ipv6List.length}个结果`);
                所有反代数组.push(...ipv6List.map(ip => [ip, 端口]));
            }
            else {
                log(`[反代解析] ${地址} 未获取到TXT、A和AAAA记录，保留原域名`);
                所有反代数组.push([地址, 端口]);
            }
        }
        const 排序后数组 = 所有反代数组.sort((a, b) => a[0].localeCompare(b[0]));
        const 目标根域名 = 目标域名.includes('.') ? 目标域名.split('.').slice(-2).join('.') : 目标域名;
        let 随机种子 = [...(目标根域名 + UUID)].reduce((a, c) => a + c.charCodeAt(0), 0);
        log(`[反代解析] 随机种子: ${随机种子}\n目标站点: ${目标根域名}`);
        const 洗牌后 = [...排序后数组].sort(() => (随机种子 = (随机种子 * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff - 0.5);
        缓存反代解析数组 = 洗牌后.slice(0, 8);
        log(`[反代解析] 解析完成 总数: ${缓存反代解析数组.length}个\n${缓存反代解析数组.map(([ip, port], index) => `${index + 1}. ${ip}:${port}`).join('\n')}`);
        缓存反代IP = proxyIP;
    }
    else
        log(`[反代解析] 读取缓存 总数: ${缓存反代解析数组.length}个\n${缓存反代解析数组.map(([ip, port], index) => `${index + 1}. ${ip}:${port}`).join('\n')}`);
    return 缓存反代解析数组;
}
async function nginx() {
    return `
	<!DOCTYPE html>
	<html>
	<head>
	<title>Welcome to nginx!</title>
	<style>
		body {
			width: 35em;
			margin: 0 auto;
			font-family: Tahoma, Verdana, Arial, sans-serif;
		}
	</style>
	</head>
	<body>
	<h1>Welcome to nginx!</h1>
	<p>If you see this page, the nginx web server is successfully installed and
	working. Further configuration is required.</p>
	
	<p>For online documentation and support please refer to
	<a href="http://nginx.org/">nginx.org</a>.<br/>
	Commercial support is available at
	<a href="http://nginx.com/">nginx.com</a>.</p>
	
	<p><em>Thank you for using nginx.</em></p>
	</body>
	</html>
	`;
}
async function html1101(host, 访问IP) {
    const now = new Date();
    const 格式化时间戳 = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') + ' ' + String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0') + ':' + String(now.getSeconds()).padStart(2, '0');
    const 随机字符串 = Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b => b.toString(16).padStart(2, '0')).join('');
    return `<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en-US"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en-US"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en-US"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en-US"> <!--<![endif]-->
<head>
<title>Worker threw exception | ${host} | Cloudflare</title>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta name="robots" content="noindex, nofollow" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link rel="stylesheet" id="cf_styles-css" href="/cdn-cgi/styles/cf.errors.css" />
<!--[if lt IE 9]><link rel="stylesheet" id='cf_styles-ie-css' href="/cdn-cgi/styles/cf.errors.ie.css" /><![endif]-->
<style>body{margin:0;padding:0}</style>


<!--[if gte IE 10]><!-->
<script>
  if (!navigator.cookieEnabled) {
    window.addEventListener('DOMContentLoaded', function () {
      var cookieEl = document.getElementById('cookie-alert');
      cookieEl.style.display = 'block';
    })
  }
</script>
<!--<![endif]-->

</head>
<body>
    <div id="cf-wrapper">
        <div class="cf-alert cf-alert-error cf-cookie-error" id="cookie-alert" data-translate="enable_cookies">Please enable cookies.</div>
        <div id="cf-error-details" class="cf-error-details-wrapper">
            <div class="cf-wrapper cf-header cf-error-overview">
                <h1>
                    <span class="cf-error-type" data-translate="error">Error</span>
                    <span class="cf-error-code">1101</span>
                    <small class="heading-ray-id">Ray ID: ${随机字符串} &bull; ${格式化时间戳} UTC</small>
                </h1>
                <h2 class="cf-subheadline" data-translate="error_desc">Worker threw exception</h2>
            </div><!-- /.header -->
    
            <section></section><!-- spacer -->
    
            <div class="cf-section cf-wrapper">
                <div class="cf-columns two">
                    <div class="cf-column">
                        <h2 data-translate="what_happened">What happened?</h2>
                            <p>You've requested a page on a website (${host}) that is on the <a href="https://www.cloudflare.com/5xx-error-landing?utm_source=error_100x" target="_blank">Cloudflare</a> network. An unknown error occurred while rendering the page.</p>
                    </div>
                    
                    <div class="cf-column">
                        <h2 data-translate="what_can_i_do">What can I do?</h2>
                            <p><strong>If you are the owner of this website:</strong><br />refer to <a href="https://developers.cloudflare.com/workers/observability/errors/" target="_blank">Workers - Errors and Exceptions</a> and check Workers Logs for ${host}.</p>
                    </div>
                    
                </div>
            </div><!-- /.section -->
    
            <div class="cf-error-footer cf-wrapper w-240 lg:w-full py-10 sm:py-4 sm:px-8 mx-auto text-center sm:text-left border-solid border-0 border-t border-gray-300">
    <p class="text-13">
      <span class="cf-footer-item sm:block sm:mb-1">Cloudflare Ray ID: <strong class="font-semibold"> ${随机字符串}</strong></span>
      <span class="cf-footer-separator sm:hidden">&bull;</span>
      <span id="cf-footer-item-ip" class="cf-footer-item hidden sm:block sm:mb-1">
        Your IP:
        <button type="button" id="cf-footer-ip-reveal" class="cf-footer-ip-reveal-btn">Click to reveal</button>
        <span class="hidden" id="cf-footer-ip">${访问IP}</span>
        <span class="cf-footer-separator sm:hidden">&bull;</span>
      </span>
      <span class="cf-footer-item sm:block sm:mb-1"><span>Performance &amp; security by</span> <a rel="noopener noreferrer" href="https://www.cloudflare.com/5xx-error-landing" id="brand_link" target="_blank">Cloudflare</a></span>
      
    </p>
    <script>(function(){function d(){var b=a.getElementById("cf-footer-item-ip"),c=a.getElementById("cf-footer-ip-reveal");b&&"classList"in b&&(b.classList.remove("hidden"),c.addEventListener("click",function(){c.classList.add("hidden");a.getElementById("cf-footer-ip").classList.remove("hidden")}))}var a=document;document.addEventListener&&a.addEventListener("DOMContentLoaded",d)})();</script>
  </div><!-- /.error-footer -->

        </div><!-- /#cf-error-details -->
    </div><!-- /#cf-wrapper -->

     <script>
    window._cf_translation = {};
    
    
  </script> 
</body>
</html>`;
}
const 地区显示顺序 = ['DE', 'NL', 'GB', 'US', 'FI', 'FR', 'RU', 'SE', 'SG', 'LV', 'PL', 'JP', 'EE', 'ES', 'CH', 'CA', 'HK', 'KZ', 'AT', 'CZ', 'BG', 'TR', 'KR', 'DK', 'LT', 'RO', 'AU', 'MD', 'IT', 'IN', 'IE', 'AE', 'BE', 'TH', 'MY', 'HU', 'MX', 'BR', 'TW', 'NO', 'AM', 'RS', 'MK', 'ID', 'UA', 'PT', 'SK', 'IS', 'CL', 'VN', 'BY', 'AL', 'IL', 'PH', 'UZ', 'CY', 'GR', 'LI', 'BA', 'CO', 'EC', 'QA', 'SI', 'GE', 'KH', 'MO', 'NZ', 'KG'];
const 地区名称映射 = { DE: '德国', NL: '荷兰', GB: '英国', US: '美国', FI: '芬兰', FR: '法国', RU: '俄罗斯', SE: '瑞典', SG: '新加坡', LV: '拉脱维亚', PL: '波兰', JP: '日本', EE: '爱沙尼亚', ES: '西班牙', CH: '瑞士', CA: '加拿大', HK: '香港', KZ: '哈萨克斯坦', AT: '奥地利', CZ: '捷克', BG: '保加利亚', TR: '土耳其', KR: '韩国', DK: '丹麦', LT: '立陶宛', RO: '罗马尼亚', AU: '澳大利亚', MD: '摩尔多瓦', IT: '意大利', IN: '印度', IE: '爱尔兰', AE: '阿联酋', BE: '比利时', TH: '泰国', MY: '马来西亚', HU: '匈牙利', MX: '墨西哥', BR: '巴西', TW: '台湾', NO: '挪威', AM: '亚美尼亚', RS: '塞尔维亚', MK: '北马其顿', ID: '印尼', UA: '乌克兰', PT: '葡萄牙', SK: '斯洛伐克', IS: '冰岛', CL: '智利', VN: '越南', BY: '白俄罗斯', AL: '阿尔巴尼亚', IL: '以色列', PH: '菲律宾', UZ: '乌兹别克斯坦', CY: '塞浦路斯', GR: '希腊', LI: '列支敦士登', BA: '波黑', CO: '哥伦比亚', EC: '厄瓜多尔', QA: '卡塔尔', SI: '斯洛文尼亚', GE: '格鲁吉亚', KH: '柬埔寨', MO: '澳门', NZ: '新西兰', KG: '吉尔吉斯斯坦' };
function 地区旗帜(code) {
    if (code === 'TW')
        return '🇹🇼';
    if (!code || code.length !== 2)
        return '🇺🇳';
    return String.fromCodePoint(...code.toUpperCase().split('').map(char => 127397 + char.charCodeAt(0)));
}
function 数字上标(num) {
    const map = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
    return String(num).split('').map(c => map[c] || c).join('');
}
function 重新编号地区节点(lines, region) {
    const name = 地区名称映射[region] || region;
    return lines.map((line, index) => {
        const raw = String(line || '').trim();
        if (!raw)
            return '';
        const splitIndex = raw.lastIndexOf('#');
        const ipPort = splitIndex === -1 ? raw : raw.slice(0, splitIndex).trim();
        if (!ipPort)
            return '';
        return ipPort + '#' + 地区旗帜(region) + ' ' + name + 数字上标(index + 1);
    }).filter(Boolean);
}
async function 带超时fetch(url, options = {}, timeoutMs = 8500) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort('timeout'), timeoutMs);
    try {
        return await fetch(url, { ...options, signal: controller.signal });
    } finally {
        clearTimeout(timer);
    }
}
function 获取地区节点源(env = {}) {
    const configured = env.REGION_SOURCE_URL || env.IP_SOURCE_URL || env.NODE_SOURCE_URL || '';
    return configured ? configured.split(/[\n,]+/).map(x => x.trim()).filter(Boolean) : ['https://zip.cm.edu.kg/all.txt', 'https://zip.cm.edu.kg/all.json', 'https://countrymerge.pages.dev/all.txt'];
}
async function 获取地区源内容(env = {}) {
    const sources = 获取地区节点源(env);
    const errors = [];
    for (const source of sources) {
        try {
            const response = await 带超时fetch(source, { headers: { 'User-Agent': 'Mozilla/5.0 CF-Region-Loader' }, cf: { cacheTtl: 0, cacheEverything: false } }, 8500);
            if (!response.ok) {
                errors.push(source + ' HTTP ' + response.status);
                continue;
            }
            const contentType = response.headers.get('content-type') || '';
            const body = await response.text();
            if (!body || body.trim().length === 0) {
                errors.push(source + ' 内容为空');
                continue;
            }
            return { source, contentType, body, errors };
        } catch (error) {
            const message = error && error.name === 'AbortError' ? '请求超时' : (error && error.message ? error.message : String(error));
            errors.push(source + ' ' + message);
        }
    }
    throw new Error('所有节点源都无法访问：' + errors.join('；'));
}
async function 获取地区节点文本(region, env = {}) {
    if (!/^[A-Z]{2}$/.test(region))
        throw new Error('地区代码不正确');
    const sourceData = await 获取地区源内容(env);
    const isJson = sourceData.source.toLowerCase().includes('.json') || sourceData.contentType.includes('json') || sourceData.body.trim().startsWith('{') || sourceData.body.trim().startsWith('[');
    const result = isJson ? 解析地区JSON节点(sourceData.body, region) : 解析地区TXT节点(sourceData.body, region);
    const unique = [...new Set(result)];
    if (unique.length > 0)
        return { text: unique.join('\n'), count: unique.length, source: sourceData.source, errors: sourceData.errors || [] };
    throw new Error(sourceData.source + ' 没有匹配到 ' + region + ' 节点，原始长度 ' + sourceData.body.length);
}
function 解析地区TXT节点(text, region) {
    const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
    const result = [];
    let index = 0;
    for (const raw of lines) {
        const line = raw.trim();
        if (!line || !line.includes('#'))
            continue;
        const splitIndex = line.lastIndexOf('#');
        const ipPort = line.slice(0, splitIndex).trim();
        const code = line.slice(splitIndex + 1).trim().toUpperCase().replace(/[^A-Z]/g, '');
        if (code !== region || !ipPort)
            continue;
        index++;
        const name = 地区名称映射[region] || region;
        result.push(ipPort + '#' + 地区旗帜(region) + ' ' + name + 数字上标(index));
    }
    return result;
}
function 解析地区JSON节点(text, region) {
    const json = JSON.parse(text);
    const arr = Array.isArray(json) ? json : Array.isArray(json.data) ? json.data : [];
    const result = [];
    let index = 0;
    for (const item of arr) {
        if (!item || typeof item !== 'object')
            continue;
        const loc = item.locations || item.location || item.loc || {};
        const code = String(loc.cca2 || loc.country || item.cca2 || item.country || item.region || '').trim().toUpperCase();
        if (code !== region)
            continue;
        const ip = String(item.ip || item.address || item.host || '').trim();
        if (!ip)
            continue;
        let ports = item.port || item.ports || item.port_list || [443];
        if (!Array.isArray(ports))
            ports = [ports];
        for (const portRaw of ports) {
            const port = String(portRaw || '443').trim();
            if (!/^\d+$/.test(port))
                continue;
            index++;
            const name = 地区名称映射[region] || region;
            result.push(ip + ':' + port + '#' + 地区旗帜(region) + ' ' + name + 数字上标(index));
        }
    }
    return result;
}
function 解析地区TXT多选节点(text, regions) {
    const selected = new Set(规范化地区列表(regions));
    const counters = {};
    const result = [];
    const detailsMap = {};
    for (const code of selected) detailsMap[code] = 0;
    const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
    for (const raw of lines) {
        const line = raw.trim();
        if (!line || !line.includes('#'))
            continue;
        const splitIndex = line.lastIndexOf('#');
        const ipPort = line.slice(0, splitIndex).trim();
        const code = line.slice(splitIndex + 1).trim().toUpperCase().replace(/[^A-Z]/g, '');
        if (!selected.has(code) || !ipPort)
            continue;
        counters[code] = (counters[code] || 0) + 1;
        detailsMap[code] = (detailsMap[code] || 0) + 1;
        const name = 地区名称映射[code] || code;
        result.push(ipPort + '#' + 地区旗帜(code) + ' ' + name + 数字上标(counters[code]));
    }
    return { lines: result, detailsMap };
}
function 解析地区JSON多选节点(text, regions) {
    const selected = new Set(规范化地区列表(regions));
    const json = JSON.parse(text);
    const arr = Array.isArray(json) ? json : Array.isArray(json.data) ? json.data : [];
    const counters = {};
    const result = [];
    const detailsMap = {};
    for (const code of selected) detailsMap[code] = 0;
    for (const item of arr) {
        if (!item || typeof item !== 'object')
            continue;
        const loc = item.locations || item.location || item.loc || {};
        const code = String(loc.cca2 || loc.country || item.cca2 || item.country || item.region || '').trim().toUpperCase();
        if (!selected.has(code))
            continue;
        const ip = String(item.ip || item.address || item.host || '').trim();
        if (!ip)
            continue;
        let ports = item.port || item.ports || item.port_list || [443];
        if (!Array.isArray(ports))
            ports = [ports];
        for (const portRaw of ports) {
            const port = String(portRaw || '443').trim();
            if (!/^\d+$/.test(port))
                continue;
            counters[code] = (counters[code] || 0) + 1;
            detailsMap[code] = (detailsMap[code] || 0) + 1;
            const name = 地区名称映射[code] || code;
            result.push(ip + ':' + port + '#' + 地区旗帜(code) + ' ' + name + 数字上标(counters[code]));
        }
    }
    return { lines: result, detailsMap };
}

const 选中地区KV键 = 'SELECTED_REGIONS.json';
function 规范化地区列表(value) {
    let list = [];
    if (Array.isArray(value))
        list = value;
    else if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed)
            list = [];
        else {
            try {
                const parsed = JSON.parse(trimmed);
                list = Array.isArray(parsed) ? parsed : trimmed.split(/[\n,]+/);
            } catch (e) {
                list = trimmed.split(/[\n,]+/);
            }
        }
    }
    const seen = new Set();
    const result = [];
    for (const item of list) {
        const code = String(item || '').trim().toUpperCase();
        if (/^[A-Z]{2}$/.test(code) && 地区显示顺序.includes(code) && !seen.has(code)) {
            seen.add(code);
            result.push(code);
        }
    }
    return result;
}
async function 读取选中地区(env) {
    try {
        const raw = await env.KV.get(选中地区KV键);
        return 规范化地区列表(raw || '');
    } catch (e) {
        return [];
    }
}
async function 保存选中地区(env, regions) {
    await env.KV.put(选中地区KV键, JSON.stringify(规范化地区列表(regions)));
}

function 解析测速节点(line) {
    const raw = String(line || '').split('#')[0].trim();
    if (!raw)
        return null;
    let host = raw, port = 443;
    const ipv6 = raw.match(/^\[([^\]]+)\](?::(\d+))?$/);
    if (ipv6) {
        host = ipv6[1];
        port = parseInt(ipv6[2] || '443', 10) || 443;
    } else {
        const parts = raw.split(':');
        if (parts.length === 2 && /^\d+$/.test(parts[1])) {
            host = parts[0];
            port = parseInt(parts[1], 10) || 443;
        }
    }
    if (!host || !Number.isFinite(port) || port <= 0 || port > 65535)
        return null;
    return { host, port, line };
}
async function 测试单个节点延迟(item, timeoutMs) {
    let socket = null;
    const start = Date.now();
    try {
        socket = connect({ hostname: item.host, port: item.port });
        await Promise.race([
            socket.opened,
            new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs))
        ]);
        const latency = Date.now() - start;
        try { socket.close(); } catch (e) { }
        return { line: item.line, latency };
    } catch (e) {
        try { socket?.close?.(); } catch (x) { }
        return null;
    }
}
async function 并发测速节点(items, concurrency, timeoutMs, totalTimeoutMs) {
    const results = [];
    let index = 0;
    const deadline = Date.now() + totalTimeoutMs;
    const worker = async () => {
        while (index < items.length && Date.now() < deadline) {
            const current = items[index++];
            const result = await 测试单个节点延迟(current, timeoutMs);
            if (result)
                results.push(result);
        }
    };
    const count = Math.max(1, Math.min(concurrency, items.length));
    await Promise.all(Array.from({ length: count }, worker));
    return results;
}
function 稳定打散数组(arr) {
    const list = [...arr];
    let seed = 2166136261;
    for (let i = 0; i < list.length; i++) {
        const s = String(list[i]);
        for (let j = 0; j < s.length; j++)
            seed = Math.imul(seed ^ s.charCodeAt(j), 16777619);
    }
    for (let i = list.length - 1; i > 0; i--) {
        seed = Math.imul(seed ^ (seed >>> 13), 1274126177);
        const j = Math.abs(seed) % (i + 1);
        const tmp = list[i];
        list[i] = list[j];
        list[j] = tmp;
    }
    return list;
}
async function 测速筛选选中地区节点(regions, env = {}, limit = 30) {
    const rebuilt = await 重建选中地区节点文本(regions, env);
    const allLines = rebuilt.text.split('\n').map(x => x.trim()).filter(Boolean);
    const maxCandidates = Math.max(1, Math.min(3000, parseInt(env.SPEED_TEST_MAX_CANDIDATES || '800', 10) || 800));
    const timeoutMs = Math.max(150, Math.min(3000, parseInt(env.SPEED_TEST_TIMEOUT_MS || '650', 10) || 650));
    const concurrency = Math.max(1, Math.min(64, parseInt(env.SPEED_TEST_CONCURRENCY || '24', 10) || 24));
    const totalTimeoutMs = Math.max(3000, Math.min(50000, parseInt(env.SPEED_TEST_TOTAL_TIMEOUT_MS || '22000', 10) || 22000));
    const candidateLines = allLines.length > maxCandidates ? 稳定打散数组(allLines).slice(0, maxCandidates) : allLines;
    const items = candidateLines.map(解析测速节点).filter(Boolean);
    if (items.length === 0)
        throw new Error('没有可测速的节点');
    const tested = await 并发测速节点(items, concurrency, timeoutMs, totalTimeoutMs);
    tested.sort((a, b) => a.latency - b.latency);
    const selected = tested.slice(0, Math.max(1, Math.min(limit, tested.length)));
    if (selected.length === 0)
        throw new Error('测速失败，没有连通节点，可以调大 SPEED_TEST_TIMEOUT_MS 后重试');
    return { text: selected.map(x => x.line).join('\n'), count: selected.length, tested: tested.length, total: allLines.length, fastest: selected.slice(0, 10).map(x => ({ latency: x.latency, node: x.line })) };
}

function 随机打散数组(arr) {
    const list = [...arr];
    for (let i = list.length - 1; i > 0; i--) {
        let j;
        try {
            const buffer = new Uint32Array(1);
            crypto.getRandomValues(buffer);
            j = buffer[0] % (i + 1);
        } catch (e) {
            j = Math.floor(Math.random() * (i + 1));
        }
        const tmp = list[i];
        list[i] = list[j];
        list[j] = tmp;
    }
    return list;
}
async function 重建选中地区节点文本(regions, env = {}, perRegionLimit = 200) {
    const list = 规范化地区列表(regions);
    if (list.length === 0)
        throw new Error('请先选择国家/地区');
    const limitRaw = parseInt(perRegionLimit || '200', 10);
    const limit = Math.max(1, Math.min(5000, Number.isFinite(limitRaw) ? limitRaw : 200));
    const sourceData = await 获取地区源内容(env);
    const isJson = sourceData.source.toLowerCase().includes('.json') || sourceData.contentType.includes('json') || sourceData.body.trim().startsWith('{') || sourceData.body.trim().startsWith('[');
    const resultLines = [];
    const details = [];
    const errors = [...(sourceData.errors || [])];
    for (const region of list) {
        const regionLines = isJson ? 解析地区JSON节点(sourceData.body, region) : 解析地区TXT节点(sourceData.body, region);
        const uniqueLines = [...new Set(regionLines)];
        const pickedLines = 重新编号地区节点(随机打散数组(uniqueLines).slice(0, limit), region);
        resultLines.push(...pickedLines);
        details.push({ region, requested: limit, available: uniqueLines.length, selected: pickedLines.length, source: sourceData.source });
        if (uniqueLines.length === 0)
            errors.push(region + ' 没有匹配到节点');
        else if (uniqueLines.length < limit)
            errors.push(region + ' 只匹配到 ' + uniqueLines.length + ' 个节点，已全部写入');
    }
    const unique = [...new Set(resultLines)];
    if (unique.length === 0)
        throw new Error('当前选择没有拉取到任何节点。源：' + sourceData.source + '；' + errors.join('；'));
    return { text: unique.join('\n'), count: unique.length, details, errors, source: sourceData.source, perRegionLimit: limit };
}

function 生成谷歌伪装页面() {
    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Google</title><style>body{margin:0;font-family:Arial,sans-serif;background:#fff;color:#202124}.top{height:48px;display:flex;align-items:center;justify-content:flex-end;gap:16px;padding:6px 18px;font-size:13px}.top a{color:#202124;text-decoration:none}.top a:hover{text-decoration:underline}.apps{width:32px;height:32px;border-radius:50%;display:grid;place-items:center;color:#5f6368}.apps:hover{background:#f1f3f4}.avatar{width:32px;height:32px;border-radius:50%;background:#1a73e8;color:#fff;display:grid;place-items:center;font-weight:700}.main{display:flex;flex-direction:column;align-items:center;padding-top:150px}.logo{font-size:86px;font-weight:500;letter-spacing:-6px;line-height:1}.b{color:#4285f4}.r{color:#ea4335}.y{color:#fbbc05}.g{color:#34a853}.search{margin-top:28px;width:min(584px,calc(100vw - 48px));height:46px;border:1px solid #dfe1e5;border-radius:24px;display:flex;align-items:center;padding:0 16px;gap:12px}.search:hover{box-shadow:0 1px 6px rgba(32,33,36,.28);border-color:transparent}.search input{border:0;outline:0;flex:1;font-size:16px}.btns{margin-top:28px;display:flex;gap:12px}.btns button{background:#f8f9fa;border:1px solid #f8f9fa;border-radius:4px;color:#3c4043;font-size:14px;padding:0 16px;height:36px;cursor:pointer}.btns button:hover{box-shadow:0 1px 1px rgba(0,0,0,.1);border-color:#dadce0}.foot{position:fixed;bottom:0;left:0;right:0;background:#f2f2f2;color:#70757a;font-size:14px}.foot div{padding:15px 30px;border-top:1px solid #dadce0}</style></head><body><div class="top"><a href="https://www.google.com/">Gmail</a><a href="https://www.google.com/">Images</a><a class="apps" href="https://www.google.com/">☷</a><a class="avatar" href="https://www.google.com/">G</a></div><main class="main"><div class="logo"><span class="b">G</span><span class="r">o</span><span class="y">o</span><span class="b">g</span><span class="g">l</span><span class="r">e</span></div><form class="search" action="https://www.google.com/search"><span>⌕</span><input name="q" autocomplete="off"><span>🎙</span></form><div class="btns"><button onclick="document.querySelector('form').submit()">Google Search</button><button onclick="location.href='https://www.google.com/'">I'm Feeling Lucky</button></div></main><footer class="foot"><div>Japan</div><div>Advertising&nbsp;&nbsp;&nbsp;Business&nbsp;&nbsp;&nbsp;About&nbsp;&nbsp;&nbsp;Privacy&nbsp;&nbsp;&nbsp;Terms</div></footer></body></html>`;
}

function 生成KV未绑定页面(登录路径) {
    return `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>KV 未绑定</title><style>body{margin:0;min-height:100vh;background:#0b1220;color:#e5e7eb;font-family:Arial,'Microsoft YaHei',sans-serif;display:flex;align-items:center;justify-content:center}.box{width:min(520px,calc(100vw - 32px));background:#111827;border:1px solid #334155;border-radius:18px;padding:28px;box-shadow:0 20px 50px rgba(0,0,0,.35)}h1{font-size:24px;margin:0 0 12px}p{line-height:1.8;color:#cbd5e1}.code{background:#020617;border:1px solid #1e293b;border-radius:10px;padding:12px;color:#93c5fd}.btn{display:inline-block;margin-top:12px;color:#fff;background:#2563eb;padding:10px 16px;border-radius:10px;text-decoration:none}</style></head><body><div class="box"><h1>KV 没有绑定</h1><p>登录页已经正常工作，但后台需要 KV 才能保存 ADD.txt 和生成订阅。请在 Cloudflare Pages 的绑定里添加 KV Namespace，变量名必须是：</p><div class="code">KV</div><p>绑定后重新部署，再进入 /admin。</p><a class="btn" href="/${登录路径}">返回登录</a></div></body></html>`;
}

function 生成本地登录页面(登录路径, 登录后路径) {
    const 提交路径 = '/' + 登录路径;
    const 跳转路径 = 登录后路径 || 提交路径;
    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1220;color:#eaf2ff;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial}.card{width:min(360px,calc(100vw - 40px));background:#111b2e;border:1px solid #26364f;border-radius:18px;padding:28px;box-shadow:0 24px 80px rgba(0,0,0,.35)}h1{margin:0 0 8px;font-size:22px}p{margin:0 0 22px;color:#9fb0c8;font-size:13px}.field{display:flex;flex-direction:column;gap:8px;margin-bottom:14px}label{font-size:13px;color:#b9c6d8;font-weight:700}input{height:44px;border-radius:12px;border:1px solid #31425c;background:#0b1220;color:#eef4ff;padding:0 13px;outline:none}input:focus{border-color:#4f8cff}button{width:100%;height:44px;border:0;border-radius:12px;background:#2563eb;color:#fff;font-weight:800;cursor:pointer}button:disabled{opacity:.6;cursor:not-allowed}.err{display:none;margin-top:12px;color:#ff8b8b;font-size:13px}</style></head><body><form class="card" id="form"><h1>管理员登录</h1><p>请输入后台管理员密码</p><div class="field"><label>密码</label><input name="password" type="password" autocomplete="current-password" autofocus required></div><button id="btn">登录</button><div class="err" id="err"></div></form><script>const form=document.getElementById('form'),btn=document.getElementById('btn'),err=document.getElementById('err');form.addEventListener('submit',async e=>{e.preventDefault();err.style.display='none';btn.disabled=true;btn.textContent='登录中...';try{const r=await fetch('${提交路径}',{method:'POST',body:new URLSearchParams(new FormData(form))});const j=await r.json().catch(()=>({}));if(!r.ok||!j.success)throw new Error(j.error||'密码错误');location.href='${跳转路径}'}catch(x){err.textContent=x.message;err.style.display='block'}finally{btn.disabled=false;btn.textContent='登录'}});</script></body></html>`;
}
function HTML安全文本(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
function 生成订阅链接(origin, token, target = 'adaptive') {
    const type = String(target || 'adaptive').toLowerCase();
    if (type === 'v2ray' || type === 'mixed')
        return `${origin}/sub?target=mixed&token=${token}`;
    if (type === 'clash')
        return `${origin}/sub?target=clash&token=${token}`;
    if (type === 'singbox' || type === 'sing-box')
        return `${origin}/sub?target=singbox&token=${token}`;
    return `${origin}/sub?token=${token}`;
}
function 生成复制结果页面(link, target, count, selectedRegions) {
    const selectedText = 规范化地区列表(selectedRegions).join('、') || '未选择';
    const safeLink = HTML安全文本(link);
    const label = target === 'v2ray' ? 'V2Ray' : target === 'clash' ? 'Clash' : target === 'singbox' ? 'Sing-box' : '自适应链接';
    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>复制链接</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#070d1b;color:#eef4ff;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;display:grid;place-items:center}.box{width:min(560px,calc(100vw - 32px));background:#111b2e;border:1px solid #26364f;border-radius:16px;padding:22px;box-shadow:0 24px 80px rgba(0,0,0,.35)}h1{font-size:20px;margin:0 0 12px}.meta{font-size:13px;color:#b8c8dd;line-height:1.8;margin-bottom:12px}.link{background:#071020;border:1px solid #27364d;border-radius:10px;padding:10px;color:#9cc4ff;font-size:12px;word-break:break-all}.row{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap}.btn{height:38px;border:1px solid #33445f;background:#13203a;color:#eaf2ff;border-radius:9px;padding:0 14px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}.btn.primary{background:#2563eb;border-color:#2563eb;color:white}</style></head><body><div class="box"><h1>${label} 链接已生成</h1><div class="meta">已选择：${HTML安全文本(selectedText)}<br>已写入：${count} 个节点</div><div class="link" id="link">${safeLink}</div><div class="row"><button class="btn primary" id="copy">复制链接</button><a class="btn" href="/admin">返回</a></div></div><script>const link=document.getElementById('link').textContent;async function copy(){try{await navigator.clipboard.writeText(link)}catch(e){const ta=document.createElement('textarea');ta.value=link;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove()}document.getElementById('copy').textContent='已复制'}document.getElementById('copy').onclick=copy;copy();</script></body></html>`;
}
function 生成地区选择页面(token, currentADD, origin, notice = '', selectedRegions = []) {
    const selected = 规范化地区列表(selectedRegions);
    const selectedSet = new Set(selected);
    const selectedText = selected.length > 0 ? selected.join('、') : '未选择';
    const cards = 地区显示顺序.map(code => {
        const active = selectedSet.has(code);
        return `<a class="region ${active ? 'active' : ''}" href="/admin/set-region?region=${encodeURIComponent(code)}"><b>${code}</b><strong>${code}</strong><span>${地区名称映射[code] || code}</span></a>`;
    }).join('');
    const adaptive = HTML安全文本(生成订阅链接(origin, token, 'adaptive'));
    const v2ray = HTML安全文本(生成订阅链接(origin, token, 'v2ray'));
    const clash = HTML安全文本(生成订阅链接(origin, token, 'clash'));
    const singbox = HTML安全文本(生成订阅链接(origin, token, 'singbox'));
    const noticeHtml = notice ? `<div class="notice">${HTML安全文本(notice)}</div>` : '';
    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>节点管理</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#070d1b;color:#eef4ff;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.wrap{width:min(1020px,calc(100vw - 36px));margin:0 auto;padding:28px 0 14px}h1{font-size:20px;line-height:1.1;margin:0 0 10px;font-weight:900;letter-spacing:.2px}.topbar{display:flex;align-items:center;gap:8px;margin-bottom:10px}.smallbtn{height:30px;border:1px solid #30435f;background:#101a2e;color:#eaf2ff;border-radius:8px;padding:0 11px;font-size:12px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}.smallbtn:hover{border-color:#5d8dff;background:#15233d}.grid{display:grid;grid-template-columns:repeat(9,1fr);gap:8px}.region{height:54px;border-radius:8px;border:1px solid #2a3c56;background:#101a2b;color:#f4f8ff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;cursor:pointer;transition:.12s;text-decoration:none;position:relative}.region:hover{border-color:#4f8cff;background:#142139}.region.active{border-color:#2f6df6;background:#162b61;box-shadow:0 0 0 1px rgba(47,109,246,.35) inset}.region.active:after{content:'✓';position:absolute;top:5px;right:6px;width:15px;height:15px;border-radius:999px;background:#2f6df6;color:#fff;font-size:10px;line-height:15px;text-align:center}.region b{display:none}.region strong{font-size:13px;line-height:1;font-weight:900}.region span{font-size:10px;color:#d4e3ff;font-weight:700}.notice{margin:10px 0 0;background:#2a1620;border:1px solid #703247;color:#ffd4df;border-radius:10px;padding:9px 11px;font-size:12px;line-height:1.45}.summary{margin:10px 0;background:#0e1728;border:1px solid #27364d;border-radius:10px;padding:10px 12px;font-size:14px;color:#d9e6fa;line-height:1.5}.summary b{color:#fff}.bar{position:sticky;bottom:0;margin-top:10px;background:rgba(7,13,27,.94);backdrop-filter:blur(12px);border:1px solid #27364d;border-radius:12px;padding:10px 12px;display:flex;gap:10px;align-items:center;justify-content:space-between}.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.speed{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.speed input{width:84px;height:34px;border:1px solid #33445f;background:#091426;color:#eaf2ff;border-radius:9px;padding:0 10px;font-size:13px;font-weight:800;outline:none}.speed input:focus{border-color:#4f8cff}.btn{height:34px;border:1px solid #33445f;background:#13203a;color:#eaf2ff;border-radius:9px;padding:0 12px;font-size:12px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}.btn.primary{background:#2563eb;border-color:#2563eb;color:white}.btn:hover{filter:brightness(1.1)}.btn[aria-disabled="true"]{opacity:.65;pointer-events:none}.muted{font-size:12px;color:#9fb2cc}#toast{position:fixed;top:14px;left:50%;transform:translateX(-50%);background:#111b2e;border:1px solid #2b3a52;border-radius:12px;padding:9px 13px;box-shadow:0 16px 60px rgba(0,0,0,.35);display:none;z-index:9;max-width:min(620px,calc(100vw - 28px));line-height:1.5;font-size:13px}.loading{opacity:.65;pointer-events:none}@media(max-width:980px){.grid{grid-template-columns:repeat(7,1fr)}}@media(max-width:760px){.grid{grid-template-columns:repeat(4,1fr)}.wrap{width:min(100vw - 22px,720px)}.bar{align-items:flex-start;flex-direction:column}.actions{justify-content:flex-start}}@media(max-width:420px){.grid{grid-template-columns:repeat(3,1fr)}}</style></head><body><div class="wrap"><h1>区域选择</h1><div class="topbar"><a class="smallbtn" href="/admin/set-all-regions">全选</a><a class="smallbtn" href="/admin/clear-regions">清空</a></div><div class="grid">${cards}</div><div class="summary">已选择：<b>${HTML安全文本(selectedText)}</b></div>${noticeHtml}<div class="bar"><div class="actions"><a class="btn primary" href="/admin/apply-regions?target=adaptive&limit=200&html=1" data-target="adaptive" data-label="自适应链接" data-link="${adaptive}">自适应链接</a><a class="btn" href="/admin/apply-regions?target=v2ray&limit=200&html=1" data-target="v2ray" data-label="V2Ray" data-link="${v2ray}">V2Ray</a><a class="btn" href="/admin/apply-regions?target=clash&limit=200&html=1" data-target="clash" data-label="Clash" data-link="${clash}">Clash</a><a class="btn" href="/admin/apply-regions?target=singbox&limit=200&html=1" data-target="singbox" data-label="Sing-box" data-link="${singbox}">Sing-box</a></div><div class="speed"><span class="muted">数量</span><input id="nodeLimit" type="number" min="1" max="5000" value="200"><a class="btn" href="/logout">退出</a></div></div></div><div id="toast"></div><script>const toast=document.getElementById('toast');const limitInput=document.getElementById('nodeLimit');function show(msg){toast.textContent=msg;toast.style.display='block';clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(function(){toast.style.display='none'},3600)}function getLimit(){const n=parseInt(limitInput.value||'200',10);return Number.isFinite(n)&&n>0?Math.min(5000,n):200}async function copyText(text){try{await navigator.clipboard.writeText(text)}catch(e){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove()}}async function requestJson(url){const r=await fetch(url,{method:'GET',cache:'no-store'});const j=await r.json().catch(function(){return{}});if(!r.ok||!j.success)throw new Error(j.error||'操作失败');return j}async function applyAndCopy(ev,btn){ev.preventDefault();const target=btn.dataset.target||'adaptive';const label=btn.dataset.label||btn.textContent;const old=btn.textContent;const limit=getLimit();btn.setAttribute('aria-disabled','true');btn.textContent='写入中';try{const j=await requestJson('/admin/apply-regions?target='+encodeURIComponent(target)+'&limit='+encodeURIComponent(limit)+'&ajax=1&t='+Date.now());const link=j.link||btn.dataset.link;await copyText(link);const detail=(j.details||[]).map(function(x){return x.region+':'+x.selected}).join('，');let msg='已复制 '+label+'，已写入 '+j.count+' 个节点';if(detail)msg+='（'+detail+'）';if(j.errors&&j.errors.length)msg+='；'+j.errors.join('；');show(msg)}catch(e){show(e.message||String(e))}finally{btn.removeAttribute('aria-disabled');btn.textContent=old}}document.querySelectorAll('[data-target]').forEach(function(btn){btn.addEventListener('click',function(ev){applyAndCopy(ev,btn)})});document.querySelectorAll('.region').forEach(function(a){a.addEventListener('click',function(){a.classList.add('loading')})});</script></body></html>`;
}